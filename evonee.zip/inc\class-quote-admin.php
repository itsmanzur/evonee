<?php
if (!defined('ABSPATH')) {
    exit;
}

class Evonee_Quote_Admin {

    public static function init() {
        $instance = new self();
        add_action('admin_menu', [$instance, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$instance, 'enqueue_admin_assets']);
        add_action('admin_post_evonee_export_csv', [$instance, 'handle_csv_export']);
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'evonee') === false) {
            return;
        }
        $min = (defined('SCRIPT_DEBUG') && SCRIPT_DEBUG) ? '' : '.min';
        $css_file = file_exists(EVONEE_PLUGIN_DIR . 'assets/css/admin' . $min . '.css') ? 'admin' . $min . '.css' : 'admin.css';
        wp_enqueue_style('evonee-admin-css', EVONEE_PLUGIN_URL . 'assets/css/' . $css_file, [], EVONEE_VERSION);

        if (strpos($hook, 'evonee-analytics') !== false || strpos($hook, 'evonee-quotes') !== false || strpos($hook, 'evonee-dashboard') !== false) {
            wp_enqueue_script('chartjs', EVONEE_PLUGIN_URL . 'assets/js/chart.min.js', [], '4.4.1', true);
        }
    }

    public function add_admin_menu() {
        add_menu_page(
            'Evonee Quotes',
            'Evonee Quotes',
            'manage_options',
            'evonee-quotes',
            [$this, 'render_dashboard_page'],
            'dashicons-clipboard',
            30
        );

        add_submenu_page(
            'evonee-quotes',
            'Executive Dashboard',
            'Dashboard',
            'manage_options',
            'evonee-quotes',
            [$this, 'render_dashboard_page']
        );

        add_submenu_page(
            'evonee-quotes',
            'Quote Submissions',
            'Submissions',
            'manage_options',
            'evonee-submissions',
            [$this, 'render_submissions_page']
        );

        $settings = self::get_settings();
        if (!isset($settings['enable_analytics']) || $settings['enable_analytics'] === '1') {
            add_submenu_page(
                'evonee-quotes',
                'Analytics & Reports',
                'Analytics & Reports',
                'manage_options',
                'evonee-analytics',
                [$this, 'render_analytics_page']
            );
        }

        add_submenu_page(
            'evonee-quotes',
            'Settings & Modules',
            'Settings & Modules',
            'manage_options',
            'evonee-settings',
            [$this, 'render_settings_page']
        );

        add_submenu_page(
            'evonee-quotes',
            'Documentation & Help',
            'Documentation & Help',
            'manage_options',
            'evonee-docs',
            [$this, 'render_docs_page']
        );

        add_submenu_page(
            'evonee-quotes',
            'Quick Setup Wizard',
            '⚡ Setup Wizard',
            'manage_options',
            'evonee-setup-wizard',
            [$this, 'render_setup_wizard_page']
        );
    }

    /**
     * Get Plugin Options & Module Settings with Defaults
     */
    public static function get_settings() {
        $defaults = [
            'sales_email'              => 'sales@evonee.com',
            'currency_symbol'          => '$',
            'currency_code'            => 'USD',
            'currency_pos'             => 'left',
            'decimal_separator'        => '.',
            'thousand_separator'       => ',',
            'decimals'                 => '2',
            'delete_data_on_uninstall' => '0',
            'enable_price_calc'        => '1',
            'enable_pdf_quote'         => '1',
            'enable_analytics'         => '1',
            'enable_auto_reply'        => '1',
            'enable_wc_auto'           => '1',
            'enable_global_floating_btn' => '1',
            'global_floating_btn_text'   => '💬 Request Free Quote',
            'enable_rfq_basket'          => '1',
            'enable_whatsapp_float'      => '1',
            'whatsapp_number'            => '8801819898893',
            'whatsapp_default_msg'       => 'Hi Evonee Team! I have a question about a custom quote.',
            'whatsapp_float_position'    => 'bottom-right',
            'enable_deposit_payment'   => '0',
            'deposit_percentage'       => '50',
            'show_field_company'       => '1',
            'show_field_text_specs'    => '1',
            'show_field_specific_date' => '1',
            'show_field_project_notes' => '1',
            // Email Template Builder (Phase 1.4)
            'email_logo_url'           => '',
            'email_header_color'       => '#6d28d9',
            'email_brand_name'         => 'Evonee',
            'email_footer_text'        => 'Evonee Promotional Products • sales@evonee.com',
            // Phase 3 Settings
            'enable_google_sheets'     => '0',
            'google_sheets_url'        => '',
            'enable_recaptcha'         => '0',
            'recaptcha_site_key'       => '',
            'recaptcha_secret_key'     => '',
            'enable_webhook'           => '0',
            'webhook_url'              => '',
            'webhook_secret'           => '',
            'enable_slack'             => '0',
            'slack_webhook_url'        => '',
            'enable_discord'           => '0',
            'discord_webhook_url'      => '',
            // Phase 5 Enterprise Settings
            'enable_auto_quoter'       => '0',
            'auto_quoter_min_qty'      => 100,
            'auto_quoter_unit_price'   => 2.50,
            'enable_call_booking'      => '1',
            'enable_twilio_sms'        => '0',
            'twilio_sid'               => '',
            'twilio_token'             => '',
            'twilio_from_number'       => '',
            'enable_pdf_attachment'    => '1',
            'enable_price_estimator'   => '1',
            'base_quote_price'         => '50.00',
            'price_per_item'           => '1.25',
            'enable_woocommerce_button'=> '1',
            'woo_button_text'          => 'Request a Quote',
            'enable_wc_quote_only'     => '0',
            'wc_quote_condition'       => 'all',
            'wc_hide_price'            => '0',
            'enable_cart_quote'        => '0',
            'products_grid_limit'      => '12',
            'product_grid_orderby'     => 'date',
            'product_grid_order'       => 'DESC',
            'show_products_title'      => '0',
            // Product Grid Card Brand Colors
            'card_accent_color'        => '#6d28d9',
            'card_border_hover_color'  => '#a78bfa',
            'card_title_color'         => '#0f172a',
            'card_title_hover_color'   => '#6d28d9',
            'card_btn_bg'              => '#f3f0fc',
            'card_btn_text'            => '#6d28d9',
            'card_btn_hover_bg'        => '#6d28d9',
            'card_btn_hover_text'      => '#ffffff',
            'card_badge_bg'            => '#7c3aed',
            'card_badge_text'          => '#ffffff',
            'card_price_bg'            => '#f0fdf4',
            'card_price_text'          => '#16a34a',
            // Step 3 & 4 Enterprise Settings
            'pdf_company_name'         => 'Evonee Promotional Products',
            'pdf_tax_id'               => '',
            'pdf_accent_color'         => '#6d28d9',
            'pdf_terms_text'           => "1. Includes Free Digital Proof & Mockup preview before production.\n2. Price offer valid for 30 days from quote issue date.\n3. Standard production & delivery timeline applies upon artwork approval.",
            'enable_tiered_pricing'    => '1',
            'tiered_price_breaks'      => "50|5.00\n100|4.50\n500|3.80\n1000|3.20",
        ];

        $saved = get_option('evonee_quote_settings', []);
        return wp_parse_args($saved, $defaults);
    }

    /**
     * Centralized price formatter with multi-currency & locale support
     */
    public static function format_price($amount, $settings = null) {
        if ($settings === null) {
            $settings = self::get_settings();
        }
        $symbol   = !empty($settings['currency_symbol']) ? $settings['currency_symbol'] : '$';
        $pos      = !empty($settings['currency_pos']) ? $settings['currency_pos'] : 'left';
        $decimals = isset($settings['decimals']) ? intval($settings['decimals']) : 2;
        $dec_sep  = isset($settings['decimal_separator']) ? $settings['decimal_separator'] : '.';
        $th_sep   = isset($settings['thousand_separator']) ? $settings['thousand_separator'] : ',';

        $formatted_number = number_format(floatval($amount), $decimals, $dec_sep, $th_sep);

        switch ($pos) {
            case 'right':
                return $formatted_number . $symbol;
            case 'left_space':
                return $symbol . ' ' . $formatted_number;
            case 'right_space':
                return $formatted_number . ' ' . $symbol;
            case 'left':
            default:
                return $symbol . $formatted_number;
        }
    }

    /**
     * Dashboard Widget: Quick stats summary
     */
    public static function render_dashboard_widget() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        $today      = current_time('Y-m-d');

        // Check table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) !== $table_name) {
            echo '<p>Plugin table not found. Please deactivate and reactivate Evonee.</p>';
            return;
        }

        $stats = get_transient('evonee_dashboard_widget_stats');
        if (false === $stats || !is_array($stats) || !isset($stats['today_count'])) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $today_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE DATE(created_at) = %s", $today));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $new_count   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'new'));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $quoted      = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'quoted'));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $completed   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'completed'));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $total       = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions");

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $recent = $wpdb->get_results($wpdb->prepare(
                "SELECT id, full_name, product, status, created_at FROM {$wpdb->prefix}eq_quote_submissions WHERE DATE(created_at) = %s ORDER BY id DESC LIMIT 5",
                $today
            ));

            $stats = compact('today_count', 'new_count', 'quoted', 'completed', 'total', 'recent');
            set_transient('evonee_dashboard_widget_stats', $stats, 10 * MINUTE_IN_SECONDS);
        } else {
            $today_count = (int) ($stats['today_count'] ?? 0);
            $new_count   = (int) ($stats['new_count'] ?? 0);
            $quoted      = (int) ($stats['quoted'] ?? 0);
            $completed   = (int) ($stats['completed'] ?? 0);
            $total       = (int) ($stats['total'] ?? 0);
            $recent      = (array) ($stats['recent'] ?? []);
        }

        $status_colors = ['new' => '#16a34a', 'pending' => '#d97706', 'quoted' => '#2563eb', 'approved' => '#7c3aed', 'completed' => '#059669', 'rejected' => '#dc2626'];
        ?>
        <div style="font-family: -apple-system, sans-serif;">
            <!-- Stats Row -->
            <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-bottom:14px;">
                <div style="background:#faf5ff; border:1px solid #e9d5ff; border-radius:8px; padding:10px; text-align:center;">
                    <div style="font-size:22px; font-weight:800; color:#6d28d9;"><?php echo esc_html($today_count); ?></div>
                    <div style="font-size:11px; color:#6b7280; margin-top:2px;">Today</div>
                </div>
                <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; padding:10px; text-align:center;">
                    <div style="font-size:22px; font-weight:800; color:#16a34a;"><?php echo esc_html($new_count); ?></div>
                    <div style="font-size:11px; color:#6b7280; margin-top:2px;">New</div>
                </div>
                <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:10px; text-align:center;">
                    <div style="font-size:22px; font-weight:800; color:#2563eb;"><?php echo esc_html($quoted); ?></div>
                    <div style="font-size:11px; color:#6b7280; margin-top:2px;">Quoted</div>
                </div>
                <div style="background:#f0fdf4; border:1px solid #a7f3d0; border-radius:8px; padding:10px; text-align:center;">
                    <div style="font-size:22px; font-weight:800; color:#059669;"><?php echo esc_html($completed); ?></div>
                    <div style="font-size:11px; color:#6b7280; margin-top:2px;">Completed</div>
                </div>
            </div>

            <!-- Today's Submissions -->
            <?php if (!empty($recent)): ?>
                <p style="font-size:12px; font-weight:700; color:#374151; margin:0 0 6px;">📋 Today's Submissions:</p>
                <ul style="margin:0; padding:0; list-style:none;">
                    <?php foreach ($recent as $r):
                        $sc = isset($status_colors[strtolower($r->status)]) ? $status_colors[strtolower($r->status)] : '#6b7280';
                    ?>
                        <li style="display:flex; justify-content:space-between; align-items:center; padding:5px 0; border-bottom:1px solid #f1f5f9; font-size:12px;">
                            <span><strong>#<?php echo esc_html($r->id); ?></strong> <?php echo esc_html($r->full_name); ?> — <em><?php echo esc_html($r->product); ?></em></span>
                            <span style="background:<?php echo esc_attr($sc); ?>; color:#fff; border-radius:4px; padding:2px 7px; font-size:10px; font-weight:700; text-transform:uppercase;"><?php echo esc_html($r->status ?: 'new'); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p style="color:#9ca3af; font-size:12px; text-align:center; margin:8px 0;">No submissions today yet.</p>
            <?php endif; ?>

            <!-- Footer -->
            <div style="margin-top:12px; display:flex; justify-content:space-between; align-items:center;">
                <span style="font-size:11px; color:#9ca3af;">Total: <strong><?php echo esc_html($total); ?></strong> submissions</span>
                <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-submissions')); ?>" class="button button-primary button-small" style="background:#6d28d9; border-color:#6d28d9;">View All &rarr;</a>
            </div>
        </div>
        <?php
    }

    /**
     * Render Evonee Executive Dashboard Page (v3.1 Command Center)
     */
    public function render_dashboard_page() {
        // Fallback for direct query links to render Submissions page seamlessly
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!empty($_GET['s']) || !empty($_GET['status_filter']) || !empty($_GET['action']) || !empty($_GET['paged']) || isset($_GET['id']) || (isset($_GET['view']) && $_GET['view'] === 'submissions')) {
            $this->render_submissions_page();
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) !== $table_name) {
            Evonee_Quote_Ajax::create_submissions_table();
        }

        $stats = get_transient('evonee_dashboard_stats');
        if (false === $stats || !is_array($stats) || !isset($stats['total_count'])) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $total_count     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions");
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $new_count       = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'new'));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $pending_count   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'pending'));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $quoted_count    = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'quoted'));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $approved_count  = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'approved'));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $completed_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'completed'));

            // Total Quoted Revenue Value ($)
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $total_pipeline_val = (float) $wpdb->get_var("SELECT SUM(quoted_price) FROM {$wpdb->prefix}eq_quote_submissions WHERE quoted_price IS NOT NULL AND quoted_price > 0");

            // Overdue / Urgent Action Needed Count
            $today = current_time('Y-m-d');
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $urgent_count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE (status IN ('new', 'pending') AND created_at <= %s) OR (follow_up_date IS NOT NULL AND follow_up_date <= %s)",
                wp_date('Y-m-d H:i:s', time() - (2 * DAY_IN_SECONDS)),
                $today
            ));

            // Recent 5 Submissions
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $recent_quotes = $wpdb->get_results("SELECT id, full_name, email, product, quantity, quoted_price, status, created_at FROM {$wpdb->prefix}eq_quote_submissions ORDER BY id DESC LIMIT 5");

            // Monthly Trends (Last 6 Months)
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $monthly_trends = $wpdb->get_results("
                SELECT DATE_FORMAT(created_at, '%b %Y') as month_label, COUNT(*) as total 
                FROM {$wpdb->prefix}eq_quote_submissions 
                GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
                ORDER BY created_at ASC LIMIT 6
            ");

            // Top Requested Products (Top 3)
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $top_products = $wpdb->get_results("
                SELECT product, COUNT(*) as total
                FROM {$wpdb->prefix}eq_quote_submissions
                GROUP BY product
                ORDER BY total DESC
                LIMIT 3
            ");

            $stats = compact('total_count', 'new_count', 'pending_count', 'quoted_count', 'approved_count', 'completed_count', 'total_pipeline_val', 'urgent_count', 'recent_quotes', 'monthly_trends', 'top_products');
            set_transient('evonee_dashboard_stats', $stats, 10 * MINUTE_IN_SECONDS);
        } else {
            $total_count        = (int) ($stats['total_count'] ?? 0);
            $new_count          = (int) ($stats['new_count'] ?? 0);
            $pending_count      = (int) ($stats['pending_count'] ?? 0);
            $quoted_count       = (int) ($stats['quoted_count'] ?? 0);
            $approved_count     = (int) ($stats['approved_count'] ?? 0);
            $completed_count    = (int) ($stats['completed_count'] ?? 0);
            $total_pipeline_val = (float) ($stats['total_pipeline_val'] ?? 0);
            $urgent_count       = (int) ($stats['urgent_count'] ?? 0);
            $recent_quotes      = (array) ($stats['recent_quotes'] ?? []);
            $monthly_trends     = (array) ($stats['monthly_trends'] ?? []);
            $top_products       = (array) ($stats['top_products'] ?? []);
        }

        $won_deals = $approved_count + $completed_count;
        $win_rate  = $total_count > 0 ? round(($won_deals / $total_count) * 100, 1) : 0;
        $settings  = self::get_settings();
        $curr_sym  = esc_html($settings['currency_symbol'] ?? '$');

        // System Health Diagnostics Checks
        $cron_active     = wp_next_scheduled('evonee_daily_quote_cron') ? true : false;
        $wc_active       = class_exists('WooCommerce');
        $recaptcha_ready = (!empty($settings['enable_recaptcha']) && !empty($settings['recaptcha_site_key']));
        $webhook_ready   = (!empty($settings['enable_webhook']) && !empty($settings['webhook_url']));
        $slack_ready     = (!empty($settings['enable_slack']) && !empty($settings['slack_webhook_url']));
        $user_name       = wp_get_current_user()->display_name ?: 'Admin';
        ?>
        <div class="wrap evonee-admin-wrap">
            <!-- Hero Header -->
            <div class="evonee-docs-header" style="background: linear-gradient(135deg, #0f172a 0%, #3b0764 50%, #6d28d9 100%); padding:28px 32px; border-radius:14px; margin-bottom:24px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
                    <div>
                        <h1 style="color:#ffffff; font-size:26px; font-weight:800; margin:0 0 6px; display:flex; align-items:center; gap:10px;">
                            ⚡ Evonee Executive Command Center
                        </h1>
                        <p class="subtitle" style="color:#cbd5e1; font-size:14px; margin:0;">
                            Welcome back, <strong><?php echo esc_html($user_name); ?></strong>! Overview of your B2B quotation pipeline, automated reminders, and revenue metrics.
                        </p>
                    </div>
                    <div class="evonee-docs-brand" style="text-align:right;">
                        <span style="background:rgba(255,255,255,0.15); backdrop-filter:blur(8px); color:#ffffff; padding:6px 14px; border-radius:20px; font-size:12px; font-weight:700; border:1px solid rgba(255,255,255,0.2);">
                            v1.0.0 Release Edition
                        </span>
                        <div style="font-size:11px; color:#cbd5e1; margin-top:6px;">📅 <?php echo esc_html(wp_date('F j, Y')); ?></div>
                    </div>
                </div>
            </div>

            <!-- Preset & Mode Indicator Banner -->
            <div style="background:#f3f0fc; border:1px solid #ddd6fe; border-left:4px solid #6d28d9; border-radius:10px; padding:12px 18px; margin-bottom:24px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                <div style="display:flex; align-items:center; gap:10px; font-size:13px; color:#4c1d95;">
                    <span style="font-size:18px;">⚙️</span>
                    <span><strong>Active Store Configuration:</strong> B2B Quotation Engine is active. Customize branding, presets, or currency anytime.</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-setup-wizard')); ?>" class="button button-secondary button-small" style="font-weight:700; color:#6d28d9; border-color:#c4b5fd;">⚡ Launch Setup Wizard</a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-settings')); ?>" class="button button-secondary button-small" style="font-weight:700;">⚙️ Settings</a>
                </div>
            </div>

            <!-- Urgent Action Alert Banner -->
            <?php if ($urgent_count > 0): ?>
                <div class="evonee-dash-alert" style="background:#fff7ed; border:1px solid #ffedd5; border-left:4px solid #f97316; border-radius:10px; padding:14px 20px; margin-bottom:24px; display:flex; justify-content:space-between; align-items:center; gap:16px;">
                    <div style="display:flex; align-items:center; gap:12px;">
                        <span style="font-size:24px;">⚠️</span>
                        <div>
                            <strong style="color:#9a3412; font-size:14px;">Urgent Lead Action Required!</strong>
                            <p style="color:#c2410c; font-size:13px; margin:2px 0 0;">You have <strong><?php echo esc_html($urgent_count); ?></strong> quote request(s) awaiting response or overdue for follow-up.</p>
                        </div>
                    </div>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-submissions&date_range=followup_due')); ?>" class="button button-primary" style="background:#ea580c; border-color:#ea580c; font-weight:700; border-radius:6px; white-space:nowrap;">View Pending Quotes &rarr;</a>
                </div>
            <?php endif; ?>

            <!-- KPI Metric Cards Grid -->
            <div class="evonee-metrics-grid" style="display:grid; grid-template-columns:repeat(4, 1fr); gap:18px; margin-bottom:24px;">
                <div class="evonee-stat-card" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:20px; display:flex; align-items:center; gap:16px; box-shadow:0 2px 4px rgba(0,0,0,0.02);">
                    <div class="evonee-stat-icon" style="background:#faf5ff; color:#6d28d9; font-size:24px; width:52px; height:52px; border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">📥</div>
                    <div>
                        <div class="evonee-stat-val" style="font-size:26px; font-weight:800; color:#0f172a; line-height:1.2;"><?php echo esc_html(number_format($total_count)); ?></div>
                        <div class="evonee-stat-lbl" style="font-size:12px; color:#64748b; font-weight:600; margin-top:2px;">Total Quotes Received</div>
                    </div>
                </div>

                <div class="evonee-stat-card" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:20px; display:flex; align-items:center; gap:16px; box-shadow:0 2px 4px rgba(0,0,0,0.02);">
                    <div class="evonee-stat-icon" style="background:#fff7ed; color:#ea580c; font-size:24px; width:52px; height:52px; border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">⏳</div>
                    <div>
                        <div class="evonee-stat-val" style="font-size:26px; font-weight:800; color:#ea580c; line-height:1.2;"><?php echo esc_html(number_format($new_count + $pending_count)); ?></div>
                        <div class="evonee-stat-lbl" style="font-size:12px; color:#64748b; font-weight:600; margin-top:2px;">Action Needed (New / Pending)</div>
                    </div>
                </div>

                <div class="evonee-stat-card" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:20px; display:flex; align-items:center; gap:16px; box-shadow:0 2px 4px rgba(0,0,0,0.02);">
                    <div class="evonee-stat-icon" style="background:#eff6ff; color:#2563eb; font-size:24px; width:52px; height:52px; border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">💰</div>
                    <div>
                        <div class="evonee-stat-val" style="font-size:26px; font-weight:800; color:#2563eb; line-height:1.2;"><?php echo esc_html($curr_sym) . esc_html(number_format($total_pipeline_val, 2)); ?></div>
                        <div class="evonee-stat-lbl" style="font-size:12px; color:#64748b; font-weight:600; margin-top:2px;">Gross Quoted Pipeline</div>
                    </div>
                </div>

                <div class="evonee-stat-card" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:20px; display:flex; align-items:center; gap:16px; box-shadow:0 2px 4px rgba(0,0,0,0.02);">
                    <div class="evonee-stat-icon" style="background:#f0fdf4; color:#16a34a; font-size:24px; width:52px; height:52px; border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">🏆</div>
                    <div>
                        <div class="evonee-stat-val" style="font-size:26px; font-weight:800; color:#16a34a; line-height:1.2;"><?php echo esc_html(number_format($won_deals)); ?></div>
                        <div class="evonee-stat-lbl" style="font-size:12px; color:#64748b; font-weight:600; margin-top:2px;">Won Deals (<?php echo esc_html($win_rate); ?>% Win Rate)</div>
                    </div>
                </div>
            </div>

            <!-- Pipeline Funnel & Monthly Target Goal Card -->
            <div class="evonee-doc-card" style="margin-bottom:24px;">
                <div class="evonee-card-header" style="padding:14px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; border-top-left-radius:12px; border-top-right-radius:12px; display:flex; justify-content:space-between; align-items:center;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span class="dashicons dashicons-chart-pie" style="color:#6d28d9;"></span>
                        <h2 style="font-size:14px; font-weight:700; color:#1e293b; margin:0;">🎯 Pipeline Funnel & Monthly Revenue Target</h2>
                    </div>
                    <span style="font-size:12px; font-weight:700; color:#16a34a; background:#f0fdf4; border:1px solid #bbf7d0; padding:2px 10px; border-radius:12px;">
                        <?php echo esc_html($win_rate); ?>% Win Rate
                    </span>
                </div>
                <div class="evonee-card-body" style="padding:20px;">
                    <?php
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                    $avg_resp_sec = (int) $wpdb->get_var("SELECT AVG(response_time_seconds) FROM {$wpdb->prefix}eq_quote_submissions WHERE response_time_seconds IS NOT NULL AND response_time_seconds > 0");
                    if ($avg_resp_sec > 0) {
                        $hrs  = floor($avg_resp_sec / 3600);
                        $mins = round(($avg_resp_sec % 3600) / 60);
                        $resp_time_str = ($hrs > 0) ? "{$hrs}h {$mins}m" : "{$mins} mins";
                    } else {
                        $resp_time_str = "⚡ <15 mins";
                    }
                    ?>
                    <div style="display:grid; grid-template-columns:repeat(5, 1fr); gap:12px; text-align:center; margin-bottom:18px;">
                        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px;">
                            <span style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;">1. New Requests</span>
                            <div style="font-size:20px; font-weight:800; color:#16a34a; margin-top:4px;"><?php echo esc_html($new_count); ?></div>
                        </div>
                        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px;">
                            <span style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;">2. Quoted Offers</span>
                            <div style="font-size:20px; font-weight:800; color:#2563eb; margin-top:4px;"><?php echo esc_html($quoted_count); ?></div>
                        </div>
                        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px;">
                            <span style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;">3. Approved Deals</span>
                            <div style="font-size:20px; font-weight:800; color:#7c3aed; margin-top:4px;"><?php echo esc_html($approved_count); ?></div>
                        </div>
                        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px;">
                            <span style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;">4. Pipeline Value</span>
                            <div style="font-size:20px; font-weight:800; color:#059669; margin-top:4px;"><?php echo esc_html($curr_sym) . esc_html(number_format($total_pipeline_val, 2)); ?></div>
                        </div>
                        <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:10px; padding:12px;">
                            <span style="font-size:11px; font-weight:700; color:#166534; text-transform:uppercase;">5. Avg Lead Velocity</span>
                            <div style="font-size:18px; font-weight:800; color:#15803d; margin-top:4px;"><?php echo esc_html($resp_time_str); ?></div>
                        </div>
                    </div>

                    <!-- Target Progress Bar -->
                    <?php
                    $target_goal = 10000;
                    $goal_pct    = min(100, round(($total_pipeline_val / $target_goal) * 100));
                    ?>
                    <div>
                        <div style="display:flex; justify-content:space-between; font-size:12px; font-weight:700; color:#334155; margin-bottom:6px;">
                            <span>Monthly Quoted Goal ($10,000 Target)</span>
                            <span><?php echo esc_html($curr_sym) . esc_html(number_format($total_pipeline_val, 2)); ?> / $10,000 (<?php echo esc_html($goal_pct); ?>%)</span>
                        </div>
                        <div style="background:#f1f5f9; border-radius:10px; height:10px; overflow:hidden;">
                            <div style="background:linear-gradient(90deg, #16a34a 0%, #22c55e 100%); height:100%; width:<?php echo esc_attr($goal_pct); ?>%; border-radius:10px;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Action Launcher Grid -->
            <div class="evonee-doc-card" style="margin-bottom:24px;">
                <div class="evonee-card-header" style="padding:14px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; border-top-left-radius:12px; border-top-right-radius:12px; display:flex; align-items:center; gap:8px;">
                    <span class="dashicons dashicons-external" style="color:#6d28d9;"></span>
                    <h2 style="font-size:14px; font-weight:700; color:#1e293b; margin:0;">Quick Launcher & Action Center</h2>
                </div>
                <div class="evonee-card-body" style="padding:18px 20px;">
                    <div style="display:grid; grid-template-columns:repeat(5, 1fr); gap:12px;">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-submissions')); ?>" class="button" style="display:flex; align-items:center; justify-content:center; gap:8px; height:42px; background:#faf5ff; border:1px solid #e9d5ff; color:#6d28d9; font-weight:700; border-radius:8px;">
                            <span>📥 Submissions</span>
                        </a>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-analytics')); ?>" class="button" style="display:flex; align-items:center; justify-content:center; gap:8px; height:42px; background:#eff6ff; border:1px solid #bfdbfe; color:#1d4ed8; font-weight:700; border-radius:8px;">
                            <span>📊 Analytics</span>
                        </a>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-settings')); ?>" class="button" style="display:flex; align-items:center; justify-content:center; gap:8px; height:42px; background:#f0fdf4; border:1px solid #bbf7d0; color:#15803d; font-weight:700; border-radius:8px;">
                            <span>⚙️ Settings</span>
                        </a>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-docs')); ?>" class="button" style="display:flex; align-items:center; justify-content:center; gap:8px; height:42px; background:#fff7ed; border:1px solid #fed7aa; color:#c2410c; font-weight:700; border-radius:8px;">
                            <span>📖 Docs & Guide</span>
                        </a>
                        <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=evonee-submissions&action=export_csv'), 'eq_export_csv_nonce')); ?>" class="button" style="display:flex; align-items:center; justify-content:center; gap:8px; height:42px; background:#f8fafc; border:1px solid #cbd5e1; color:#334155; font-weight:700; border-radius:8px;">
                            <span>📥 Export CSV</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Two-Column Main Body -->
            <div style="display:grid; grid-template-columns:2fr 1fr; gap:24px;">
                <!-- Left Column -->
                <div>
                    <!-- Recent Submissions Card -->
                    <div class="evonee-doc-card" style="margin-bottom:24px;">
                        <div class="evonee-card-header" style="padding:14px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; border-top-left-radius:12px; border-top-right-radius:12px; display:flex; justify-content:space-between; align-items:center;">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <span class="dashicons dashicons-list-view" style="color:#6d28d9;"></span>
                                <h2 style="font-size:14px; font-weight:700; color:#1e293b; margin:0;">📋 Recent Quote Submissions</h2>
                            </div>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-submissions')); ?>" style="font-size:12px; font-weight:700; color:#6d28d9; text-decoration:none;">View All Submissions &rarr;</a>
                        </div>
                        <div class="evonee-card-body" style="padding:0;">
                            <?php if (!empty($recent_quotes)): ?>
                                <table class="wp-list-table widefat fixed striped" style="border:none; box-shadow:none;">
                                    <thead>
                                        <tr>
                                            <th style="font-size:11px; text-transform:uppercase; color:#64748b;">ID / Date</th>
                                            <th style="font-size:11px; text-transform:uppercase; color:#64748b;">Customer</th>
                                            <th style="font-size:11px; text-transform:uppercase; color:#64748b;">Product</th>
                                            <th style="font-size:11px; text-transform:uppercase; color:#64748b;">Status</th>
                                            <th style="font-size:11px; text-transform:uppercase; color:#64748b; text-align:right;">Quoted Price</th>
                                            <th style="font-size:11px; text-transform:uppercase; color:#64748b; text-align:right;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_quotes as $q):
                                            $sc_colors = ['new' => '#16a34a', 'pending' => '#d97706', 'quoted' => '#2563eb', 'approved' => '#7c3aed', 'completed' => '#059669', 'rejected' => '#dc2626'];
                                            $sc_bg = isset($sc_colors[strtolower($q->status)]) ? $sc_colors[strtolower($q->status)] : '#6b7280';
                                        ?>
                                            <tr>
                                                <td>
                                                    <strong>#<?php echo esc_html($q->id); ?></strong><br>
                                                    <small style="color:#94a3b8;"><?php echo esc_html(wp_date('M j, H:i', strtotime($q->created_at))); ?></small>
                                                </td>
                                                <td>
                                                    <strong><?php echo esc_html($q->full_name); ?></strong><br>
                                                    <small style="color:#64748b;"><?php echo esc_html($q->email); ?></small>
                                                </td>
                                                <td>
                                                    <?php echo esc_html($q->product); ?><br>
                                                    <small style="color:#64748b;">Qty: <?php echo esc_html($q->quantity); ?></small>
                                                </td>
                                                <td>
                                                    <span style="background:<?php echo esc_attr($sc_bg); ?>; color:#ffffff; border-radius:4px; padding:3px 8px; font-size:10px; font-weight:700; text-transform:uppercase;">
                                                        <?php echo esc_html($q->status ?: 'new'); ?>
                                                    </span>
                                                </td>
                                                <td style="text-align:right; font-weight:700; color:#0f172a;">
                                                    <?php echo (!empty($q->quoted_price) && floatval($q->quoted_price) > 0) ? esc_html($curr_sym) . number_format($q->quoted_price, 2) : '<span style="color:#94a3b8; font-weight:normal;">Unquoted</span>'; ?>
                                                </td>
                                                <td style="text-align:right;">
                                                    <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-submissions&view_id=' . intval($q->id))); ?>" class="button button-small" style="background:#faf5ff; border-color:#e9d5ff; color:#6d28d9; font-weight:700;" title="View Detail & Reply">
                                                        👁️ View
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p style="padding:20px; text-align:center; color:#94a3b8; margin:0;">No quote submissions received yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Mini Trend Graph Card -->
                    <div class="evonee-doc-card">
                        <div class="evonee-card-header" style="padding:14px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; border-top-left-radius:12px; border-top-right-radius:12px; display:flex; align-items:center; gap:8px;">
                            <span class="dashicons dashicons-chart-bar" style="color:#6d28d9;"></span>
                            <h2 style="font-size:14px; font-weight:700; color:#1e293b; margin:0;">📈 6-Month Lead Growth Trend</h2>
                        </div>
                        <div class="evonee-card-body" style="padding:20px;">
                            <canvas id="dashTrendChart" style="max-height:220px;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Right Column -->
                <div>
                    <!-- Live Audit Activity Feed Card -->
                    <div class="evonee-doc-card" style="margin-bottom:24px;">
                        <div class="evonee-card-header" style="padding:14px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; border-top-left-radius:12px; border-top-right-radius:12px; display:flex; align-items:center; gap:8px;">
                            <span class="dashicons dashicons-rss" style="color:#6d28d9;"></span>
                            <h2 style="font-size:14px; font-weight:700; color:#1e293b; margin:0;">⚡ Live Customer & Audit Activity</h2>
                        </div>
                        <div class="evonee-card-body" style="padding:14px 20px;">
                            <?php
                            global $wpdb;
                            $act_table = $wpdb->prefix . 'eq_quote_activity_log';
                            $recent_acts = [];
                            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $act_table)) === $act_table) {
                                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                                $recent_acts = $wpdb->get_results("SELECT * FROM {$act_table} ORDER BY id DESC LIMIT 5");
                            }
                            ?>
                            <?php if (!empty($recent_acts)): ?>
                                <ul style="margin:0; padding:0; list-style:none; display:flex; flex-direction:column; gap:10px;">
                                    <?php foreach ($recent_acts as $act): ?>
                                        <li style="font-size:12px; border-bottom:1px solid #f1f5f9; padding-bottom:8px;">
                                            <div style="font-weight:700; color:#0f172a; margin-bottom:2px; display:flex; justify-content:space-between;">
                                                <span>Quote #<?php echo esc_html($act->quote_id); ?> — <?php echo esc_html(ucwords(str_replace('_', ' ', $act->action))); ?></span>
                                                <small style="color:#94a3b8;"><?php echo esc_html(wp_date('M j, H:i', strtotime($act->created_at))); ?></small>
                                            </div>
                                            <div style="color:#64748b; font-size:11.5px;"><?php echo esc_html($act->details); ?></div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <p style="font-size:12px; color:#94a3b8; text-align:center; margin:10px 0;">No activity logs recorded yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- System Health Diagnostic Card -->
                    <div class="evonee-doc-card" style="margin-bottom:24px;">
                        <div class="evonee-card-header" style="padding:14px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; border-top-left-radius:12px; border-top-right-radius:12px; display:flex; align-items:center; gap:8px;">
                            <span class="dashicons dashicons-heart" style="color:#6d28d9;"></span>
                            <h2 style="font-size:14px; font-weight:700; color:#1e293b; margin:0;">🩺 System Health & Integrations</h2>
                        </div>
                        <div class="evonee-card-body" style="padding:16px 20px;">
                            <ul style="margin:0; padding:0; list-style:none;">
                                <li style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #f1f5f9; font-size:13px;">
                                    <span>⏱️ <strong>WP-Cron Expiry Automation</strong></span>
                                    <?php if ($cron_active): ?>
                                        <span style="background:#dcfce7; color:#15803d; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Active ✓</span>
                                    <?php else: ?>
                                        <span style="background:#fee2e2; color:#b91c1c; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Inactive ⚠</span>
                                    <?php endif; ?>
                                </li>
                                <li style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #f1f5f9; font-size:13px;">
                                    <span>🛒 <strong>WooCommerce Engine</strong></span>
                                    <?php if ($wc_active): ?>
                                        <span style="background:#dcfce7; color:#15803d; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Connected ✓</span>
                                    <?php else: ?>
                                        <span style="background:#f1f5f9; color:#64748b; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Not Installed</span>
                                    <?php endif; ?>
                                </li>
                                <li style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #f1f5f9; font-size:13px;">
                                    <span>🛡️ <strong>reCAPTCHA v3 Protection</strong></span>
                                    <?php if ($recaptcha_ready): ?>
                                        <span style="background:#dcfce7; color:#15803d; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Protected ✓</span>
                                    <?php else: ?>
                                        <span style="background:#fef3c7; color:#b45309; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Disabled</span>
                                    <?php endif; ?>
                                </li>
                                <li style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #f1f5f9; font-size:13px;">
                                    <span>🔗 <strong>Webhook / Zapier Catch</strong></span>
                                    <?php if ($webhook_ready): ?>
                                        <span style="background:#dcfce7; color:#15803d; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Connected ✓</span>
                                    <?php else: ?>
                                        <span style="background:#f1f5f9; color:#64748b; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Off</span>
                                    <?php endif; ?>
                                </li>
                                <li style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; font-size:13px;">
                                    <span>💬 <strong>Slack Lead Channel</strong></span>
                                    <?php if ($slack_ready): ?>
                                        <span style="background:#dcfce7; color:#15803d; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Connected ✓</span>
                                    <?php else: ?>
                                        <span style="background:#f1f5f9; color:#64748b; border-radius:12px; padding:2px 10px; font-size:11px; font-weight:700;">Off</span>
                                    <?php endif; ?>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!-- Top Requested Products Widget -->
                    <div class="evonee-doc-card">
                        <div class="evonee-card-header" style="padding:14px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; border-top-left-radius:12px; border-top-right-radius:12px; display:flex; align-items:center; gap:8px;">
                            <span class="dashicons dashicons-star-filled" style="color:#d97706;"></span>
                            <h2 style="font-size:14px; font-weight:700; color:#1e293b; margin:0;">🔥 Top Demanded Products</h2>
                        </div>
                        <div class="evonee-card-body" style="padding:16px 20px;">
                            <?php if (!empty($top_products)): ?>
                                <?php foreach ($top_products as $tp):
                                    $pct = $total_count > 0 ? round(($tp->total / $total_count) * 100) : 0;
                                ?>
                                    <div style="margin-bottom:14px;">
                                        <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:4px;">
                                            <strong><?php echo esc_html($tp->product); ?></strong>
                                            <span style="color:#64748b; font-weight:600;"><?php echo esc_html($tp->total); ?> quotes (<?php echo esc_html($pct); ?>%)</span>
                                        </div>
                                        <div style="background:#f1f5f9; border-radius:10px; height:8px; overflow:hidden;">
                                            <div style="background:linear-gradient(90deg, #6d28d9 0%, #7c3aed 100%); height:100%; width:<?php echo esc_attr($pct); ?>%; border-radius:10px;"></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="color:#94a3b8; font-size:12px; text-align:center; margin:0;">No product data available yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const trendCtx = document.getElementById('dashTrendChart');
            if (trendCtx) {
                const trendLabels = <?php echo json_encode(array_column($monthly_trends, 'month_label') ?: ['Current']); ?>;
                const trendData   = <?php echo json_encode(array_map('intval', array_column($monthly_trends, 'total')) ?: [$total_count]); ?>;

                new Chart(trendCtx, {
                    type: 'line',
                    data: {
                        labels: trendLabels,
                        datasets: [{
                            label: 'Quote Submissions',
                            data: trendData,
                            borderColor: '#6d28d9',
                            backgroundColor: 'rgba(109, 40, 217, 0.08)',
                            borderWidth: 3,
                            fill: true,
                            tension: 0.3,
                            pointBackgroundColor: '#6d28d9',
                            pointRadius: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            y: { beginAtZero: true, grid: { color: '#f1f5f9' } },
                            x: { grid: { display: false } }
                        }
                    }
                });
            }
        });
        </script>
        <?php
    }

    /**
     * Render Quote Submissions Viewer Page (Full CRM Submissions Suite)
     */
    public function render_submissions_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) !== $table_name) {
            Evonee_Quote_Ajax::create_submissions_table();
        }

        // Handle CSV Export
        if (isset($_GET['action']) && $_GET['action'] === 'export_csv') {
            if (!current_user_can('manage_options')) {
                wp_die('Unauthorized action.');
            }
            if (!check_admin_referer('eq_export_csv_nonce')) {
                wp_die('Security check failed.');
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}eq_quote_submissions ORDER BY id DESC", ARRAY_A);

            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=evonee_quote_submissions_' . gmdate('Y-m-d_H-i') . '.csv');

            $output = fopen('php://output', 'w');

            // UTF-8 BOM for Excel compatibility
            fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

            // Column Headers
            fputcsv($output, ['ID', 'Date', 'Customer Name', 'Company', 'Email', 'Phone', 'Country', 'Product', 'Quantity', 'Product Details', 'Delivery Timeframe', 'Need Date', 'ZIP Code', 'Artwork URL', 'Project Notes', 'Quoted Price', 'Status']);

            if (!empty($rows)) {
                foreach ($rows as $row) {
                    $art_urls = Evonee_Quote_Ajax::parse_artwork_urls($row['artwork_url'] ?? '');
                    fputcsv($output, [
                        $row['id'],
                        $row['created_at'],
                        $row['full_name'],
                        $row['company'],
                        $row['email'],
                        $row['phone'],
                        $row['country'],
                        $row['product'],
                        $row['quantity'],
                        Evonee_Quote_Ajax::format_product_details_text($row['product_details'] ?? ''),
                        $row['timeframe'],
                        $row['specific_date'],
                        $row['zip_code'],
                        implode(' | ', $art_urls),
                        $row['project_notes'],
                        $row['quoted_price'] ?? '',
                        strtoupper(isset($row['status']) ? $row['status'] : 'new')
                    ]);
                }
            }

            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
            fclose($output);
            exit;
        }

        // Handle PDF Quote Sheet Generation & Printing
        if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'generate_pdf_quote') {
            if (!current_user_can('manage_options')) {
                wp_die('Unauthorized action.');
            }
            if (!check_admin_referer('eq_generate_pdf_' . intval($_GET['id']))) {
                wp_die('Security check failed.');
            }

            $quote_id = intval($_GET['id']);
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $quote = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}eq_quote_submissions WHERE id = %d", $quote_id));

            if (!$quote) {
                wp_die('Quote submission not found.');
            }

            ?>
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <title>Evonee Official Quote Sheet #<?php echo esc_html($quote->id); ?></title>
                <style>
                    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f8fafc; color: #1e1b2e; margin: 0; padding: 40px; }
                    .pdf-wrap { max-width: 800px; margin: 0 auto; background: #ffffff; padding: 40px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
                    .pdf-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #6d28d9; padding-bottom: 20px; margin-bottom: 30px; }
                    .pdf-logo { font-size: 28px; font-weight: 800; color: #6d28d9; }
                    .pdf-meta { text-align: right; font-size: 13px; color: #64748b; }
                    .pdf-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px; }
                    .pdf-card { background: #faf9fd; border: 1px solid #e5e0f5; padding: 18px; border-radius: 8px; }
                    .pdf-card h3 { margin: 0 0 10px; font-size: 14px; color: #4c1d95; text-transform: uppercase; letter-spacing: 0.05em; }
                    .pdf-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
                    .pdf-table th { background: #6d28d9; color: #ffffff; text-align: left; padding: 12px; font-size: 13px; }
                    .pdf-table td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
                    .pdf-terms { background: #f1f5f9; padding: 16px; border-radius: 8px; font-size: 12px; color: #64748b; margin-top: 30px; }
                    .pdf-actions { margin-bottom: 20px; text-align: right; }
                    .btn-print { background: #6d28d9; color: #fff; padding: 10px 20px; border: none; border-radius: 6px; font-size: 14px; font-weight: 700; cursor: pointer; text-decoration: none; }
                    @media print { .pdf-actions { display: none; } body { padding: 0; background: #fff; } .pdf-wrap { border: none; box-shadow: none; } }
                </style>
            </head>
            <body>
                <div class="pdf-actions">
                    <button type="button" class="btn-print" onclick="window.print();">🖨️ Print / Save as PDF</button>
                </div>
                <div class="pdf-wrap">
                    <div class="pdf-header">
                        <?php
                        $pdf_settings = self::get_settings();
                        $pdf_logo = !empty($pdf_settings['email_logo_url']) ? esc_url($pdf_settings['email_logo_url']) : '';
                        $pdf_brand = !empty($pdf_settings['email_brand_name']) ? esc_html($pdf_settings['email_brand_name']) : 'EVONEE';
                        ?>
                        <div>
                            <?php if (!empty($pdf_logo)): ?>
                                <img src="<?php echo esc_url($pdf_logo); ?>" alt="<?php echo esc_attr($pdf_brand); ?>" style="max-height:50px; display:block; margin-bottom:6px;">
                            <?php else: ?>
                                <div class="pdf-logo"><?php echo esc_html(strtoupper($pdf_brand)); ?></div>
                            <?php endif; ?>
                            <div style="font-size:12px; color:#64748b; margin-top:4px;"><?php echo esc_html($pdf_brand); ?> Promotional Products & Custom Goods</div>
                        </div>
                        <div class="pdf-meta">
                            <strong style="font-size:16px; color:#1e1b2e;">OFFICIAL QUOTE #<?php echo esc_html($quote->id); ?></strong><br>
                            Date: <?php echo esc_html(wp_date('F d, Y', strtotime($quote->created_at))); ?><br>
                            Valid Until: <?php echo esc_html(wp_date('F d, Y', strtotime('+30 days', strtotime($quote->created_at)))); ?>
                        </div>
                    </div>

                    <div class="pdf-grid">
                        <div class="pdf-card">
                            <h3>Bill To (Customer Information)</h3>
                            <strong><?php echo esc_html($quote->full_name); ?></strong><br>
                            <?php if (!empty($quote->company)): ?>Company: <?php echo esc_html($quote->company); ?><br><?php endif; ?>
                            Email: <?php echo esc_html($quote->email); ?><br>
                            Phone: <?php echo esc_html($quote->phone); ?><br>
                            Country: <?php echo esc_html($quote->country); ?><br>
                            ZIP Code: <?php echo esc_html($quote->zip_code); ?>
                        </div>
                        <div class="pdf-card">
                            <h3>Quotation Details</h3>
                            Product: <strong><?php echo esc_html($quote->product); ?></strong><br>
                            Quantity: <strong><?php echo esc_html($quote->quantity); ?></strong><br>
                            Delivery Timeframe: <?php echo esc_html($quote->timeframe); ?><br>
                            <?php if (!empty($quote->specific_date)): ?>Need By Date: <strong><?php echo esc_html($quote->specific_date); ?></strong><br><?php endif; ?>
                            Status: <span style="color:#6d28d9; font-weight:700; text-transform:uppercase;"><?php echo esc_html($quote->status ?: 'new'); ?></span>
                            <?php
                            $pdf_details = Evonee_Quote_Ajax::parse_product_details($quote->product_details ?? '');
                            if (!empty($pdf_details)):
                                foreach ($pdf_details as $dkey => $dval):
                                    if ($dval === '' || $dval === null) {
                                        continue;
                                    }
                                    $dlabel = ucwords(str_replace('_', ' ', (string) $dkey));
                                    $dvalue = is_array($dval) ? implode(', ', $dval) : (string) $dval;
                            ?>
                            <br><?php echo esc_html($dlabel); ?>: <?php echo esc_html($dvalue); ?>
                            <?php
                                endforeach;
                            endif;
                            ?>
                        </div>
                    </div>

                    <table class="pdf-table">
                        <thead>
                            <tr>
                                <th>Item Description</th>
                                <th>Quantity</th>
                                <th>Timeframe</th>
                                <th>Status</th>
                                <th>Price Offer</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <strong>Custom <?php echo esc_html($quote->product); ?></strong>
                                    <?php if (!empty($quote->project_notes)): ?>
                                        <br><small style="color:#64748b;"><?php echo esc_html($quote->project_notes); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($quote->quantity); ?></td>
                                <td><?php echo esc_html($quote->timeframe); ?></td>
                                <td><?php echo esc_html(strtoupper($quote->status ?: 'NEW')); ?></td>
                                <td><strong><?php echo (!empty($quote->quoted_price) && floatval($quote->quoted_price) > 0) ? '$' . number_format($quote->quoted_price, 2) : 'Included in Offer'; ?></strong></td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="pdf-terms">
                        <strong>📌 Terms & Conditions:</strong><br>
                        1. Includes Free Digital Proof & Mockup preview before production.<br>
                        2. Price offer valid for 30 days from quote issue date.<br>
                        3. Standard production & delivery timeline applies upon artwork approval.
                    </div>

                    <?php if (!empty($quote->digital_signature)): ?>
                        <div style="margin-top:20px; padding:12px; border:1px dashed #cbd5e1; border-radius:8px; display:inline-block; background:#fafafa;">
                            <strong style="font-size:11px; color:#475569; display:block;">✍️ Customer Acceptance Signature:</strong>
                            <img src="<?php echo esc_url($quote->digital_signature); ?>" style="max-height:60px; margin-top:4px;">
                        </div>
                    <?php endif; ?>
                </div>
            </body>
            </html>
            <?php
            exit;
        }

        // Handle Single Deletion
        if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete' && check_admin_referer('delete_quote_' . intval($_GET['id']))) {
            $delete_id = intval($_GET['id']);
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->delete($table_name, ['id' => $delete_id], ['%d']);
            wp_safe_redirect(admin_url('admin.php?page=evonee-submissions&eq_notice=deleted&eq_id=' . $delete_id));
            exit;
        }

        // Handle Status Update
        if (isset($_POST['eq_action'], $_POST['sub_id'], $_POST['status']) && $_POST['eq_action'] === 'update_status' && check_admin_referer('eq_update_status')) {
            $sub_id     = intval($_POST['sub_id']);
            $new_status = sanitize_text_field(wp_unslash($_POST['status']));
            $allowed_statuses = ['new', 'pending', 'quoted', 'approved', 'completed', 'rejected'];
            if (!in_array($new_status, $allowed_statuses, true)) {
                $new_status = 'new';
            }
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update($table_name, ['status' => $new_status], ['id' => $sub_id], ['%s'], ['%d']);
            Evonee_Quote_Ajax::log_activity($sub_id, 'status_change', 'Status updated to ' . strtoupper($new_status));
            wp_safe_redirect(admin_url('admin.php?page=evonee-submissions&eq_notice=status&eq_id=' . $sub_id));
            exit;
        }

        // Handle Direct Customer Email Reply
        if (isset($_POST['eq_action'], $_POST['sub_id'], $_POST['customer_email'], $_POST['email_subject'], $_POST['email_body']) && $_POST['eq_action'] === 'send_customer_reply' && check_admin_referer('eq_send_reply')) {
            $sub_id         = intval($_POST['sub_id']);
            $customer_email = sanitize_email(wp_unslash($_POST['customer_email']));
            $subject        = sanitize_text_field(wp_unslash($_POST['email_subject']));
            $reply_body     = wp_kses_post(wp_unslash($_POST['email_body']));

            // Generate Token for Quote Acceptance (Phase 3.1)
            $token  = wp_generate_password(32, false);
            $expiry = gmdate('Y-m-d H:i:s', time() + (30 * DAY_IN_SECONDS));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update($table_name, ['acceptance_token' => $token, 'token_expiry' => $expiry], ['id' => $sub_id], ['%s', '%s'], ['%d']);

            $accept_url  = add_query_arg(['eq_action' => 'accept_quote', 'token' => $token], home_url());
            $decline_url = add_query_arg(['eq_action' => 'decline_quote', 'token' => $token], home_url());

            $sales_email = Evonee_Quote_Ajax::get_sales_email();
            $headers = [
                'Content-Type: text/html; charset=UTF-8',
                'From: Evonee Sales <' . $sales_email . '>',
                'Reply-To: ' . $sales_email
            ];

            $mail_body = '
            <!DOCTYPE html>
            <html>
            <head><meta charset="UTF-8"></head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #1e1b2e; background-color: #f8fafc; padding: 20px;">
                <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 10px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
                    <div style="background: #6d28d9; padding: 20px 24px; color: #ffffff;">
                        <h2 style="margin:0; font-size: 20px;">Evonee Custom Quote Response</h2>
                    </div>
                    <div style="padding: 24px; color: #334155;">
                        ' . nl2br($reply_body) . '
                    </div>
                    <div style="padding: 20px 24px; background: #faf5ff; border-top: 1px solid #f3e8ff; text-align: center;">
                        <p style="margin:0 0 12px; font-weight:bold; color:#4c1d95; font-size:14px;">Ready to proceed with this quote?</p>
                        <a href="' . esc_url($accept_url) . '" style="display:inline-block; background:#16a34a; color:#ffffff; padding:10px 20px; border-radius:6px; font-weight:bold; text-decoration:none; margin-right:10px;">✅ Accept Quote</a>
                        <a href="' . esc_url($decline_url) . '" style="display:inline-block; background:#dc2626; color:#ffffff; padding:10px 16px; border-radius:6px; font-weight:bold; text-decoration:none;">❌ Decline Quote</a>
                    </div>
                    <div style="background: #f1f5f9; padding: 14px 24px; font-size: 12px; color: #64748b; text-align: center;">
                        Evonee Promotional Products &bull; <a href="mailto:' . esc_attr($sales_email) . '" style="color:#6d28d9;">' . esc_html($sales_email) . '</a>
                    </div>
                </div>
            </body>
            </html>';

            $sent = wp_mail($customer_email, $subject, $mail_body, $headers);
            Evonee_Quote_Ajax::log_email($sub_id, $customer_email, $subject, 'admin_reply', $sent ? 'sent' : 'failed');

            if ($sent) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $wpdb->update($table_name, ['status' => 'quoted'], ['id' => $sub_id], ['%s'], ['%d']);
                Evonee_Quote_Ajax::log_activity($sub_id, 'status_change', 'Status updated to QUOTED via Email Reply');
                wp_safe_redirect(admin_url('admin.php?page=evonee-submissions&eq_notice=email_sent'));
                exit;
            }
            wp_safe_redirect(admin_url('admin.php?page=evonee-submissions&eq_notice=email_failed'));
            exit;
        }

        // Handle Bulk Deletion / Bulk Status Update
        if (isset($_POST['bulk_action'], $_POST['bulk_ids']) && !empty($_POST['bulk_ids']) && check_admin_referer('eq_bulk_action')) {
            $bulk_ids = array_map('intval', (array) wp_unslash($_POST['bulk_ids']));
            $bulk_ids = array_filter($bulk_ids);
            $action   = sanitize_text_field(wp_unslash($_POST['bulk_action']));

            if (!empty($bulk_ids) && $action === 'delete') {
                $placeholders = implode(',', array_fill(0, count($bulk_ids), '%d'));
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter
                $wpdb->query($wpdb->prepare("DELETE FROM {$table_name} WHERE id IN ($placeholders)", ...$bulk_ids));
                wp_safe_redirect(admin_url('admin.php?page=evonee-submissions&eq_notice=bulk_deleted&eq_count=' . count($bulk_ids)));
                exit;
            } elseif (!empty($bulk_ids) && in_array($action, ['status_new', 'status_pending', 'status_quoted', 'status_approved', 'status_completed', 'status_rejected'], true)) {
                $status_val = str_replace('status_', '', $action);
                $placeholders = implode(',', array_fill(0, count($bulk_ids), '%d'));
                $query_args = array_merge([$status_val], $bulk_ids);
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter
                $wpdb->query($wpdb->prepare("UPDATE {$table_name} SET status = %s WHERE id IN ($placeholders)", ...$query_args));
                foreach ($bulk_ids as $bid) {
                    Evonee_Quote_Ajax::log_activity($bid, 'status_change', 'Bulk status update to ' . strtoupper($status_val));
                }
                wp_safe_redirect(admin_url('admin.php?page=evonee-submissions&eq_notice=bulk_status'));
                exit;
            }
        }

        // Search, Date & Status Filter Query
        $search        = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $status_filter = isset($_GET['status_filter']) ? sanitize_text_field(wp_unslash($_GET['status_filter'])) : '';
        $date_range    = isset($_GET['date_range']) ? sanitize_text_field(wp_unslash($_GET['date_range'])) : '';

        // Column Sorting (Phase 2.5)
        $allowed_orderby = ['id', 'created_at', 'full_name', 'product', 'quantity', 'status', 'follow_up_date', 'quoted_price'];
        $raw_orderby     = isset($_GET['orderby']) ? sanitize_text_field(wp_unslash($_GET['orderby'])) : 'id';
        $orderby         = in_array($raw_orderby, $allowed_orderby, true) ? $raw_orderby : 'id';
        $raw_order       = isset($_GET['order']) ? sanitize_text_field(wp_unslash($_GET['order'])) : 'DESC';
        $order           = strtoupper($raw_order) === 'ASC' ? 'ASC' : 'DESC';

        // Pagination
        $allowed_per_page = [20, 50, 100];
        $per_page  = isset($_GET['per_page']) ? intval($_GET['per_page']) : 20;
        if (!in_array($per_page, $allowed_per_page)) $per_page = 20;
        $current_page = max(1, isset($_GET['paged']) ? intval($_GET['paged']) : 1);
        $offset       = ($current_page - 1) * $per_page;

        $where_clauses = [];
        if (!empty($search)) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where_clauses[] = $wpdb->prepare("(full_name LIKE %s OR email LIKE %s OR phone LIKE %s OR product LIKE %s OR company LIKE %s OR zip_code LIKE %s)", $like, $like, $like, $like, $like, $like);
        }
        if (!empty($status_filter)) {
            $where_clauses[] = $wpdb->prepare("status = %s", $status_filter);
        }

        // Date Range Filtering
        if ($date_range === 'today') {
            $where_clauses[] = $wpdb->prepare("DATE(created_at) = %s", current_time('Y-m-d'));
        } elseif ($date_range === 'last_7_days') {
            $where_clauses[] = $wpdb->prepare("created_at >= %s", wp_date('Y-m-d H:i:s', time() - (7 * DAY_IN_SECONDS)));
        } elseif ($date_range === 'this_month') {
            $where_clauses[] = $wpdb->prepare("created_at >= %s", wp_date('Y-m-01 00:00:00'));
        } elseif ($date_range === 'followup_due') {
            $where_clauses[] = $wpdb->prepare("follow_up_date IS NOT NULL AND follow_up_date <= %s", current_time('Y-m-d'));
        }

        $where_sql   = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $total_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions $where_sql");
        $total_pages = $per_page > 0 ? (int) ceil($total_count / $per_page) : 1;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $results    = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}eq_quote_submissions $where_sql ORDER BY " . sanitize_sql_orderby("$orderby $order") . " LIMIT %d OFFSET %d", $per_page, $offset));
        $export_url = wp_nonce_url(admin_url('admin.php?page=evonee-submissions&action=export_csv'), 'eq_export_csv_nonce');
        ?>
        <div class="wrap evonee-admin-wrap">
            <?php
            if (isset($_GET['eq_notice'])) {
                $notice = sanitize_text_field(wp_unslash($_GET['eq_notice']));
                $nid    = isset($_GET['eq_id']) ? intval($_GET['eq_id']) : 0;
                $ncount = isset($_GET['eq_count']) ? intval($_GET['eq_count']) : 0;
                $msgs   = [
                    'deleted'       => 'Submission #' . $nid . ' deleted successfully.',
                    'status'        => 'Submission #' . $nid . ' status updated.',
                    'email_sent'    => 'Quote reply email sent successfully. Status updated to QUOTED.',
                    'email_failed'  => 'Failed to send email. Please check your WordPress email server settings.',
                    'bulk_deleted'  => $ncount . ' submissions deleted successfully.',
                    'bulk_status'   => 'Selected submissions updated.',
                ];
                if (isset($msgs[$notice])) {
                    $class = ($notice === 'email_failed') ? 'notice-error' : 'notice-success';
                    echo '<div class="notice ' . esc_attr($class) . ' is-dismissible"><p>' . esc_html($msgs[$notice]) . '</p></div>';
                }
            }
            ?>
            <div class="evonee-admin-header">
                <div>
                    <h1 class="wp-heading-inline">📥 Evonee Quote Submissions</h1>
                    <p class="subtitle">Manage customer quote requests, track quotation status, export reports, and send email replies directly.</p>
                </div>
                <div class="evonee-header-actions">
                    <a href="<?php echo esc_url($export_url); ?>" class="button button-primary button-large" style="background:#16a34a; border-color:#16a34a;">📊 Export to CSV</a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-docs')); ?>" class="button button-secondary button-large">📖 Documentation & Help</a>
                </div>
            </div>

            <!-- Search & Filter Bar -->
            <div class="evonee-filter-bar">
                <form method="get" class="evonee-filter-form">
                    <input type="hidden" name="page" value="evonee-submissions">
                    
                    <div class="evonee-filter-group">
                        <select name="status_filter" onchange="this.form.submit();">
                            <option value="">All Statuses</option>
                            <option value="new" <?php selected($status_filter, 'new'); ?>>🟢 New</option>
                            <option value="pending" <?php selected($status_filter, 'pending'); ?>>🟡 Pending</option>
                            <option value="quoted" <?php selected($status_filter, 'quoted'); ?>>🔵 Quoted</option>
                            <option value="approved" <?php selected($status_filter, 'approved'); ?>>💜 Approved</option>
                            <option value="completed" <?php selected($status_filter, 'completed'); ?>>💚 Completed</option>
                            <option value="rejected" <?php selected($status_filter, 'rejected'); ?>>🔴 Rejected</option>
                        </select>

                        <select name="date_range" onchange="this.form.submit();">
                            <option value="">All Time</option>
                            <option value="today" <?php selected($date_range, 'today'); ?>>📅 Today</option>
                            <option value="last_7_days" <?php selected($date_range, 'last_7_days'); ?>>🗓️ Last 7 Days</option>
                            <option value="this_month" <?php selected($date_range, 'this_month'); ?>>📆 This Month</option>
                            <option value="followup_due" <?php selected($date_range, 'followup_due'); ?>>⏰ Follow-up Due</option>
                        </select>

                        <div class="evonee-search-input">
                            <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search by name, email, phone, product...">
                            <button type="submit" class="button">Search</button>
                        </div>

                        <button type="button" id="eq-run-drip-btn" class="button" style="background:#faf5ff; border-color:#d8b4fe; color:#6d28d9; font-weight:700; height:30px;">⏰ Run Drip Engine</button>

                        <?php if (!empty($search) || !empty($status_filter) || !empty($date_range)): ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-submissions')); ?>" class="button button-link-delete">Reset Filters</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="evonee-admin-card">
                <?php if (empty($results)): ?>
                    <div class="evonee-empty-state">
                        <span class="dashicons dashicons-email-alt" style="font-size: 48px; width: 48px; height: 48px; color: #6d28d9;"></span>
                        <h3>No Submissions Found</h3>
                        <p>No quote submissions match your filter or search criteria.</p>
                    </div>
                <?php else: ?>
                    <form method="post" id="eq-bulk-form">
                        <?php wp_nonce_field('eq_bulk_action'); ?>
                        
                        <div class="evonee-bulk-actions">
                            <select name="bulk_action">
                                <option value="">Bulk Actions</option>
                                <option value="delete">Delete Selected</option>
                                <option value="status_new">Mark as New</option>
                                <option value="status_pending">Mark as Pending</option>
                                <option value="status_quoted">Mark as Quoted</option>
                                <option value="status_approved">Mark as Approved</option>
                                <option value="status_completed">Mark as Completed</option>
                            </select>
                            <button type="submit" onclick="return confirm('Apply bulk action to selected items?');" class="button">Apply</button>
                            <div class="evonee-pagination-info" style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                                <span class="evonee-count-tag"><?php echo esc_html($total_count); ?> Total Submissions</span>
                                <span style="color:#94a3b8; font-size:12px;">
                                    Showing <?php echo esc_html(min(($offset + 1), $total_count)); ?>–<?php echo esc_html(min($offset + $per_page, $total_count)); ?> of <?php echo esc_html($total_count); ?>
                                </span>
                                <span style="display:inline-flex; align-items:center; gap:4px; margin:0;">
                                    <label style="font-size:12px; color:#64748b;">Per page:</label>
                                    <select name="per_page" form="eq-per-page-form" onchange="document.getElementById('eq-per-page-form').submit();" style="font-size:12px; padding:2px 4px;">
                                        <?php foreach ([20, 50, 100] as $pp): ?>
                                            <option value="<?php echo esc_attr($pp); ?>" <?php selected($per_page, $pp); ?>><?php echo esc_html($pp); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </span>
                            </div>
                        </div>

                        <?php
                        $sort_link = function($col, $title) use ($orderby, $order, $search, $status_filter, $date_range, $per_page) {
                            $next_order = ($orderby === $col && $order === 'ASC') ? 'DESC' : 'ASC';
                            $url = admin_url('admin.php?' . http_build_query(array_filter([
                                'page'          => 'evonee-quotes',
                                'orderby'       => $col,
                                'order'         => $next_order,
                                's'             => $search,
                                'status_filter' => $status_filter,
                                'date_range'    => $date_range,
                                'per_page'      => $per_page
                            ])));
                            $icon = ($orderby === $col) ? ($order === 'ASC' ? ' ▲' : ' ▼') : '';
                            return sprintf('<a href="%s" style="color:inherit; text-decoration:none;">%s%s</a>', esc_url($url), esc_html($title), esc_html($icon));
                        };
                        ?>
                        <table class="wp-list-table widefat fixed striped evonee-submissions-table">
                            <thead>
                                <tr>
                                    <th style="width: 32px;"><input type="checkbox" id="eq-select-all"></th>
                                    <th style="width: 60px;"><?php echo wp_kses_post($sort_link('id', 'ID')); ?></th>
                                    <th style="width: 140px;"><?php echo wp_kses_post($sort_link('created_at', 'Date')); ?></th>
                                    <th><?php echo wp_kses_post($sort_link('full_name', 'Customer & Company')); ?></th>
                                    <th>Contact Info</th>
                                    <th><?php echo wp_kses_post($sort_link('product', 'Product')); ?></th>
                                    <th style="width: 60px;"><?php echo wp_kses_post($sort_link('quantity', 'Qty')); ?></th>
                                    <th style="width: 100px;"><?php echo wp_kses_post($sort_link('quoted_price', 'Offer Price')); ?></th>
                                    <th>Delivery & Follow-up</th>
                                    <th>Artwork</th>
                                    <th style="width: 110px;"><?php echo wp_kses_post($sort_link('status', 'Status')); ?></th>
                                    <th style="width: 170px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $row_settings = self::get_settings();
                                $show_pdf_btn = (!isset($row_settings['enable_pdf_quote']) || $row_settings['enable_pdf_quote'] === '1');
                                foreach ($results as $row):
                                    $st = isset($row->status) ? strtolower($row->status) : 'new';
                                ?>
                                    <tr data-row='<?php echo esc_attr(wp_json_encode($row)); ?>'>
                                        <td><input type="checkbox" name="bulk_ids[]" value="<?php echo esc_attr($row->id); ?>"></td>
                                        <td><strong>#<?php echo esc_html($row->id); ?></strong></td>
                                        <td><small><?php echo esc_html(gmdate('M d, Y h:i A', strtotime($row->created_at))); ?></small></td>
                                        <td>
                                            <strong><?php echo esc_html($row->full_name); ?></strong>
                                            <?php if (!empty($row->company)): ?>
                                                <br><small style="color: #64748b;"><?php echo esc_html($row->company); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="mailto:<?php echo esc_attr($row->email); ?>"><?php echo esc_html($row->email); ?></a>
                                            <br><small><?php echo esc_html($row->phone); ?></small>
                                        </td>
                                        <td><span class="evonee-badge-product"><?php echo esc_html($row->product); ?></span></td>
                                        <td><strong><?php echo esc_html($row->quantity); ?></strong></td>
                                        <td>
                                            <?php if (!empty($row->quoted_price) && floatval($row->quoted_price) > 0): ?>
                                                <strong style="color:#16a34a;">$<?php echo number_format($row->quoted_price, 2); ?></strong>
                                            <?php else: ?>
                                                <span style="color:#94a3b8; font-size:11px;">Not Set</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small><?php echo esc_html($row->timeframe); ?></small>
                                            <?php if (!empty($row->specific_date)): ?>
                                                <br><small style="color: #6d28d9; font-weight:700;">Need by: <?php echo esc_html($row->specific_date); ?></small>
                                            <?php endif; ?>
                                            <?php if (!empty($row->follow_up_date)):
                                                $is_due = (strtotime($row->follow_up_date) <= strtotime(current_time('Y-m-d')));
                                                $badge_color = $is_due ? '#dc2626' : '#d97706';
                                            ?>
                                                <br><span style="background:<?php echo esc_attr($badge_color); ?>; color:#fff; font-size:10px; padding:2px 5px; border-radius:3px; font-weight:700;">⏰ Follow-up: <?php echo esc_html($row->follow_up_date); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php
                                            $art_urls = Evonee_Quote_Ajax::parse_artwork_urls($row->artwork_url ?? '');
                                            if (!empty($art_urls)):
                                                foreach ($art_urls as $ai => $aurl):
                                            ?>
                                                <a href="<?php echo esc_url($aurl); ?>" target="_blank" rel="noopener noreferrer" class="button button-small button-secondary">File <?php echo esc_html((string) ($ai + 1)); ?></a>
                                            <?php
                                                endforeach;
                                            else:
                                            ?>
                                                <span style="color: #94a3b8; font-style: italic; font-size:11.5px;">Design Help</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <select class="evonee-status-select evonee-status-<?php echo esc_attr($st); ?>" data-id="<?php echo esc_attr($row->id); ?>">
                                                <option value="new" <?php selected($st, 'new'); ?>>New</option>
                                                <option value="pending" <?php selected($st, 'pending'); ?>>Pending</option>
                                                <option value="quoted" <?php selected($st, 'quoted'); ?>>Quoted</option>
                                                <option value="approved" <?php selected($st, 'approved'); ?>>Approved</option>
                                                <option value="completed" <?php selected($st, 'completed'); ?>>Completed</option>
                                                <option value="rejected" <?php selected($st, 'rejected'); ?>>Rejected</option>
                                            </select>
                                        </td>
                                        <td>
                                            <div class="evonee-action-btns">
                                                <button type="button" class="button button-small button-primary eq-view-detail-btn" data-id="<?php echo esc_attr($row->id); ?>">👁️ View</button>
                                                <button type="button" class="button button-small button-secondary eq-reply-email-btn" data-id="<?php echo esc_attr($row->id); ?>" data-email="<?php echo esc_attr($row->email); ?>" data-name="<?php echo esc_attr($row->full_name); ?>" data-product="<?php echo esc_attr($row->product); ?>">✉️ Reply</button>
                                                <?php
                                                // PDF Quote Button — only shown if enable_pdf_quote setting is ON
                                                if ($show_pdf_btn):
                                                    $pdf_url = wp_nonce_url(
                                                        admin_url('admin.php?page=evonee-quotes&action=generate_pdf_quote&id=' . $row->id),
                                                        'eq_generate_pdf_' . $row->id
                                                    );
                                                ?>
                                                <a href="<?php echo esc_url($pdf_url); ?>" target="_blank" class="button button-small" style="color:#6d28d9; border-color:#6d28d9;">📄 PDF</a>
                                                <?php endif; ?>
                                                <?php
                                                $delete_url = wp_nonce_url(admin_url('admin.php?page=evonee-quotes&action=delete&id=' . $row->id), 'delete_quote_' . $row->id);
                                                ?>
                                                <a href="<?php echo esc_url($delete_url); ?>" onclick="return confirm('Are you sure you want to delete this submission?');" class="button button-small button-link-delete">Delete</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </form>
                    <form method="post" id="eq-status-form" style="display:none;">
                        <?php wp_nonce_field('eq_update_status'); ?>
                        <input type="hidden" name="eq_action" value="update_status">
                        <input type="hidden" name="sub_id" id="eq-status-sub-id" value="">
                        <input type="hidden" name="status" id="eq-status-value" value="">
                    </form>
                    <form method="get" id="eq-per-page-form" style="display:none;">
                        <input type="hidden" name="page" value="evonee-quotes">
                        <?php if (!empty($search)): ?><input type="hidden" name="s" value="<?php echo esc_attr($search); ?>"><?php endif; ?>
                        <?php if (!empty($status_filter)): ?><input type="hidden" name="status_filter" value="<?php echo esc_attr($status_filter); ?>"><?php endif; ?>
                        <?php if (!empty($date_range)): ?><input type="hidden" name="date_range" value="<?php echo esc_attr($date_range); ?>"><?php endif; ?>
                    </form>

                    <?php if ($total_pages > 1): ?>
                    <div class="evonee-pagination-nav" style="display:flex; justify-content:center; align-items:center; gap:6px; margin-top:16px; flex-wrap:wrap;">
                        <?php
                        $base_url_args = ['page' => 'evonee-quotes'];
                        if (!empty($search)) $base_url_args['s'] = $search;
                        if (!empty($status_filter)) $base_url_args['status_filter'] = $status_filter;
                        if ($per_page !== 20) $base_url_args['per_page'] = $per_page;

                        // Previous
                        if ($current_page > 1):
                            $prev_url = admin_url('admin.php?' . http_build_query(array_merge($base_url_args, ['paged' => $current_page - 1])));
                        ?>
                            <a href="<?php echo esc_url($prev_url); ?>" class="button">&laquo; Prev</a>
                        <?php endif; ?>

                        <?php
                        // Numbered pages (show max 7 links)
                        $start = max(1, $current_page - 3);
                        $end   = min($total_pages, $current_page + 3);
                        for ($p = $start; $p <= $end; $p++):
                            $pg_url = admin_url('admin.php?' . http_build_query(array_merge($base_url_args, ['paged' => $p])));
                            $active_style = ($p === $current_page) ? 'background:#6d28d9; color:#fff; border-color:#6d28d9;' : '';
                        ?>
                            <a href="<?php echo esc_url($pg_url); ?>" class="button" style="<?php echo esc_attr($active_style); ?>"><?php echo esc_html($p); ?></a>
                        <?php endfor; ?>

                        <?php if ($current_page < $total_pages):
                            $next_url = admin_url('admin.php?' . http_build_query(array_merge($base_url_args, ['paged' => $current_page + 1])));
                        ?>
                            <a href="<?php echo esc_url($next_url); ?>" class="button">Next &raquo;</a>
                        <?php endif; ?>

                        <span style="font-size:12px; color:#9ca3af; margin-left:8px;">Page <?php echo esc_html($current_page); ?> of <?php echo esc_html($total_pages); ?></span>
                    </div>
                    <?php endif; ?>

                <?php endif; ?>
            </div>
        </div>

        <!-- Detail Modal Drawer -->
        <div id="eq-admin-modal" class="eq-admin-modal-wrap" style="display:none;">
            <div class="eq-admin-modal-overlay"></div>
            <div class="eq-admin-modal-box">
                <button type="button" class="eq-admin-modal-close">&times;</button>
                <div class="eq-admin-modal-header">
                    <h2>📋 Quote Submission Details <span id="eq-detail-id"></span></h2>
                </div>
                <div class="eq-admin-modal-content" id="eq-detail-body">
                    <!-- Populated via JS -->
                </div>
                <!-- Follow-up Date & Offer Price Controls (Phase 2.2 & 2.3) -->
                <div style="border-top:1px solid #e2e8f0; padding:14px 20px; background:#f0fdf4; display:grid; grid-template-columns:1fr 1fr; gap:16px; align-items:center;">
                    <div>
                        <label style="font-size:12px; font-weight:700; color:#166534; display:block; margin-bottom:4px;">⏰ Set Follow-up Reminder Date:</label>
                        <div style="display:flex; gap:6px;">
                            <input type="date" id="eq-followup-date-input" style="font-size:12px; padding:4px 8px; border:1px solid #bbf7d0; border-radius:4px;">
                            <button type="button" id="eq-save-followup-btn" class="button button-small button-secondary">Set Date</button>
                        </div>
                        <span id="eq-followup-msg" style="font-size:11px; color:#166534; display:none;">Saved!</span>
                    </div>
                    <div>
                        <label style="font-size:12px; font-weight:700; color:#1e40af; display:block; margin-bottom:4px;">💰 Price ($) & Deposit (%):</label>
                        <div style="display:flex; gap:6px; align-items:center;">
                            <input type="number" step="0.01" id="eq-quoted-price-input" placeholder="Price $" style="font-size:12px; padding:4px 8px; border:1px solid #bfdbfe; border-radius:4px; width:90px;">
                            <input type="number" step="1" min="0" max="100" id="eq-deposit-percent-input" placeholder="Dep %" style="font-size:12px; padding:4px 8px; border:1px solid #bfdbfe; border-radius:4px; width:60px;">
                            <button type="button" id="eq-save-price-btn" class="button button-small button-primary" style="background:#2563eb; border-color:#2563eb;">Save Offer</button>
                        </div>
                        <span id="eq-price-msg" style="font-size:11px; color:#2563eb; display:none;">Saved!</span>
                    </div>
                </div>

                <!-- 1-Click WooCommerce Order Conversion (Phase 1.2) -->
                <div style="border-top:1px solid #e2e8f0; padding:12px 20px; background:#fff7ed; display:flex; justify-content:space-between; align-items:center;">
                    <div>
                        <strong style="font-size:12.5px; color:#c2410c;">🛒 WooCommerce Order Integration:</strong>
                        <span style="font-size:12px; color:#7c2d12; margin-left:4px;">Instantly convert quote into a WooCommerce Pending Order.</span>
                    </div>
                    <div>
                        <button type="button" id="eq-convert-wc-btn" class="button button-primary" style="background:#ea580c; border-color:#ea580c;">🛒 Convert to WC Order</button>
                    </div>
                </div>

                <!-- Internal Admin Notes (Phase 1.3) -->
                <div style="border-top:1px solid #e2e8f0; padding:16px 20px; background:#f8fafc;">
                    <h3 style="margin:0 0 8px; font-size:13px; color:#374151; font-weight:700;">🔒 Internal Team Notes <small style="font-weight:400; color:#9ca3af;">(Not visible to customer)</small></h3>
                    <textarea id="eq-admin-notes-text" rows="3" style="width:100%; font-size:13px; padding:8px; border:1px solid #d1d5db; border-radius:6px; resize:vertical;" placeholder="Add internal notes, follow-up reminders, or team comments..."></textarea>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px;">
                        <span id="eq-notes-saved-msg" style="font-size:11px; color:#16a34a; display:none;">✅ Notes saved!</span>
                        <button type="button" id="eq-save-notes-btn" class="button button-primary" style="background:#6d28d9; border-color:#6d28d9;">💾 Save Notes</button>
                    </div>
                </div>

                <!-- Quote Discussion Thread (Step 2) -->
                <div style="border-top:1px solid #e2e8f0; padding:16px 20px; background:#faf5ff;">
                    <h3 style="margin:0 0 10px; font-size:13px; color:#6d28d9; font-weight:700;">💬 Quote Discussion Thread (Live Customer Messages)</h3>
                    <div id="eq-discussion-messages" style="max-height:160px; overflow-y:auto; font-size:12px; background:#ffffff; padding:10px; border-radius:6px; border:1px solid #e9d5ff; margin-bottom:10px;">
                        <em style="color:#9ca3af;">Loading messages...</em>
                    </div>
                    <div style="display:flex; gap:8px;">
                        <input type="text" id="eq-admin-chat-input" placeholder="Type a message to customer..." style="flex:1; font-size:12px; padding:6px 10px; border:1px solid #d8b4fe; border-radius:6px;">
                        <button type="button" id="eq-send-admin-chat-btn" class="button button-primary" style="background:#6d28d9; border-color:#6d28d9;">Send Response</button>
                    </div>
                </div>

                <!-- Activity Log & Email History (Phase 2.1 & 2.4) -->
                <div style="border-top:1px solid #e2e8f0; padding:16px 20px; background:#ffffff;">
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                        <div>
                            <h4 style="margin:0 0 8px; font-size:12px; color:#4c1d95; text-transform:uppercase;">📜 Activity Log Timeline</h4>
                            <div id="eq-activity-log-body" style="max-height:140px; overflow-y:auto; font-size:11.5px; background:#faf9fd; padding:10px; border-radius:6px; border:1px solid #e5e0f5;">
                                <!-- Populated via JS -->
                            </div>
                        </div>
                        <div>
                            <h4 style="margin:0 0 8px; font-size:12px; color:#2563eb; text-transform:uppercase;">📧 Email Dispatch History</h4>
                            <div id="eq-email-log-body" style="max-height:140px; overflow-y:auto; font-size:11.5px; background:#eff6ff; padding:10px; border-radius:6px; border:1px solid #bfdbfe;">
                                <!-- Populated via JS -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Email Reply Modal Drawer -->
        <div id="eq-reply-modal" class="eq-admin-modal-wrap" style="display:none;">
            <div class="eq-admin-modal-overlay"></div>
            <div class="eq-admin-modal-box" style="max-width: 580px;">
                <button type="button" class="eq-admin-modal-close">&times;</button>
                <div class="eq-admin-modal-header">
                    <h2>✉️ Send Price Quote Email to Customer</h2>
                </div>
                <form method="post" style="padding: 20px;">
                    <?php wp_nonce_field('eq_send_reply'); ?>
                    <input type="hidden" name="eq_action" value="send_customer_reply">
                    <input type="hidden" name="sub_id" id="eq-reply-sub-id" value="">
                    
                    <div style="margin-bottom: 12px;">
                        <label style="font-weight:700; display:block; margin-bottom:4px;">Customer Email:</label>
                        <input type="email" name="customer_email" id="eq-reply-email" class="widefat" readonly required style="background:#f8fafc;">
                    </div>

                    <!-- AI Smart Reply Drafter Bar -->
                    <div style="margin-bottom:12px; background:#f0fdf4; border:1px solid #bbf7d0; border-radius:6px; padding:10px 12px; display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <strong style="font-size:12px; color:#15803d;">🤖 Smart AI Sales Assistant:</strong>
                            <span style="font-size:11.5px; color:#166534; display:block;">Generate an instant, customized quote offer & proposal.</span>
                        </div>
                        <button type="button" id="eq-ai-reply-btn" class="button button-primary" style="background:#16a34a; border-color:#16a34a; font-weight:700;">🤖 AI Draft Reply</button>
                    </div>

                    <?php
                    $reply_templates = get_option('evonee_reply_templates', []);
                    if (!empty($reply_templates)):
                    ?>
                    <div style="margin-bottom:12px; background:#faf5ff; border:1px solid #e9d5ff; border-radius:6px; padding:10px 12px;">
                        <label style="font-weight:700; display:block; margin-bottom:6px; font-size:12px; color:#6d28d9;">⚡ Load Quick Template:</label>
                        <select id="eq-template-select" style="width:100%; font-size:13px; padding:6px;">
                            <option value="">— Select a template —</option>
                            <?php foreach ($reply_templates as $idx => $tmpl): ?>
                                <option value="<?php echo esc_attr($idx); ?>"
                                    data-subject="<?php echo esc_attr($tmpl['subject'] ?? ''); ?>"
                                    data-body="<?php echo esc_attr($tmpl['body'] ?? ''); ?>">
                                    <?php echo esc_html($tmpl['title'] ?? 'Template ' . ($idx + 1)); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <div style="margin-bottom: 12px;">
                        <label style="font-weight:700; display:block; margin-bottom:4px;">Subject Line:</label>
                        <input type="text" name="email_subject" id="eq-reply-subject" class="widefat" required>
                    </div>

                    <div style="margin-bottom: 16px;">
                        <label style="font-weight:700; display:block; margin-bottom:4px;">Quote Details & Message:</label>
                        <textarea name="email_body" id="eq-reply-body" rows="8" class="widefat" required></textarea>
                    </div>

                    <div style="display:flex; justify-content:flex-end; gap:10px;">
                        <button type="button" class="button eq-close-modal-btn">Cancel</button>
                        <button type="submit" class="button button-primary button-large" style="background:#6d28d9; border-color:#6d28d9;">📤 Send Email Quote</button>
                    </div>
                </form>
            </div>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Select All Checkbox
            const selectAll = document.getElementById('eq-select-all');
            if (selectAll) {
                selectAll.addEventListener('change', function() {
                    document.querySelectorAll('input[name="bulk_ids[]"]').forEach(cb => cb.checked = this.checked);
                });
            }

            const statusForm = document.getElementById('eq-status-form');
            document.querySelectorAll('.evonee-status-select').forEach(sel => {
                sel.addEventListener('change', function() {
                    if (!statusForm) return;
                    document.getElementById('eq-status-sub-id').value = this.getAttribute('data-id');
                    document.getElementById('eq-status-value').value = this.value;
                    statusForm.submit();
                });
            });

            function escapeHtml(str) {
                if (str == null || str === '') return '';
                return String(str).replace(/[&<>"']/g, function (s) {
                    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[s];
                });
            }

            function parseArtworkUrls(raw) {
                if (!raw) return [];
                if (Array.isArray(raw)) return raw.filter(Boolean);
                try {
                    const decoded = JSON.parse(raw);
                    if (Array.isArray(decoded)) return decoded.filter(Boolean);
                } catch (e) {}
                return String(raw).split(/\s*,\s*/).filter(Boolean);
            }

            function parseProductDetails(raw) {
                if (!raw) return {};
                if (typeof raw === 'object' && !Array.isArray(raw)) return raw;
                try {
                    const decoded = JSON.parse(raw);
                    return (decoded && typeof decoded === 'object') ? decoded : {};
                } catch (e) {
                    return {};
                }
            }

            // View Details Modal
            const detailModal = document.getElementById('eq-admin-modal');
            const detailBody  = document.getElementById('eq-detail-body');
            const detailId    = document.getElementById('eq-detail-id');

            const notesText      = document.getElementById('eq-admin-notes-text');
            const saveNotesBtn   = document.getElementById('eq-save-notes-btn');
            const notesSavedMsg  = document.getElementById('eq-notes-saved-msg');
            let currentDetailId  = null;

            document.querySelectorAll('.eq-view-detail-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const row = JSON.parse(this.closest('tr').getAttribute('data-row'));
                    currentDetailId = row.id;
                    detailId.textContent = '#' + row.id;

                    // Load admin notes
                    if (notesText) {
                        notesText.value = row.admin_notes || '';
                        if (notesSavedMsg) notesSavedMsg.style.display = 'none';
                    }

                    // Load follow-up date & offer price & deposit percent
                    const followupInput = document.getElementById('eq-followup-date-input');
                    const priceInput    = document.getElementById('eq-quoted-price-input');
                    const depositInput  = document.getElementById('eq-deposit-percent-input');
                    if (followupInput) followupInput.value = row.follow_up_date || '';
                    if (priceInput) priceInput.value = row.quoted_price || '';
                    if (depositInput) depositInput.value = row.deposit_percent || '';

                    // Fetch Activity Log & Email Log
                    const actBody   = document.getElementById('eq-activity-log-body');
                    const emailBody = document.getElementById('eq-email-log-body');
                    if (actBody) actBody.innerHTML = '<em style="color:#9ca3af;">Loading timeline...</em>';
                    if (emailBody) emailBody.innerHTML = '<em style="color:#9ca3af;">Loading email logs...</em>';

                    const artUrls = parseArtworkUrls(row.artwork_url);
                    let artworkHtml = artUrls.length
                        ? artUrls.map((url, i) => `<a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer" class="button button-primary">Download Artwork ${i + 1}</a>`).join(' ')
                        : `<span style="color:#94a3b8; font-style:italic;">No artwork uploaded (Customer requested design assistance)</span>`;

                    const details = parseProductDetails(row.product_details);
                    const detailRows = Object.keys(details).filter(k => details[k] !== '' && details[k] != null).map(k => {
                        const label = k.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                        const val = Array.isArray(details[k]) ? details[k].join(', ') : details[k];
                        return `<p><strong>${escapeHtml(label)}:</strong> ${escapeHtml(val)}</p>`;
                    }).join('');

                    detailBody.innerHTML = `
                        <div class="eq-detail-grid">
                            <div class="eq-detail-card">
                                <h3>Customer Information</h3>
                                <p><strong>Name:</strong> ${escapeHtml(row.full_name)}</p>
                                <p><strong>Company:</strong> ${escapeHtml(row.company || 'N/A')}</p>
                                <p><strong>Email:</strong> <a href="mailto:${escapeHtml(row.email)}">${escapeHtml(row.email)}</a></p>
                                <p><strong>Phone / WhatsApp:</strong> ${escapeHtml(row.phone)}</p>
                                <p><strong>Country:</strong> ${escapeHtml(row.country)}</p>
                                <p><strong>ZIP / Postal Code:</strong> ${escapeHtml(row.zip_code)}</p>
                            </div>
                            <div class="eq-detail-card">
                                <h3>Product & Order Requirements</h3>
                                <p><strong>Product Requested:</strong> <span class="evonee-badge-product">${escapeHtml(row.product)}</span></p>
                                <p><strong>Quantity:</strong> ${escapeHtml(row.quantity)}</p>
                                <p><strong>Timeframe:</strong> ${escapeHtml(row.timeframe)}</p>
                                <p><strong>Specific Need Date:</strong> ${escapeHtml(row.specific_date || 'N/A')}</p>
                                <p><strong>Submitted Date:</strong> ${escapeHtml(row.created_at)}</p>
                                <p><strong>Estimated System Price:</strong> <strong style="color:#2563eb;">${row.estimated_total ? '$' + parseFloat(row.estimated_total).toFixed(2) : 'Under Review'}</strong></p>
                                <p><strong>Quoted Price Offer:</strong> <strong style="color:#16a34a;">${row.quoted_price ? '$' + parseFloat(row.quoted_price).toFixed(2) : 'Not Set'}</strong> ${row.deposit_percent > 0 ? `<small style="color:#2563eb;">(${row.deposit_percent}% Deposit Required)</small>` : ''}</p>
                                <p><strong>Current Status:</strong> <strong style="text-transform:uppercase; color:#6d28d9;">${escapeHtml(row.status || 'NEW')}</strong></p>
                                <p style="margin-top: 10px;">
                                    <a href="admin-ajax.php?action=eq_download_pdf&id=${row.id}" target="_blank" class="button button-secondary" style="background:#f1f5f9; border-color:#cbd5e1; color:#334155; font-weight:600;">📄 Download PDF Quote Sheet</a>
                                </p>
                            </div>
                        </div>

                        <div class="eq-detail-card" style="margin-top: 14px;">
                            <h3>Product Details</h3>
                            ${detailRows || '<p style="color:#94a3b8;">No additional product details.</p>'}
                        </div>

                        <div class="eq-detail-card" style="margin-top: 14px;">
                            <h3>Uploaded Artwork</h3>
                            ${artworkHtml}
                        </div>

                        <div class="eq-detail-card" style="margin-top: 14px;">
                            <h3>Customer Project Notes & Requirements</h3>
                            <div style="background:#f8fafc; padding:12px 16px; border-radius:6px; border:1px solid #e2e8f0; font-size:13.5px; white-space:pre-wrap;">${escapeHtml(row.project_notes || 'No additional notes provided.')}</div>
                        </div>
                    `;

                    // Load Logs via PHP queries (passed via inline JSON data)
                    <?php
                    global $wpdb;
                    $act_table   = $wpdb->prefix . 'eq_quote_activity_log';
                    $email_table = $wpdb->prefix . 'eq_email_log';
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
                    $all_act     = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}eq_quote_activity_log ORDER BY id DESC LIMIT 500");
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
                    $all_email   = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}eq_email_log ORDER BY id DESC LIMIT 500");
                    ?>
                    const allActivities = <?php echo wp_json_encode($all_act ?: []); ?>;
                    const allEmails     = <?php echo wp_json_encode($all_email ?: []); ?>;

                    const subActs = allActivities.filter(a => String(a.submission_id) === String(row.id));
                    const subEmails = allEmails.filter(e => String(e.submission_id) === String(row.id));

                    if (actBody) {
                        if (subActs.length > 0) {
                            actBody.innerHTML = subActs.map(a => `<div style="margin-bottom:4px; border-bottom:1px dashed #e2e8f0; padding-bottom:4px;"><strong>${escapeHtml(a.action)}</strong>: ${escapeHtml(a.notes)} <br><small style="color:#94a3b8;">${escapeHtml(a.created_at)}</small></div>`).join('');
                        } else {
                            actBody.innerHTML = '<span style="color:#94a3b8;">No activity logged yet.</span>';
                        }
                    }

                    function loadDiscussionMessages(subId) {
                        const discBox = document.getElementById('eq-discussion-messages');
                        if (!discBox) return;
                        discBox.innerHTML = '<em style="color:#9ca3af;">Loading messages...</em>';
                        fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>?action=eq_get_messages&submission_id=' + subId)
                            .then(r => r.json())
                            .then(data => {
                                if (data.success && data.data && data.data.messages && data.data.messages.length > 0) {
                                    discBox.innerHTML = data.data.messages.map(m => {
                                        const isAdmin = m.sender_type === 'admin';
                                        const bg = isAdmin ? '#faf5ff' : '#eff6ff';
                                        const border = isAdmin ? '#e9d5ff' : '#bfdbfe';
                                        const align = isAdmin ? 'right' : 'left';
                                        const senderLabel = isAdmin ? '🛡️ Admin (' + escapeHtml(m.sender_name) + ')' : '👤 ' + escapeHtml(m.sender_name);
                                        return `<div style="background:${bg}; border:1px solid ${border}; padding:6px 10px; border-radius:6px; margin-bottom:6px; text-align:${align};">
                                            <strong>${senderLabel}</strong> <small style="color:#94a3b8;">${escapeHtml(m.created_at)}</small>
                                            <div style="margin-top:2px; color:#1e293b;">${escapeHtml(m.message)}</div>
                                        </div>`;
                                    }).join('');
                                    discBox.scrollTop = discBox.scrollHeight;
                                } else {
                                    discBox.innerHTML = '<span style="color:#94a3b8; font-style:italic;">No messages in discussion thread yet.</span>';
                                }
                            })
                            .catch(() => { discBox.innerHTML = '<span style="color:#dc2626;">Error loading messages.</span>'; });
                    }

                    if (emailBody) {
                        if (subEmails.length > 0) {
                            emailBody.innerHTML = subEmails.map(e => `<div style="margin-bottom:4px; border-bottom:1px dashed #bfdbfe; padding-bottom:4px;"><strong>${escapeHtml(e.type)}</strong> (${escapeHtml(e.status)}) → ${escapeHtml(e.recipient)}<br><em>${escapeHtml(e.subject)}</em><br><small style="color:#94a3b8;">${escapeHtml(e.sent_at)}</small></div>`).join('');
                        } else {
                            emailBody.innerHTML = '<span style="color:#94a3b8;">No email history recorded yet.</span>';
                        }
                    }

                    loadDiscussionMessages(row.id);

                    detailModal.style.display = 'flex';
                });
            });

            // Save Admin Notes via AJAX
            if (saveNotesBtn) {
                saveNotesBtn.addEventListener('click', function() {
                    if (!currentDetailId) return;
                    const notes = notesText ? notesText.value : '';
                    saveNotesBtn.disabled = true;
                    saveNotesBtn.textContent = 'Saving...';

                    const fd = new FormData();
                    fd.append('action', 'eq_save_admin_notes');
                    fd.append('nonce', '<?php echo esc_js(wp_create_nonce('eq_save_notes_nonce')); ?>');
                    fd.append('submission_id', currentDetailId);
                    fd.append('notes', notes);

                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(data => {
                            saveNotesBtn.disabled = false;
                            saveNotesBtn.textContent = '💾 Save Notes';
                            if (data.success && notesSavedMsg) {
                                notesSavedMsg.style.display = 'inline';
                                setTimeout(() => notesSavedMsg.style.display = 'none', 3000);
                                const tr = document.querySelector(`.eq-view-detail-btn[data-id="${currentDetailId}"]`)?.closest('tr');
                                if (tr) {
                                    const rowData = JSON.parse(tr.getAttribute('data-row'));
                                    rowData.admin_notes = notes;
                                    tr.setAttribute('data-row', JSON.stringify(rowData));
                                }
                            }
                        })
                        .catch(() => { saveNotesBtn.disabled = false; saveNotesBtn.textContent = '💾 Save Notes'; });
                });
            }

            // Send Admin Chat Message (Step 2)
            const sendChatBtn = document.getElementById('eq-send-admin-chat-btn');
            const chatInput   = document.getElementById('eq-admin-chat-input');
            if (sendChatBtn && chatInput) {
                sendChatBtn.addEventListener('click', function() {
                    if (!currentDetailId) return;
                    const msg = chatInput.value.trim();
                    if (!msg) return;
                    sendChatBtn.disabled = true;
                    sendChatBtn.textContent = 'Sending...';

                    const fd = new FormData();
                    fd.append('action', 'eq_send_message');
                    fd.append('submission_id', currentDetailId);
                    fd.append('sender_type', 'admin');
                    fd.append('message', msg);

                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(data => {
                            sendChatBtn.disabled = false;
                            sendChatBtn.textContent = 'Send Response';
                            if (data.success) {
                                chatInput.value = '';
                                const discBox = document.getElementById('eq-discussion-messages');
                                if (discBox) {
                                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>?action=eq_get_messages&submission_id=' + currentDetailId)
                                        .then(r => r.json())
                                        .then(d => {
                                            if (d.success && d.data && d.data.messages && d.data.messages.length > 0) {
                                                discBox.innerHTML = d.data.messages.map(m => {
                                                    const isAdmin = m.sender_type === 'admin';
                                                    const bg = isAdmin ? '#faf5ff' : '#eff6ff';
                                                    const border = isAdmin ? '#e9d5ff' : '#bfdbfe';
                                                    const align = isAdmin ? 'right' : 'left';
                                                    const senderLabel = isAdmin ? '🛡️ Admin (' + escapeHtml(m.sender_name) + ')' : '👤 ' + escapeHtml(m.sender_name);
                                                    return `<div style="background:${bg}; border:1px solid ${border}; padding:6px 10px; border-radius:6px; margin-bottom:6px; text-align:${align};">
                                                        <strong>${senderLabel}</strong> <small style="color:#94a3b8;">${escapeHtml(m.created_at)}</small>
                                                        <div style="margin-top:2px; color:#1e293b;">${escapeHtml(m.message)}</div>
                                                    </div>`;
                                                }).join('');
                                                discBox.scrollTop = discBox.scrollHeight;
                                            }
                                        });
                                }
                            } else {
                                alert(data.data ? data.data.message : 'Error sending message.');
                            }
                        })
                        .catch(() => { sendChatBtn.disabled = false; sendChatBtn.textContent = 'Send Response'; });
                });
            }

            // Save Follow-up Date via AJAX
            const saveFollowupBtn = document.getElementById('eq-save-followup-btn');
            const followupMsg     = document.getElementById('eq-followup-msg');
            if (saveFollowupBtn) {
                saveFollowupBtn.addEventListener('click', function() {
                    if (!currentDetailId) return;
                    const fDate = document.getElementById('eq-followup-date-input')?.value || '';
                    saveFollowupBtn.disabled = true;

                    const fd = new FormData();
                    fd.append('action', 'eq_save_followup');
                    fd.append('nonce', '<?php echo esc_js(wp_create_nonce('eq_save_followup_nonce')); ?>');
                    fd.append('submission_id', currentDetailId);
                    fd.append('follow_up_date', fDate);

                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(data => {
                            saveFollowupBtn.disabled = false;
                            if (data.success && followupMsg) {
                                followupMsg.style.display = 'inline';
                                setTimeout(() => followupMsg.style.display = 'none', 3000);
                                const tr = document.querySelector(`.eq-view-detail-btn[data-id="${currentDetailId}"]`)?.closest('tr');
                                if (tr) {
                                    const rowData = JSON.parse(tr.getAttribute('data-row'));
                                    rowData.follow_up_date = fDate;
                                    tr.setAttribute('data-row', JSON.stringify(rowData));
                                }
                            }
                        })
                        .catch(() => { saveFollowupBtn.disabled = false; });
                });
            }

            // Save Quoted Price Offer & Deposit % via AJAX
            const savePriceBtn = document.getElementById('eq-save-price-btn');
            const priceMsg    = document.getElementById('eq-price-msg');
            if (savePriceBtn) {
                savePriceBtn.addEventListener('click', function() {
                    if (!currentDetailId) return;
                    const priceVal = document.getElementById('eq-quoted-price-input')?.value || 0;
                    const depVal   = document.getElementById('eq-deposit-percent-input')?.value || 0;
                    savePriceBtn.disabled = true;

                    const fd = new FormData();
                    fd.append('action', 'eq_save_price_offer');
                    fd.append('nonce', '<?php echo esc_js(wp_create_nonce('eq_save_price_offer_nonce')); ?>');
                    fd.append('submission_id', currentDetailId);
                    fd.append('quoted_price', priceVal);
                    fd.append('deposit_percent', depVal);

                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(data => {
                            savePriceBtn.disabled = false;
                            if (data.success && priceMsg) {
                                priceMsg.style.display = 'inline';
                                setTimeout(() => priceMsg.style.display = 'none', 3000);
                                const tr = document.querySelector(`.eq-view-detail-btn[data-id="${currentDetailId}"]`)?.closest('tr');
                                if (tr) {
                                    const rowData = JSON.parse(tr.getAttribute('data-row'));
                                    rowData.quoted_price = priceVal;
                                    rowData.deposit_percent = depVal;
                                    tr.setAttribute('data-row', JSON.stringify(rowData));
                                }
                            }
                        })
                        .catch(() => { savePriceBtn.disabled = false; });
                });
            }

            // 🤖 AI Smart Reply Drafter Handler
            const aiReplyBtn = document.getElementById('eq-ai-reply-btn');
            if (aiReplyBtn) {
                aiReplyBtn.addEventListener('click', function() {
                    let subId = currentDetailId;
                    if (!subId) {
                        subId = document.getElementById('eq-reply-sub-id')?.value;
                    }
                    if (!subId) {
                        alert('Please open a quote detail drawer first.');
                        return;
                    }

                    aiReplyBtn.disabled = true;
                    aiReplyBtn.textContent = '🤖 Generating AI Draft...';

                    const fd = new FormData();
                    fd.append('action', 'eq_ai_generate_reply');
                    fd.append('nonce', '<?php echo esc_js(wp_create_nonce('eq_admin_nonce')); ?>');
                    fd.append('submission_id', subId);

                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(data => {
                            aiReplyBtn.disabled = false;
                            aiReplyBtn.textContent = '🤖 AI Draft Reply';
                            if (data.success && data.data) {
                                const subjInp  = document.getElementById('eq-reply-subject');
                                const bodyInp  = document.getElementById('eq-reply-body');
                                const priceInp = document.getElementById('eq-quoted-price-input');
                                const depInp   = document.getElementById('eq-deposit-percent-input');

                                if (subjInp) subjInp.value = data.data.reply_subject || '';
                                if (bodyInp) bodyInp.value = data.data.reply_body || '';
                                if (priceInp && data.data.suggested_price) priceInp.value = data.data.suggested_price;
                                if (depInp && data.data.suggested_deposit_percent) depInp.value = data.data.suggested_deposit_percent;

                                alert('✨ AI Smart Reply Proposal generated successfully!');
                            } else {
                                alert('Failed to generate AI reply: ' + (data.data?.message || 'Unknown error'));
                            }
                        })
                        .catch(() => {
                            aiReplyBtn.disabled = false;
                            aiReplyBtn.textContent = '🤖 AI Draft Reply';
                        });
                });
            }

            // Convert to WooCommerce Order via AJAX (Phase 1.2)
            const convertWcBtn = document.getElementById('eq-convert-wc-btn');
            if (convertWcBtn) {
                convertWcBtn.addEventListener('click', function() {
                    if (!currentDetailId) return;
                    if (!confirm('Convert Quote #' + currentDetailId + ' to a WooCommerce Order?')) return;

                    convertWcBtn.disabled = true;
                    convertWcBtn.textContent = 'Converting...';

                    const fd = new FormData();
                    fd.append('action', 'eq_convert_to_wc_order');
                    fd.append('nonce', '<?php echo esc_js(wp_create_nonce('eq_convert_to_wc_order_nonce')); ?>');
                    fd.append('submission_id', currentDetailId);

                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(data => {
                            convertWcBtn.disabled = false;
                            convertWcBtn.textContent = '🛒 Convert to WC Order';
                            if (data.success) {
                                alert(data.data.message + '\n\nOpening WooCommerce Order edit page...');
                                window.open(data.data.order_edit_url, '_blank');
                            } else {
                                alert('Error: ' + (data.data?.message || 'Failed to convert order.'));
                            }
                        })
                        .catch(() => {
                            convertWcBtn.disabled = false;
                            convertWcBtn.textContent = '🛒 Convert to WC Order';
                            alert('An unexpected error occurred.');
                        });
                });
            // ⏰ Run Drip Engine Manual Launcher
            const runDripBtn = document.getElementById('eq-run-drip-btn');
            if (runDripBtn) {
                runDripBtn.addEventListener('click', function() {
                    runDripBtn.disabled = true;
                    runDripBtn.textContent = '⏳ Executing...';
                    const fd = new FormData();
                    fd.append('action', 'eq_run_drip_engine');
                    fd.append('nonce', '<?php echo esc_js(wp_create_nonce('eq_admin_nonce')); ?>');

                    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(data => {
                            runDripBtn.disabled = false;
                            runDripBtn.textContent = '⏰ Run Drip Engine';
                            if (data.success && data.data) {
                                alert('✅ ' + data.data.message);
                            } else {
                                alert('Failed to execute drip engine.');
                            }
                        })
                        .catch(() => {
                            runDripBtn.disabled = false;
                            runDripBtn.textContent = '⏰ Run Drip Engine';
                        });
                });
            }

            // Reply Email Modal
            const replyModal   = document.getElementById('eq-reply-modal');
            const replySubId   = document.getElementById('eq-reply-sub-id');
            const replyEmail   = document.getElementById('eq-reply-email');
            const replySubject = document.getElementById('eq-reply-subject');
            const replyBody    = document.getElementById('eq-reply-body');

            document.querySelectorAll('.eq-reply-email-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id      = this.getAttribute('data-id');
                    const email   = this.getAttribute('data-email');
                    const name    = this.getAttribute('data-name');
                    const product = this.getAttribute('data-product');

                    replySubId.value = id;
                    replyEmail.value = email;
                    replyEmail.dataset.name = name || '';
                    replyEmail.dataset.product = product || '';
                    replySubject.value = `Official Price Quote for ${product} - Evonee (#${id})`;
                    replyBody.value = `Hi ${name},\n\nThank you for reaching out to Evonee regarding your quote request for ${product}.\n\nWe have reviewed your specifications and are pleased to provide you with the following price quote:\n\n- Product: ${product}\n- Price: $ [Enter Price Here]\n- Turnaround Time: [Enter Delivery Timeframe]\n\nPlease let us know if you would like to proceed or if you have any questions!\n\nBest regards,\nEvonee Sales Team\nsales@evonee.com`;

                    replyModal.style.display = 'flex';
                });
            });

            // Close Admin Modals
            document.querySelectorAll('.eq-admin-modal-close, .eq-close-modal-btn, .eq-admin-modal-overlay').forEach(el => {
                el.addEventListener('click', function() {
                    detailModal.style.display = 'none';
                    replyModal.style.display = 'none';
                });
            });

            // Quick Reply Template Select Handler (Phase 1.5)
            const templateSelect = document.getElementById('eq-template-select');
            if (templateSelect) {
                templateSelect.addEventListener('change', function() {
                    const selected = this.options[this.selectedIndex];
                    if (!selected || !selected.value) return;
                    const custName = replyEmail ? replyEmail.dataset.name || '' : '';
                    const product  = replyEmail ? replyEmail.dataset.product || '' : '';
                    const quoteId  = replySubId ? replySubId.value || '' : '';

                    const replaceVars = (str) => str
                        .replace(/\{customer_name\}/g, custName)
                        .replace(/\{product\}/g, product)
                        .replace(/\{quote_id\}/g, quoteId);

                    if (replySubject && selected.dataset.subject) {
                        replySubject.value = replaceVars(selected.dataset.subject);
                    }
                    if (replyBody && selected.dataset.body) {
                        replyBody.value = replaceVars(selected.dataset.body);
                    }
                    // Reset selector after use
                    this.selectedIndex = 0;
                });
            }
        });
        </script>
        <?php
    }

    /**
     * Render Documentation & Help Admin Page
     */
    public function render_docs_page() {
        $settings = self::get_settings();
        ?>
        <div class="wrap evonee-admin-wrap">
            <div class="evonee-docs-header">
                <div>
                    <h1>📖 Evonee Get Quote — Plugin Documentation & User Guide</h1>
                    <p class="subtitle">Official setup guide, shortcode reference, Google Sheets tutorial, and developer hooks.</p>
                </div>
                <div class="evonee-docs-brand">
                    <span>Evonee v<?php echo esc_html(EVONEE_VERSION); ?></span>
                </div>
            </div>

            <!-- SaaS Tab Navigation -->
            <div class="eq-tabs-nav">
                <button type="button" class="eq-tab-btn active" data-tab="doc-tab-overview">
                    <span class="dashicons dashicons-welcome-widgets-menus"></span> Overview & Modules
                </button>
                <button type="button" class="eq-tab-btn" data-tab="doc-tab-shortcodes">
                    <span class="dashicons dashicons-shortcode"></span> Shortcodes & Page Builders
                </button>
                <button type="button" class="eq-tab-btn" data-tab="doc-tab-gsheets">
                    <span class="dashicons dashicons-spreadsheet"></span> Google Sheets Setup
                </button>
                <button type="button" class="eq-tab-btn" data-tab="doc-tab-integrations">
                    <span class="dashicons dashicons-share-alt"></span> Webhooks & Slack
                </button>
                <button type="button" class="eq-tab-btn" data-tab="doc-tab-developer">
                    <span class="dashicons dashicons-shield"></span> Security & Hooks
                </button>
            </div>

            <!-- Docs Content Layout -->
            <div class="evonee-docs-grid">
                
                <!-- Main Content Column -->
                <div class="evonee-docs-main">
                    
                    <!-- TAB 1: OVERVIEW & MODULES -->
                    <div id="doc-tab-overview" class="eq-tab-content active">
                        <div class="evonee-doc-card">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-welcome-widgets-menus"></span>
                                <h2>1. Quick Start & v2.0.0 Enterprise Overview</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p>The <strong>Evonee Get Quote Plugin (v2.0.0 Enterprise)</strong> provides a complete B2B Lead Management & Custom Quote Automation System. It embeds a site-wide modal popup with a 6-step progress bar, instant price estimator, front-end customer portal, 1-click WooCommerce order conversion, and automated WP-Cron expiry reminders.</p>

                                <div class="evonee-feature-box">
                                    <ul>
                                        <li>⚡ <strong>9 Core Modules & 40+ Features:</strong> Full CRM pipeline, Email Builder, Front-end Portal, WooCommerce Conversion, Analytics, Integrations, and Cron Automations.</li>
                                        <li>👤 <strong>Front-end Customer Portal:</strong> Embed <code>[evonee_customer_portal]</code> for buyers to track submitted quotes and accept/decline offers.</li>
                                        <li>🛒 <strong>1-Click WooCommerce Order Conversion:</strong> Convert quote submissions into WooCommerce pending orders directly from the CRM drawer.</li>
                                        <li>⏰ <strong>Automated Reminders & Expiry:</strong> Daily WP-Cron automatically dispatches reminder emails to customers before quote offers expire.</li>
                                        <li>🛡️ <strong>Advanced Security & Spam Shield:</strong> Google reCAPTCHA v3, Nonce verification, Honeypot bot protection, and IP rate-limiting.</li>
                                        <li>📎 <strong>Multi-File Artwork Upload:</strong> Secure dropzone supporting up to 3 artwork files (AI, PDF, EPS, SVG, PNG, JPG) with DOM-based SVG XSS sanitization.</li>
                                        <li>💬 <strong>Customer Tokenized Quote Acceptance:</strong> Auto-generates expiring action links (Accept/Decline) inside email replies for 1-click customer approval.</li>
                                        <li>🔗 <strong>Webhook, Zapier, Slack, Discord & Google Sheets:</strong> Real-time automated lead payloads to Google Sheets, Slack channels, Discord, or CRM webhooks.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="evonee-doc-card">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <h2>2. Complete v2.0 Module Guide</h2>
                            </div>
                            <div class="evonee-card-body">
                                <table class="evonee-docs-table">
                                    <thead>
                                        <tr>
                                            <th>Module</th>
                                            <th>Key Capabilities</th>
                                            <th>Where to Configure</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><strong>📦 Module 1 — CRM</strong></td>
                                            <td>Pagination, Internal Admin Notes, Follow-up Reminders, Activity Log Timeline, Column Sorting & Date Range Filters.</td>
                                            <td><code>Evonee Quotes ➔ Submissions</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>✉️ Module 2 — Email</strong></td>
                                            <td>Visual Branding Builder (Logo, Colors, Footer), Email Dispatch History Log, Quick Reply Templates (`{customer_name}`, `{product}`).</td>
                                            <td><code>Evonee Quotes ➔ Settings</code> & ➔ <code>Email Log</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>🌍 Module 3 — Multi-Currency & Pricing</strong></td>
                                            <td>Global Currency Symbols ($, €, £, ¥, ৳, AED), ISO 4217 Currency Codes, 4 Position formats, Decimal/Thousand Separator controls, and Volume Tier Breaks.</td>
                                            <td><code>Evonee Quotes ➔ Settings</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>📊 Module 4 — Analytics</strong></td>
                                            <td>Chart.js Monthly Trends Bar Chart, Status Distribution Doughnut Chart, and Conversion Funnel Cards.</td>
                                            <td><code>Evonee Quotes ➔ Analytics & Reports</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>🛒 Module 5 — WooCommerce & Direct Pay</strong></td>
                                            <td>1-Click Quote to Order Conversion, Instant Payment & Checkout button upon Customer Signature Acceptance, Conditional Quote Rules, and Bulk Cart Quote.</td>
                                            <td><code>Evonee Quotes ➔ Settings</code> & ➔ <code>Submissions</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>🎨 Module 6 — Visual Field Builder</strong></td>
                                            <td>7 dynamic No-Code field types: Text, Dropdown Select, Radio Buttons, Single Checkbox, HTML5 Date Picker, Number, and Textarea with live modal rendering & server validation.</td>
                                            <td><code>Evonee Quotes ➔ Settings ➔ Section 3</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>🔗 Module 7 — Integrations</strong></td>
                                            <td>Webhook URL endpoint (Zapier, Make, HubSpot), Google Sheets Real-Time Sync, Slack, Discord, Native Elementor Widget, and Gutenberg Block.</td>
                                            <td><code>Evonee Quotes ➔ Settings</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>🛒 Module 10 — RFQ Dynamic Quote Basket</strong></td>
                                            <td>Floating Quote Basket button, slide-out side drawer with live quantity adjusters, and 1-click bulk quote request submission.</td>
                                            <td>Site-wide Floating Widget & WooCommerce Product Pages</td>
                                        </tr>
                                        <tr>
                                            <td><strong>⚡ Module 11 — 1-Minute Setup Wizard</strong></td>
                                            <td>Guided 3-step onboarding wizard with presets for Custom Printing, B2B Wholesale, Equipment Rental, and Professional Services.</td>
                                            <td><code>Evonee Quotes ➔ ⚡ Setup Wizard</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>🎨 Module 12 — Brand Colors Customizer</strong></td>
                                            <td>Full color customization for Product Grid cards in Elementor Style tab (`Brand Colors & Styling`) and Admin settings.</td>
                                            <td><code>Evonee Quotes ➔ Settings</code> & Elementor Editor</td>
                                        </tr>
                                        <tr>
                                            <td><strong>🤖 Module 13 — AI Smart Reply Drafter</strong></td>
                                            <td>1-click AI response drafter inside submission detail drawer, generating tailored quote offers based on product specs, quantity, and lead time.</td>
                                            <td><code>Submissions Drawer ➔ 🤖 AI Draft Reply</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>⏰ Module 14 — Automated Email Drip Engine</strong></td>
                                            <td>Automated 2-stage follow-up sequence (Day 2 check-in & Day 5 expiration/discount urgency) via daily WP-Cron and 1-click manual trigger.</td>
                                            <td><code>Submissions Page ➔ ⏰ Run Drip Engine</code></td>
                                        </tr>
                                        <tr>
                                            <td><strong>💵 Module 15 — Partial Deposit & Response Velocity Analytics</strong></td>
                                            <td>Flexible deposit percentage options (e.g. 20% or 50% upfront) and lead response speed tracker in Executive Dashboard.</td>
                                            <td><code>Submissions Drawer & Executive Dashboard</code></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 2: SHORTCODES & PAGE BUILDERS -->
                    <div id="doc-tab-shortcodes" class="eq-tab-content">
                        <div class="evonee-doc-card">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-shortcode"></span>
                                <h2>1. Shortcodes, Elementor & Page Builders</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p>Use shortcodes inside Elementor's <strong>Shortcode Widget</strong>, Gutenberg blocks, or any page builder to render grids, trigger buttons, or customer portal.</p>

                                <h3>Primary Shortcodes:</h3>
                                
                                <div style="margin-bottom:14px;">
                                    <strong>1. Products Grid Shortcode:</strong>
                                    <div class="evonee-code-snippet">
                                        <code>[evonee_products cols="6" cols_tablet="3" cols_mobile="2"]</code>
                                        <button type="button" class="evonee-copy-code" data-code='[evonee_products cols="6" cols_tablet="3" cols_mobile="2"]'>Copy</button>
                                    </div>
                                </div>

                                <h3>Shortcode Parameters Reference:</h3>
                                <table class="evonee-docs-table">
                                    <thead>
                                        <tr>
                                            <th>Attribute</th>
                                            <th>Default</th>
                                            <th>Options / Format</th>
                                            <th>Description</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><code>cols</code> / <code>columns</code></td>
                                            <td><code>6</code></td>
                                            <td><code>1</code> to <code>6</code></td>
                                            <td>Number of product columns to display on Desktop viewports.</td>
                                        </tr>
                                        <tr>
                                            <td><code>cols_tablet</code></td>
                                            <td><code>3</code></td>
                                            <td><code>1</code> to <code>4</code></td>
                                            <td>Number of product columns to display on Tablet viewports.</td>
                                        </tr>
                                        <tr>
                                            <td><code>cols_mobile</code></td>
                                            <td><code>2</code></td>
                                            <td><code>1</code>, <code>2</code></td>
                                            <td>Number of product columns to display on Mobile viewports.</td>
                                        </tr>
                                        <tr>
                                            <td><code>gap</code></td>
                                            <td><code>18px</code></td>
                                            <td>e.g. <code>12px</code>, <code>20px</code></td>
                                            <td>Whitespace gap between product cards.</td>
                                        </tr>
                                        <tr>
                                            <td><code>img_height</code></td>
                                            <td><code>140px</code></td>
                                            <td>e.g. <code>140px</code>, <code>180px</code></td>
                                            <td>Thumbnail container height for uniform image alignment.</td>
                                        </tr>
                                        <tr>
                                            <td><code>limit</code></td>
                                            <td>Settings value (default <code>12</code>)</td>
                                            <td>e.g. <code>8</code>, <code>12</code>, <code>0</code></td>
                                            <td>Maximum number of products to show. <code>0</code> displays all. Overrides Settings.</td>
                                        </tr>
                                        <tr>
                                            <td><code>show_title</code></td>
                                            <td><code>no</code></td>
                                            <td><code>yes</code> / <code>no</code></td>
                                            <td>Show the grid heading. Off by default.</td>
                                        </tr>
                                        <tr>
                                            <td><code>card_style</code></td>
                                            <td><code>classic</code></td>
                                            <td><code>classic</code>, <code>floating</code>, <code>compact</code>, <code>gradient</code>, <code>horizontal</code>, <code>dark</code></td>
                                            <td>Product card design variation style modifier. Overrides Settings.</td>
                                        </tr>
                                        <tr>
                                            <td><code>badge</code></td>
                                            <td><code>(empty)</code></td>
                                            <td>e.g. <code>Popular</code>, <code>Best Seller</code>, <code>🔥 Hot</code></td>
                                            <td>Renders a floating top-right badge tag on product cards.</td>
                                        </tr>
                                        <tr>
                                            <td><code>show_price</code></td>
                                            <td><code>0</code></td>
                                            <td><code>1</code> / <code>yes</code> / <code>0</code></td>
                                            <td>Displays an estimated unit price tag badge on product cards.</td>
                                        </tr>
                                    </tbody>
                                </table>

                                <!-- Card Variations Guide Box -->
                                <div style="background:#faf5ff; border:1px solid #e9d5ff; border-radius:12px; padding:20px; margin-top:20px;">
                                    <h3 style="margin:0 0 10px; color:#6d28d9; font-size:15px; display:flex; align-items:center; gap:8px;">
                                        🎨 Product Card Design Variations Guide
                                    </h3>
                                    <p style="font-size:13px; color:#475569; margin:0 0 14px;">Choose from 6 pre-styled card variations for your product showcase grids:</p>

                                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                                        <div style="background:#ffffff; border:1px solid #e9d5ff; border-radius:8px; padding:12px;">
                                            <strong style="color:#0f172a; font-size:13px; display:block;">1. Classic Soft Pill (Default)</strong>
                                            <small style="color:#64748b; display:block; margin:2px 0 6px;">Clean white card with soft purple pill button.</small>
                                            <code style="font-size:11px; background:#f1f5f9; padding:2px 6px; border-radius:4px; display:inline-block;">[evonee_products card_style="classic"]</code>
                                        </div>

                                        <div style="background:#ffffff; border:1px solid #e9d5ff; border-radius:8px; padding:12px;">
                                            <strong style="color:#0f172a; font-size:13px; display:block;">2. Modern Floating (Shadow & Badge)</strong>
                                            <small style="color:#64748b; display:block; margin:2px 0 6px;">Elevated floating shadow with top corner badge.</small>
                                            <code style="font-size:11px; background:#f1f5f9; padding:2px 6px; border-radius:4px; display:inline-block;">[evonee_products card_style="floating" badge="Best Seller"]</code>
                                        </div>

                                        <div style="background:#ffffff; border:1px solid #e9d5ff; border-radius:8px; padding:12px;">
                                            <strong style="color:#0f172a; font-size:13px; display:block;">3. E-Commerce Compact</strong>
                                            <small style="color:#64748b; display:block; margin:2px 0 6px;">Compact vertical card with starting price tag.</small>
                                            <code style="font-size:11px; background:#f1f5f9; padding:2px 6px; border-radius:4px; display:inline-block;">[evonee_products card_style="compact" show_price="1"]</code>
                                        </div>

                                        <div style="background:#ffffff; border:1px solid #e9d5ff; border-radius:8px; padding:12px;">
                                            <strong style="color:#0f172a; font-size:13px; display:block;">4. Gradient Glass (Luxury Tech)</strong>
                                            <small style="color:#64748b; display:block; margin:2px 0 6px;">Vibrant gradient outline border and gradient CTA.</small>
                                            <code style="font-size:11px; background:#f1f5f9; padding:2px 6px; border-radius:4px; display:inline-block;">[evonee_products card_style="gradient" badge="🔥 Hot"]</code>
                                        </div>

                                        <div style="background:#ffffff; border:1px solid #e9d5ff; border-radius:8px; padding:12px;">
                                            <strong style="color:#0f172a; font-size:13px; display:block;">5. Horizontal Split (List Layout)</strong>
                                            <small style="color:#64748b; display:block; margin:2px 0 6px;">Row layout: thumbnail left, details right.</small>
                                            <code style="font-size:11px; background:#f1f5f9; padding:2px 6px; border-radius:4px; display:inline-block;">[evonee_products card_style="horizontal" show_price="1" cols="1"]</code>
                                        </div>

                                        <div style="background:#ffffff; border:1px solid #e9d5ff; border-radius:8px; padding:12px;">
                                            <strong style="color:#0f172a; font-size:13px; display:block;">6. Dark Sleek Edition</strong>
                                            <small style="color:#64748b; display:block; margin:2px 0 6px;">Dark theme container with neon purple accents.</small>
                                            <code style="font-size:11px; background:#f1f5f9; padding:2px 6px; border-radius:4px; display:inline-block;">[evonee_products card_style="dark" badge="Custom"]</code>
                                        </div>
                                    </div>
                                </div>

                                <div style="margin-top:16px; margin-bottom:14px;">
                                    <strong>2. Quote Trigger Button Shortcode:</strong>
                                    <div class="evonee-code-snippet">
                                        <code>[evonee_quote_button product="Silicone Wristband" text="Get Free Quote"]</code>
                                        <button type="button" class="evonee-copy-code" data-code='[evonee_quote_button product="Silicone Wristband" text="Get Free Quote"]'>Copy</button>
                                    </div>
                                </div>

                                <div style="background:#faf5ff; border:1px solid #e9d5ff; padding:16px; border-radius:8px; margin-top:14px; margin-bottom:16px;">
                                    <strong style="color:#6d28d9; font-size:14px; display:block; margin-bottom:6px;">🌐 How to Use Evonee Quotes Sitewide (Global Non-WooCommerce):</strong>
                                    <ul style="margin:0; padding-left:18px; font-size:13px; color:#475569; line-height:1.6;">
                                        <li><strong>Sitewide Floating Sticky Button:</strong> Enable <code>Sitewide Floating Sticky Quote Button</code> in <code>Evonee Quotes ➔ Settings</code> for a 1-click floating button on every page.</li>
                                        <li><strong>WordPress Nav Menu Item:</strong> Go to <code>Appearance ➔ Menus</code>, edit any menu item, and add CSS Class <code>eq-trigger</code> (or <code>eq-open-modal</code>).</li>
                                        <li><strong>Any Custom Button or Link:</strong> Add CSS class <code>eq-trigger</code> to any HTML element. Optionally pass <code>data-product="Custom Service"</code> to pre-fill product name.</li>
                                    </ul>
                                </div>

                                <div style="margin-bottom:14px;">
                                    <strong>3. Front-end Customer Quote Portal Shortcode:</strong>
                                    <div class="evonee-code-snippet">
                                        <code>[evonee_customer_portal]</code>
                                        <button type="button" class="evonee-copy-code" data-code='[evonee_customer_portal]'>Copy</button>
                                    </div>
                                    <p class="description">Renders a front-end portal where buyers can view their quote history, track real-time statuses, view price offers, and 1-click accept or decline offers.</p>
                                </div>

                                <h3>Native Page Builders & WooCommerce Integration:</h3>
                                <ul style="line-height:1.6; color:#475569; padding-left:20px;">
                                    <li><strong>Elementor Native Widget:</strong> Search for <code>Evonee Quote Button</code> under Elementor's <em>General</em> widget category.</li>
                                    <li><strong>Gutenberg Block:</strong> Search for <code>evonee/quote-button</code> block in WordPress block editor or Full Site Editing (FSE).</li>
                                    <li><strong>1-Click WooCommerce Order Conversion:</strong> In <code>Evonee Quotes ➔ Submissions</code>, open any quote drawer and click <code>🛒 Convert to WC Order</code> to generate a WooCommerce pending order.</li>
                                    <li><strong>Bulk Cart Quote Request:</strong> Enable <code>Bulk Cart Quote Request</code> in Settings to add a B2B quote request button on WooCommerce Cart & Checkout pages.</li>
                                </ul>

                                <h3>Enterprise Features & Customer Discussion:</h3>
                                <ul style="line-height:1.6; color:#475569; padding-left:20px;">
                                    <li><strong>✍️ Digital E-Signature:</strong> Customers can sign quote acceptances using an interactive HTML5 canvas pad on acceptance links.</li>
                                    <li><strong>💬 Quote Discussion Thread:</strong> Live messaging per quote between buyers and admin in the Customer Portal and Admin Drawer.</li>
                                    <li><strong>📄 Custom PDF Sheet Generator:</strong> Download official PDF quote sheets with Tax ID, custom accent colors, and terms.</li>
                                    <li><strong>🔔 Weekly Sales Digest:</strong> Automatic weekly sales summary email delivered every Monday via WP-Cron.</li>
                                </ul>
                            </div>
                        </div>

                        <!-- Visual Custom Field Builder Guide -->
                        <div class="evonee-doc-card">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-plus-alt2"></span>
                                <h2>2. 🎨 Visual Custom Field Builder Guide</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p>You can dynamically add unlimited custom fields to your Get Quote popup modal without writing code. Navigate to <code>Evonee Quotes ➔ Settings ➔ Section 3</code>.</p>
                                
                                <table class="evonee-docs-table">
                                    <thead>
                                        <tr>
                                            <th>Field Type</th>
                                            <th>How to Configure</th>
                                            <th>Frontend Display</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><strong>Text Input</strong></td>
                                            <td>Provide label (e.g. <em>Event Name</em>)</td>
                                            <td>Standard single-line text input.</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Dropdown Select</strong></td>
                                            <td>Comma-separated options (e.g. <em>Red, Blue, Green</em>)</td>
                                            <td>Modern styled select dropdown.</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Radio Buttons</strong></td>
                                            <td>Comma-separated options (e.g. <em>Standard, Express, Overnight</em>)</td>
                                            <td>Clean horizontal radio group with instant toggle.</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Single Checkbox</strong></td>
                                            <td>Label (e.g. <em>Include Sample Pack</em>)</td>
                                            <td>Stylish toggle checkbox. Saves as 'Yes' when checked.</td>
                                        </tr>
                                        <tr>
                                            <td><strong>HTML5 Date Picker</strong></td>
                                            <td>Label (e.g. <em>Event / Target Deadline Date</em>)</td>
                                            <td>Native calendar date picker with YYYY-MM-DD format.</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Number</strong></td>
                                            <td>Label (e.g. <em>Budget Range / Est. Guests</em>)</td>
                                            <td>Numeric input field.</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Textarea</strong></td>
                                            <td>Label (e.g. <em>Special Artwork / Engraving Specs</em>)</td>
                                            <td>Multi-line expandable textarea.</td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p class="description" style="margin-top:10px;">All custom field inputs are automatically validated on submission, saved with the lead record, displayed in the CRM Detail drawer, and included in PDF quote sheets.</p>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 3: GOOGLE SHEETS SETUP -->
                    <div id="doc-tab-gsheets" class="eq-tab-content">
                        <div class="evonee-doc-card">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-spreadsheet"></span>
                                <h2>📊 Direct Google Sheets Real-Time Auto-Sync Setup</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p>Sync all customer quote leads directly to your Google Spreadsheet in real-time:</p>
                                
                                <ol style="margin-left:20px; line-height:1.7; color:#334155;">
                                    <li>Open your <a href="https://sheets.google.com" target="_blank" style="color:#6d28d9; font-weight:bold;">Google Sheets</a> &rarr; <strong>Extensions &rarr; Apps Script</strong>.</li>
                                    <li>Replace any existing code with the snippet below:</li>
                                </ol>

                                <div class="evonee-code-snippet" style="flex-direction:column; align-items:flex-start; gap:10px;">
                                    <div style="display:flex; justify-content:space-between; width:100%;">
                                        <strong style="color:#38bdf8;">Google Apps Script Code Snippet:</strong>
                                        <button type="button" class="evonee-copy-code" data-code='function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var d = JSON.parse(e.postData.contents);
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(["ID", "Date", "Name", "Company", "Email", "Phone", "Country", "Product", "Qty", "Details", "Artwork", "Timeframe", "Specific Date", "ZIP", "Notes", "Status"]);
    }
    sheet.appendRow([d.submission_id, d.created_at, d.full_name, d.company, d.email, d.phone, d.country, d.product, d.quantity, d.product_details, d.artwork_urls, d.timeframe, d.specific_date, d.zip_code, d.project_notes, d.status]);
    return ContentService.createTextOutput(JSON.stringify({"result":"success"})).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({"result":"error", "error":err.toString()})).setMimeType(ContentService.MimeType.JSON);
  }
}'>Copy Code</button>
                                    </div>
                                    <pre style="margin:0; font-size:12px; color:#f8fafc; overflow-x:auto; width:100%;">function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var d = JSON.parse(e.postData.contents);
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(["ID", "Date", "Name", "Company", "Email", "Phone", "Country", "Product", "Qty", "Details", "Artwork", "Timeframe", "Specific Date", "ZIP", "Notes", "Status"]);
    }
    sheet.appendRow([d.submission_id, d.created_at, d.full_name, d.company, d.email, d.phone, d.country, d.product, d.quantity, d.product_details, d.artwork_urls, d.timeframe, d.specific_date, d.zip_code, d.project_notes, d.status]);
    return ContentService.createTextOutput(JSON.stringify({"result":"success"})).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({"result":"error", "error":err.toString()})).setMimeType(ContentService.MimeType.JSON);
  }
}</pre>
                                </div>

                                <ol start="3" style="margin-left:20px; line-height:1.7; color:#334155;">
                                    <li>Click <strong>Deploy &rarr; New deployment &rarr; Select Web app</strong>.</li>
                                    <li>Set <strong>Execute as:</strong> <code>Me</code> and <strong>Who has access:</strong> <code>Anyone</code>.</li>
                                    <li>Click <strong>Deploy</strong>, copy the Web App URL, and paste it under <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-settings#tab-integrations')); ?>" style="color:#6d28d9; font-weight:bold;">Settings & Modules (Integrations Tab)</a>!</li>
                                </ol>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 4: WEBHOOKS & INTEGRATIONS -->
                    <div id="doc-tab-integrations" class="eq-tab-content">
                        <div class="evonee-doc-card">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-share-alt"></span>
                                <h2>REST API, Webhook, Zapier & Slack Configuration</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p><strong>Custom WP REST API Endpoints:</strong></p>
                                <ul>
                                    <li><code>GET /wp-json/evonee/v1/quotes</code> — Retrieve latest 50 quote submissions (Admin Auth).</li>
                                    <li><code>POST /wp-json/evonee/v1/submit</code> — Submit new quote request via REST API.</li>
                                    <li><code>GET /wp-json/evonee/v1/stats</code> — Retrieve dashboard metrics and sales statistics.</li>
                                </ul>

                                <p style="margin-top:14px;"><strong>Zapier / Make / HubSpot Webhooks:</strong> Navigate to <code>Evonee Quotes ➔ Settings ➔ Integrations Tab</code>, enable Webhooks, and paste your Target Catch Webhook URL. The plugin sends the following JSON payload on submission:</p>
                                
                                <div class="evonee-code-snippet" style="flex-direction:column; align-items:flex-start; gap:10px;">
                                    <div style="display:flex; justify-content:space-between; width:100%;">
                                        <strong style="color:#38bdf8;">Sample Webhook JSON Payload:</strong>
                                        <button type="button" class="evonee-copy-code" data-code='{
  "submission_id": 42,
  "created_at": "2026-09-09 22:30:00",
  "full_name": "John Doe",
  "company": "Acme Corp",
  "email": "john@example.com",
  "phone": "+1 555-0199",
  "country": "United States",
  "product": "Silicone Wristband",
  "quantity": "500",
  "product_details": {"wristband_type":"1/2 Inch","color":"#6d28d9"},
  "artwork_urls": ["https://site.com/uploads/evonee-quotes/2026/09/logo.pdf"],
  "timeframe": "10-12 Business Days",
  "zip_code": "10001",
  "project_notes": "Urgent campaign delivery needed.",
  "status": "new"
}'>Copy JSON</button>
                                    </div>
                                    <pre style="margin:0; font-size:12px; color:#f8fafc; overflow-x:auto; width:100%;">{
  "submission_id": 42,
  "created_at": "2026-09-09 22:30:00",
  "full_name": "John Doe",
  "company": "Acme Corp",
  "email": "john@example.com",
  "phone": "+1 555-0199",
  "country": "United States",
  "product": "Silicone Wristband",
  "quantity": "500",
  "product_details": {"wristband_type":"1/2 Inch","color":"#6d28d9"},
  "artwork_urls": ["https://site.com/uploads/evonee-quotes/2026/09/logo.pdf"],
  "timeframe": "10-12 Business Days",
  "zip_code": "10001",
  "project_notes": "Urgent campaign delivery needed.",
  "status": "new"
}</pre>
                                </div>

                                <p style="margin-top:16px;"><strong>Slack Incoming Webhook:</strong> Paste your Slack Webhook URL in Settings. Every new lead instantly posts a formatted lead notification to your sales team channel.</p>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 5: SECURITY & DEVELOPER HOOKS -->
                    <div id="doc-tab-developer" class="eq-tab-content">
                        <div class="evonee-doc-card">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-shield"></span>
                                <h2>Security Architecture & Developer Action Hooks</h2>
                            </div>
                            <div class="evonee-card-body">
                                <h3>🛡️ Multi-Layer Security Architecture:</h3>
                                <ul>
                                    <li><strong>DOM-based SVG XSS Protection:</strong> SVG files are parsed using PHP <code>DOMDocument</code> XML parser with <code>LIBXML_NONET</code>. Script tags, dangerous nodes, inline <code>on*</code> attributes, and <code>javascript:</code> URIs are automatically stripped.</li>
                                    <li><strong>Google reCAPTCHA v3:</strong> Invisible spam bot protection score evaluation (&lt; 0.5 score rejection).</li>
                                    <li><strong>Honeypot & Rate Limiting:</strong> Silent honeypot field catches automated bots. Transient IP rate limiter caps requests at 5 per 15 minutes per IP.</li>
                                </ul>

                                <h3 style="margin-top:20px;">🛠️ Developer PHP Action & Filter Hooks:</h3>
                                <div class="evonee-code-snippet">
                                    <code>add_action('evonee_quote_form_custom_fields', function() { /* Custom Inputs */ });</code>
                                    <button type="button" class="evonee-copy-code" data-code="add_action('evonee_quote_form_custom_fields', function() { echo '&lt;div class=&quot;eq-field&quot;&gt;&lt;label&gt;Event Name&lt;/label&gt;&lt;input type=&quot;text&quot; name=&quot;event_name&quot;&gt;&lt;/div&gt;'; });">Copy</button>
                                </div>
                                <div class="evonee-code-snippet">
                                    <code>add_filter('evonee_notification_recipient', function($recipients) { return array_merge($recipients, ['manager@site.com']); });</code>
                                    <button type="button" class="evonee-copy-code" data-code="add_filter('evonee_notification_recipient', function($recipients) { return array_merge($recipients, ['manager@site.com']); });">Copy</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Right Sidebar Column -->
                <div class="evonee-docs-sidebar">
                    
                    <div class="evonee-sidebar-card">
                        <h3>📌 Email Notifications</h3>
                        <p>Quote request notifications are automatically dispatched to:</p>
                        <ul>
                            <li><strong>Sales Email:</strong> <code><?php echo esc_html($settings['sales_email'] ?? 'sales@evonee.com'); ?></code></li>
                            <li><strong>Admin Email:</strong> <code><?php echo esc_html(get_option('admin_email')); ?></code></li>
                        </ul>
                    </div>

                    <div class="evonee-sidebar-card">
                        <h3>📁 Upload Safety</h3>
                        <p>Uploaded artwork files are saved securely in:</p>
                        <code>wp-content/uploads/evonee-quotes/YYYY/MM/</code>
                        <p><small style="color:#94a3b8; display:block; margin-top:4px;">Supports up to 3 files: AI, PDF, EPS, SVG, PNG, JPG (Max <?php echo esc_html(size_format(wp_max_upload_size())); ?>).</small></p>
                    </div>

                    <div class="evonee-sidebar-card" style="background:linear-gradient(135deg, #faf5ff 0%, #f3e8ff 100%); border-color:#e9d5ff;">
                        <h3 style="color:#4c1d95;">💬 Need Support or Customization?</h3>
                        <p style="color:#6b21a8;">Evonee v2.0 Enterprise Plugin Documentation & Support.</p>
                        <a href="mailto:sales@evonee.com" class="button button-primary button-large" style="width:100%; text-align:center; background:linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%); border-color:#6d28d9; border-radius:8px; font-weight:700; margin-top:8px;">Contact Developer Team</a>
                    </div>

                </div>

            </div>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Tab switcher logic
            const tabBtns = document.querySelectorAll('.eq-tab-btn');
            const tabContents = document.querySelectorAll('.eq-tab-content');

            function switchTab(targetId) {
                tabBtns.forEach(btn => {
                    if (btn.getAttribute('data-tab') === targetId) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                    }
                });
                tabContents.forEach(content => {
                    if (content.id === targetId) {
                        content.classList.add('active');
                    } else {
                        content.classList.remove('active');
                    }
                });
                if (history.replaceState) {
                    history.replaceState(null, null, '#' + targetId);
                } else {
                    window.location.hash = targetId;
                }
            }

            tabBtns.forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    switchTab(this.getAttribute('data-tab'));
                });
            });

            // Restore active tab from hash
            const currentHash = window.location.hash ? window.location.hash.replace('#', '') : '';
            if (currentHash && document.getElementById(currentHash)) {
                switchTab(currentHash);
            }

            // Copy button logic
            function copyToClipboard(text) {
                if (navigator.clipboard && window.isSecureContext) {
                    return navigator.clipboard.writeText(text);
                } else {
                    return new Promise((resolve, reject) => {
                        const textArea = document.createElement('textarea');
                        textArea.value = text;
                        textArea.style.position = 'fixed';
                        textArea.style.left = '-9999px';
                        textArea.style.top = '-9999px';
                        document.body.appendChild(textArea);
                        textArea.focus();
                        textArea.select();
                        try {
                            const successful = document.execCommand('copy');
                            document.body.removeChild(textArea);
                            if (successful) {
                                resolve();
                            } else {
                                reject(new Error('Copy command failed'));
                            }
                        } catch (err) {
                            document.body.removeChild(textArea);
                            reject(err);
                        }
                    });
                }
            }

            document.addEventListener('click', function(e) {
                const btn = e.target.closest('.evonee-copy-code');
                if (!btn) return;
                e.preventDefault();

                let code = btn.getAttribute('data-code');
                if (!code && btn.previousElementSibling) {
                    code = btn.previousElementSibling.textContent.trim();
                }

                if (!code) return;

                copyToClipboard(code).then(() => {
                    const originalText = btn.textContent;
                    btn.textContent = 'Copied! ✓';
                    btn.style.background = '#16a34a';
                    setTimeout(() => {
                        btn.textContent = originalText;
                        btn.style.background = '#6d28d9';
                    }, 1500);
                }).catch(err => {
                    console.error('Copy error:', err);
                    prompt('Copy code:', code);
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Render Analytics & Reports Dashboard Page
     */
    public function render_analytics_page() {
        $settings = self::get_settings();
        if (isset($settings['enable_analytics']) && $settings['enable_analytics'] !== '1') {
            wp_safe_redirect(admin_url('admin.php?page=evonee-settings'));
            exit;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) !== $table_name) {
            Evonee_Quote_Ajax::create_submissions_table();
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $total_submissions = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions");
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $new_count         = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'new'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $quoted_count      = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'quoted'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $approved_count    = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'approved'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $completed_count   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'completed'));

        // Monthly Trend Data for Chart.js
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $monthly_trends = $wpdb->get_results("
            SELECT DATE_FORMAT(created_at, '%b %Y') as month_label, COUNT(*) as total 
            FROM {$wpdb->prefix}eq_quote_submissions 
            GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
            ORDER BY created_at ASC LIMIT 12
        ");

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $top_products = $wpdb->get_results("
            SELECT product, COUNT(*) as total
            FROM {$wpdb->prefix}eq_quote_submissions
            GROUP BY product
            ORDER BY total DESC
            LIMIT 10
        ");

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $top_countries = $wpdb->get_results("
            SELECT country, COUNT(*) as total
            FROM {$wpdb->prefix}eq_quote_submissions
            GROUP BY country
            ORDER BY total DESC
            LIMIT 10
        ");

        // Conversion Funnel Calculations (Phase 4.2)
        $pct_quoted   = $total_submissions > 0 ? round(($quoted_count / $total_submissions) * 100, 1) : 0;
        $pct_approved = $total_submissions > 0 ? round(($approved_count / $total_submissions) * 100, 1) : 0;
        $pct_completed= $total_submissions > 0 ? round(($completed_count / $total_submissions) * 100, 1) : 0;

        ?>
        <div class="wrap evonee-admin-wrap">
            <div class="evonee-docs-header" style="background: linear-gradient(135deg, #1e1b2e 0%, #4c1d95 100%);">
                <div>
                    <h1>📊 Evonee Quotes — Analytics & Business Metrics</h1>
                    <p class="subtitle">Real-time quotation pipeline overview, conversion funnel charts, and business growth insights.</p>
                </div>
                <div class="evonee-docs-brand">
                    <span>v1.0.0 Business Reports</span>
                </div>
            </div>

            <!-- Metric Stats Grid -->
            <div class="evonee-metrics-grid">
                <div class="evonee-stat-card">
                    <span class="evonee-stat-icon" style="background:#f3f0fc; color:#6d28d9;">📥</span>
                    <div>
                        <div class="evonee-stat-val"><?php echo number_format($total_submissions); ?></div>
                        <div class="evonee-stat-lbl">Total Quotes Received</div>
                    </div>
                </div>

                <div class="evonee-stat-card">
                    <span class="evonee-stat-icon" style="background:#dcfce7; color:#15803d;">🟢</span>
                    <div>
                        <div class="evonee-stat-val"><?php echo number_format($new_count); ?></div>
                        <div class="evonee-stat-lbl">New Requests</div>
                    </div>
                </div>

                <div class="evonee-stat-card">
                    <span class="evonee-stat-icon" style="background:#dbeafe; color:#1d4ed8;">🔵</span>
                    <div>
                        <div class="evonee-stat-val"><?php echo number_format($quoted_count); ?></div>
                        <div class="evonee-stat-lbl">Quotes Dispatched</div>
                    </div>
                </div>

                <div class="evonee-stat-card">
                    <span class="evonee-stat-icon" style="background:#f3e8ff; color:#6b21a8;">💜</span>
                    <div>
                        <div class="evonee-stat-val"><?php echo number_format($approved_count + $completed_count); ?></div>
                        <div class="evonee-stat-lbl">Approved & Completed</div>
                    </div>
                </div>
            </div>

            <!-- Conversion Funnel Section (Phase 4.2) -->
            <div class="evonee-doc-card" style="margin-top:20px;">
                <div class="evonee-card-header">
                    <span class="dashicons dashicons-filter"></span>
                    <h2>📉 Quote Conversion Funnel Overview</h2>
                </div>
                <div class="evonee-card-body" style="display:grid; grid-template-columns:repeat(4,1fr); gap:16px; text-align:center;">
                    <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px;">
                        <div style="font-size:12px; color:#64748b; font-weight:700;">1. Total Submissions</div>
                        <div style="font-size:24px; font-weight:800; color:#1e1b2e; margin:6px 0;"><?php echo esc_html($total_submissions); ?></div>
                        <div style="font-size:11px; color:#16a34a; font-weight:700;">100% Baseline</div>
                    </div>
                    <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:16px;">
                        <div style="font-size:12px; color:#1d4ed8; font-weight:700;">2. Quotes Dispatched</div>
                        <div style="font-size:24px; font-weight:800; color:#2563eb; margin:6px 0;"><?php echo esc_html($quoted_count); ?></div>
                        <div style="font-size:11px; color:#2563eb; font-weight:700;"><?php echo esc_html($pct_quoted); ?>% Quoted Rate</div>
                    </div>
                    <div style="background:#faf5ff; border:1px solid #e9d5ff; border-radius:8px; padding:16px;">
                        <div style="font-size:12px; color:#6b21a8; font-weight:700;">3. Customer Approved</div>
                        <div style="font-size:24px; font-weight:800; color:#7c3aed; margin:6px 0;"><?php echo esc_html($approved_count); ?></div>
                        <div style="font-size:11px; color:#7c3aed; font-weight:700;"><?php echo esc_html($pct_approved); ?>% Approval Rate</div>
                    </div>
                    <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; padding:16px;">
                        <div style="font-size:12px; color:#15803d; font-weight:700;">4. Deals Completed</div>
                        <div style="font-size:24px; font-weight:800; color:#059669; margin:6px 0;"><?php echo esc_html($completed_count); ?></div>
                        <div style="font-size:11px; color:#059669; font-weight:700;"><?php echo esc_html($pct_completed); ?>% Won Deals</div>
                    </div>
                </div>
            </div>

            <!-- Chart.js Interactive Graphs -->
            <div class="evonee-analytics-two-col" style="margin-top:20px; display:grid; grid-template-columns:2fr 1fr; gap:20px;">
                <!-- Monthly Trend Bar Chart -->
                <div class="evonee-doc-card">
                    <div class="evonee-card-header">
                        <span class="dashicons dashicons-chart-area"></span>
                        <h2>📈 Monthly Submission Trend</h2>
                    </div>
                    <div class="evonee-card-body">
                        <canvas id="monthlyTrendChart" style="max-height:280px;"></canvas>
                    </div>
                </div>

                <!-- Status Distribution Doughnut Chart -->
                <div class="evonee-doc-card">
                    <div class="evonee-card-header">
                        <span class="dashicons dashicons-chart-pie"></span>
                        <h2>🍩 Status Distribution</h2>
                    </div>
                    <div class="evonee-card-body">
                        <canvas id="statusPieChart" style="max-height:280px;"></canvas>
                    </div>
                </div>
            </div>

            <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Monthly Trend Chart
                const monthlyCtx = document.getElementById('monthlyTrendChart');
                if (monthlyCtx) {
                    const monthLabels = <?php echo wp_json_encode(array_column($monthly_trends, 'month_label') ?: ['Current Month']); ?>;
                    const monthTotals = <?php echo wp_json_encode(array_map('intval', array_column($monthly_trends, 'total')) ?: [$total_submissions]); ?>;

                    new Chart(monthlyCtx, {
                        type: 'bar',
                        data: {
                            labels: monthLabels,
                            datasets: [{
                                label: 'Submissions',
                                data: monthTotals,
                                backgroundColor: '#6d28d9',
                                borderRadius: 6
                            }]
                        },
                        options: { responsive: true, maintainAspectRatio: false }
                    });
                }

                // Status Pie Chart
                const statusCtx = document.getElementById('statusPieChart');
                if (statusCtx) {
                    new Chart(statusCtx, {
                        type: 'doughnut',
                        data: {
                            labels: ['New', 'Quoted', 'Approved', 'Completed'],
                            datasets: [{
                                data: [<?php echo esc_js(implode(',', array_map('intval', [$new_count, $quoted_count, $approved_count, $completed_count]))); ?>],
                                backgroundColor: ['#16a34a', '#2563eb', '#7c3aed', '#059669']
                            }]
                        },
                        options: { responsive: true, maintainAspectRatio: false }
                    });
                }
            });
            </script>

            <div class="evonee-analytics-two-col" style="margin-top:20px;">
                <!-- Top Products Breakdown -->
                <div class="evonee-doc-card">
                    <div class="evonee-card-header">
                        <span class="dashicons dashicons-products"></span>
                        <h2>🔥 Most Requested Products</h2>
                    </div>
                    <div class="evonee-card-body">
                        <?php if (empty($top_products)): ?>
                            <p style="color:#64748b; text-align:center;">No product data available yet.</p>
                        <?php else: ?>
                            <?php foreach ($top_products as $p): 
                                $pct = $total_submissions > 0 ? round(($p->total / $total_submissions) * 100) : 0;
                            ?>
                                <div class="evonee-bar-row">
                                    <div class="evonee-bar-lbl">
                                        <strong><?php echo esc_html($p->product); ?></strong>
                                        <span><?php echo esc_html($p->total); ?> requests (<?php echo esc_html($pct); ?>%)</span>
                                    </div>
                                    <div class="evonee-bar-track">
                                        <div class="evonee-bar-fill" style="width: <?php echo esc_attr($pct); ?>%;"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Top Countries Breakdown -->
                <div class="evonee-doc-card">
                    <div class="evonee-card-header">
                        <span class="dashicons dashicons-admin-site-alt3"></span>
                        <h2>🌍 Top Customer Locations</h2>
                    </div>
                    <div class="evonee-card-body">
                        <?php if (empty($top_countries)): ?>
                            <p style="color:#64748b; text-align:center;">No location data available yet.</p>
                        <?php else: ?>
                            <?php foreach ($top_countries as $c): 
                                $pct = $total_submissions > 0 ? round(($c->total / $total_submissions) * 100) : 0;
                            ?>
                                <div class="evonee-bar-row">
                                    <div class="evonee-bar-lbl">
                                        <strong><?php echo esc_html($c->country ?: 'Unspecified'); ?></strong>
                                        <span><?php echo esc_html($c->total); ?> quotes (<?php echo esc_html($pct); ?>%)</span>
                                    </div>
                                    <div class="evonee-bar-track">
                                        <div class="evonee-bar-fill" style="width: <?php echo esc_attr($pct); ?>%; background:#8b5cf6;"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
        <?php
    }

    /**
     * Render Plugin Settings & Module Manager Page
     */
    public function render_settings_page() {
        if (isset($_POST['eq_save_settings']) && current_user_can('manage_options') && check_admin_referer('eq_save_settings_nonce')) {
            $new_settings = [
                'sales_email'              => sanitize_email(wp_unslash($_POST['sales_email'] ?? '')),
                'currency_symbol'          => sanitize_text_field(wp_unslash($_POST['currency_symbol'] ?? '$')),
                'currency_code'            => sanitize_text_field(wp_unslash($_POST['currency_code'] ?? 'USD')),
                'currency_pos'             => sanitize_text_field(wp_unslash($_POST['currency_pos'] ?? 'left')),
                'decimal_separator'        => sanitize_text_field(wp_unslash($_POST['decimal_separator'] ?? '.')),
                'thousand_separator'       => sanitize_text_field(wp_unslash($_POST['thousand_separator'] ?? ',')),
                'decimals'                 => min(4, max(0, intval($_POST['decimals'] ?? 2))),
                'delete_data_on_uninstall' => isset($_POST['delete_data_on_uninstall']) ? '1' : '0',
                'enable_price_calc'        => isset($_POST['enable_price_calc']) ? '1' : '0',
                'enable_pdf_quote'         => isset($_POST['enable_pdf_quote']) ? '1' : '0',
                'enable_analytics'         => isset($_POST['enable_analytics']) ? '1' : '0',
                'enable_auto_reply'        => isset($_POST['enable_auto_reply']) ? '1' : '0',
                'enable_wc_auto'           => isset($_POST['enable_wc_auto']) ? '1' : '0',
                'enable_global_floating_btn' => isset($_POST['enable_global_floating_btn']) ? '1' : '0',
                'global_floating_btn_text'   => sanitize_text_field(wp_unslash($_POST['global_floating_btn_text'] ?? '💬 Request Free Quote')),
                'enable_rfq_basket'          => isset($_POST['enable_rfq_basket']) ? '1' : '0',
                'enable_whatsapp_float'      => isset($_POST['enable_whatsapp_float']) ? '1' : '0',
                'whatsapp_number'            => sanitize_text_field(wp_unslash($_POST['whatsapp_number'] ?? '8801819898893')),
                'whatsapp_default_msg'       => sanitize_text_field(wp_unslash($_POST['whatsapp_default_msg'] ?? 'Hi Evonee Team! I have a question about a custom quote.')),
                'whatsapp_float_position'    => sanitize_text_field(wp_unslash($_POST['whatsapp_float_position'] ?? 'bottom-right')),
                'show_field_company'       => isset($_POST['show_field_company']) ? '1' : '0',
                'show_field_text_specs'    => isset($_POST['show_field_text_specs']) ? '1' : '0',
                'show_field_specific_date' => isset($_POST['show_field_specific_date']) ? '1' : '0',
                'show_field_project_notes' => isset($_POST['show_field_project_notes']) ? '1' : '0',
                // Phase 3 Settings
                'enable_google_sheets'     => isset($_POST['enable_google_sheets']) ? '1' : '0',
                'google_sheets_url'        => sanitize_text_field(wp_unslash($_POST['google_sheets_url'] ?? '')),
                'enable_recaptcha'         => isset($_POST['enable_recaptcha']) ? '1' : '0',
                'recaptcha_site_key'       => sanitize_text_field(wp_unslash($_POST['recaptcha_site_key'] ?? '')),
                'recaptcha_secret_key'     => sanitize_text_field(wp_unslash($_POST['recaptcha_secret_key'] ?? '')),
                'enable_webhook'           => isset($_POST['enable_webhook']) ? '1' : '0',
                'webhook_url'              => sanitize_text_field(wp_unslash($_POST['webhook_url'] ?? '')),
                'webhook_secret'           => sanitize_text_field(wp_unslash($_POST['webhook_secret'] ?? '')),
                'enable_slack'             => isset($_POST['enable_slack']) ? '1' : '0',
                'slack_webhook_url'        => sanitize_text_field(wp_unslash($_POST['slack_webhook_url'] ?? '')),
                'enable_discord'           => isset($_POST['enable_discord']) ? '1' : '0',
                'discord_webhook_url'      => sanitize_text_field(wp_unslash($_POST['discord_webhook_url'] ?? '')),
                // Phase 5 Enterprise Settings
                'enable_auto_quoter'       => isset($_POST['enable_auto_quoter']) ? '1' : '0',
                'auto_quoter_min_qty'      => intval($_POST['auto_quoter_min_qty'] ?? 100),
                'auto_quoter_unit_price'   => floatval($_POST['auto_quoter_unit_price'] ?? 2.50),
                'enable_call_booking'      => isset($_POST['enable_call_booking']) ? '1' : '0',
                'enable_twilio_sms'        => isset($_POST['enable_twilio_sms']) ? '1' : '0',
                'twilio_sid'               => sanitize_text_field(wp_unslash($_POST['twilio_sid'] ?? '')),
                'twilio_token'             => sanitize_text_field(wp_unslash($_POST['twilio_token'] ?? '')),
                'twilio_from_number'       => sanitize_text_field(wp_unslash($_POST['twilio_from_number'] ?? '')),
                'enable_pdf_attachment'    => isset($_POST['enable_pdf_attachment']) ? '1' : '0',
                'enable_price_estimator'   => isset($_POST['enable_price_estimator']) ? '1' : '0',
                'base_quote_price'         => floatval($_POST['base_quote_price'] ?? 50.00),
                'price_per_item'           => floatval($_POST['price_per_item'] ?? 1.25),
                'enable_woocommerce_button'=> isset($_POST['enable_woocommerce_button']) ? '1' : '0',
                'woo_button_text'          => sanitize_text_field(wp_unslash($_POST['woo_button_text'] ?? 'Request a Quote')),
                'enable_wc_quote_only'     => isset($_POST['enable_wc_quote_only']) ? '1' : '0',
                'wc_quote_condition'       => sanitize_text_field(wp_unslash($_POST['wc_quote_condition'] ?? 'all')),
                'wc_hide_price'            => isset($_POST['wc_hide_price']) ? '1' : '0',
                'enable_cart_quote'        => isset($_POST['enable_cart_quote']) ? '1' : '0',
                'email_logo_url'           => esc_url_raw(wp_unslash($_POST['email_logo_url'] ?? '')),
                'email_header_color'       => sanitize_hex_color(wp_unslash($_POST['email_header_color'] ?? '')) ?: '#6d28d9',
                'email_brand_name'         => sanitize_text_field(wp_unslash($_POST['email_brand_name'] ?? '')),
                'email_footer_text'        => sanitize_text_field(wp_unslash($_POST['email_footer_text'] ?? '')),
                'products_grid_limit'      => max(0, intval($_POST['products_grid_limit'] ?? 12)),
                'product_grid_orderby'     => sanitize_text_field(wp_unslash($_POST['product_grid_orderby'] ?? 'date')),
                'product_grid_order'       => sanitize_text_field(wp_unslash($_POST['product_grid_order'] ?? 'DESC')),
                'show_products_title'      => isset($_POST['show_products_title']) ? '1' : '0',
                'card_accent_color'        => sanitize_hex_color(wp_unslash($_POST['card_accent_color'] ?? '')) ?: '#6d28d9',
                'card_border_hover_color'  => sanitize_hex_color(wp_unslash($_POST['card_border_hover_color'] ?? '')) ?: '#a78bfa',
                'card_title_color'         => sanitize_hex_color(wp_unslash($_POST['card_title_color'] ?? '')) ?: '#0f172a',
                'card_title_hover_color'   => sanitize_hex_color(wp_unslash($_POST['card_title_hover_color'] ?? '')) ?: '#6d28d9',
                'card_btn_bg'              => sanitize_hex_color(wp_unslash($_POST['card_btn_bg'] ?? '')) ?: '#f3f0fc',
                'card_btn_text'            => sanitize_hex_color(wp_unslash($_POST['card_btn_text'] ?? '')) ?: '#6d28d9',
                'card_btn_hover_bg'        => sanitize_hex_color(wp_unslash($_POST['card_btn_hover_bg'] ?? '')) ?: '#6d28d9',
                'card_btn_hover_text'      => sanitize_hex_color(wp_unslash($_POST['card_btn_hover_text'] ?? '')) ?: '#ffffff',
                'card_badge_bg'            => sanitize_hex_color(wp_unslash($_POST['card_badge_bg'] ?? '')) ?: '#7c3aed',
                'card_badge_text'          => sanitize_hex_color(wp_unslash($_POST['card_badge_text'] ?? '')) ?: '#ffffff',
                'card_price_bg'            => sanitize_hex_color(wp_unslash($_POST['card_price_bg'] ?? '')) ?: '#f0fdf4',
                'card_price_text'          => sanitize_hex_color(wp_unslash($_POST['card_price_text'] ?? '')) ?: '#16a34a',
                'pdf_company_name'         => sanitize_text_field(wp_unslash($_POST['pdf_company_name'] ?? '')),
                'pdf_tax_id'               => sanitize_text_field(wp_unslash($_POST['pdf_tax_id'] ?? '')),
                'pdf_accent_color'         => sanitize_hex_color(wp_unslash($_POST['pdf_accent_color'] ?? '')) ?: '#6d28d9',
                'pdf_terms_text'           => sanitize_textarea_field(wp_unslash($_POST['pdf_terms_text'] ?? '')),
                'enable_tiered_pricing'    => isset($_POST['enable_tiered_pricing']) ? '1' : '0',
                'tiered_price_breaks'      => sanitize_textarea_field(wp_unslash($_POST['tiered_price_breaks'] ?? '')),
            ];

            update_option('evonee_quote_settings', $new_settings);

            // Handle Custom Fields Save
            $custom_fields = [];
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            if (!empty($_POST['custom_fields']) && is_array($_POST['custom_fields'])) {
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                $raw_custom_fields = wp_unslash($_POST['custom_fields']);
                foreach ($raw_custom_fields as $cf) {
                    if (!empty($cf['label'])) {
                        $custom_fields[] = [
                            'label'    => sanitize_text_field($cf['label']),
                            'type'     => sanitize_text_field($cf['type']),
                            'options'  => sanitize_text_field($cf['options'] ?? ''),
                            'required' => !empty($cf['required']) ? 1 : 0
                        ];
                    }
                }
            }
            update_option('evonee_quote_custom_fields', $custom_fields);

            // Handle Quick Reply Templates Save (Phase 1.5)
            $reply_templates = [];
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            if (!empty($_POST['reply_templates']) && is_array($_POST['reply_templates'])) {
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                $raw_templates = wp_unslash($_POST['reply_templates']);
                foreach ($raw_templates as $tmpl) {
                    if (!empty($tmpl['title'])) {
                        $reply_templates[] = [
                            'title'   => sanitize_text_field($tmpl['title']),
                            'subject' => sanitize_text_field($tmpl['subject'] ?? ''),
                            'body'    => sanitize_textarea_field($tmpl['body'] ?? ''),
                        ];
                    }
                }
            }
            update_option('evonee_reply_templates', $reply_templates);

            wp_safe_redirect(admin_url('admin.php?page=evonee-settings&eq_notice=saved'));
            exit;
        }

        $settings = self::get_settings();
        ?>
        <div class="wrap evonee-admin-wrap">
            <?php if (isset($_GET['eq_notice']) && sanitize_text_field(wp_unslash($_GET['eq_notice'])) === 'saved'): ?>
                <div class="notice notice-success is-dismissible"><p>Evonee Quote settings saved successfully!</p></div>
            <?php endif; ?>
            <div class="evonee-docs-header" style="background: linear-gradient(135deg, #4c1d95 0%, #6d28d9 100%);">
                <div>
                    <h1>⚙️ Evonee Quote — Plugin Settings & Module Manager</h1>
                    <p class="subtitle">Enable or disable specific features, manage popup form field visibility, and set sales email preferences.</p>
                </div>
                <div class="evonee-docs-brand">
                    <span>Module Manager</span>
                </div>
            </div>

            <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=evonee-settings')); ?>">
                <?php wp_nonce_field('eq_save_settings_nonce'); ?>
                <input type="hidden" name="eq_save_settings" value="1">

                <input type="hidden" name="eq_active_tab" id="eq_active_tab" value="tab-modules">

                <!-- SaaS Tab Navigation -->
                <div class="eq-tabs-nav">
                    <button type="button" class="eq-tab-btn active" data-tab="tab-modules">
                        <span class="dashicons dashicons-admin-settings"></span> Modules & Form Fields
                    </button>
                    <button type="button" class="eq-tab-btn" data-tab="tab-builder">
                        <span class="dashicons dashicons-plus-alt2"></span> Custom Field Builder
                    </button>
                    <button type="button" class="eq-tab-btn" data-tab="tab-email">
                        <span class="dashicons dashicons-email-alt"></span> Email & Branding
                    </button>
                    <button type="button" class="eq-tab-btn" data-tab="tab-integrations">
                        <span class="dashicons dashicons-share"></span> Integrations & Security
                    </button>
                </div>

                <div class="evonee-docs-grid" style="grid-template-columns: 1fr;">
                    <div class="evonee-docs-main">

                        <!-- TAB 1: MODULES & FORM FIELDS -->
                        <div id="tab-modules" class="eq-tab-content active">

                            <!-- Module Toggles Card -->
                            <div class="evonee-doc-card">
                                <div class="evonee-card-header">
                                    <span class="dashicons dashicons-admin-settings"></span>
                                    <h2>1. Module Feature Toggles (ON / OFF)</h2>
                                </div>
                                <div class="evonee-card-body">
                                
                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>💡 Live Instant Price Calculator</strong>
                                        <p>Displays a real-time unit price and total price estimate card in the modal sidebar as customers change quantity or options.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_price_calc" value="1" <?php checked($settings['enable_price_calc'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>📄 1-Click Printable / PDF Quote Sheet</strong>
                                        <p>Generates official printable quote sheets for customers from the Submissions table with 1 click.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_pdf_quote" value="1" <?php checked($settings['enable_pdf_quote'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>📊 Analytics & Business Reports Dashboard</strong>
                                        <p>Enables the Analytics & Reports admin submenu with graphs of top requested products and customer locations.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_analytics" value="1" <?php checked($settings['enable_analytics'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>📧 Customer Auto-Reply Email</strong>
                                        <p>Sends an automated branded confirmation email to customers immediately after they submit a quote request.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_auto_reply" value="1" <?php checked($settings['enable_auto_reply'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>🛒 WooCommerce Auto-Integration</strong>
                                        <p>Automatically appends the "Get Quote" button to WooCommerce shop loop items if WooCommerce is active.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_wc_auto" value="1" <?php checked($settings['enable_wc_auto'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>🌐 Sitewide Floating Sticky Quote Button (Global Non-WooCommerce)</strong>
                                        <p>Displays a floating sticky action button in the bottom corner of every page to open the quote modal anywhere on the site.</p>
                                        <div style="margin-top:6px;">
                                            <input type="text" name="global_floating_btn_text" value="<?php echo esc_attr($settings['global_floating_btn_text'] ?? '💬 Request Free Quote'); ?>" placeholder="Button Label (e.g. 💬 Request Free Quote)" style="font-size:12px; padding:4px 8px; width:220px; border:1px solid #cbd5e1; border-radius:4px;">
                                        </div>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_global_floating_btn" value="1" <?php checked($settings['enable_global_floating_btn'] ?? '1', '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row" style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:10px; padding:16px; margin:12px 0;">
                                    <div class="evonee-setting-info" style="width:100%;">
                                        <strong style="color:#15803d; font-size:14px;">💬 Floating WhatsApp Quick Chat Button (ON / OFF)</strong>
                                        <p style="color:#166534; font-size:12px; margin-top:2px;">Displays a floating WhatsApp button on every page for instant customer chat inquiries.</p>
                                        <div style="margin-top:10px; display:grid; grid-template-columns:1fr 1.5fr 1fr; gap:12px; max-width:750px;">
                                            <div>
                                                <label style="font-size:11.5px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">WhatsApp Number (with Country Code):</label>
                                                <input type="text" name="whatsapp_number" value="<?php echo esc_attr($settings['whatsapp_number'] ?? '8801819898893'); ?>" placeholder="e.g. 8801819898893" style="font-size:12px; padding:6px 10px; width:100%; border:1px solid #cbd5e1; border-radius:6px; background:#ffffff;">
                                            </div>
                                            <div>
                                                <label style="font-size:11.5px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">Default Greeting Text:</label>
                                                <input type="text" name="whatsapp_default_msg" value="<?php echo esc_attr($settings['whatsapp_default_msg'] ?? 'Hi Evonee Team! I have a question about a custom quote.'); ?>" placeholder="Default chat greeting" style="font-size:12px; padding:6px 10px; width:100%; border:1px solid #cbd5e1; border-radius:6px; background:#ffffff;">
                                            </div>
                                            <div>
                                                <label style="font-size:11.5px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">Button Screen Position:</label>
                                                <select name="whatsapp_float_position" style="font-size:12px; padding:6px 10px; width:100%; border:1px solid #cbd5e1; border-radius:6px; background:#ffffff;">
                                                    <option value="bottom-right" <?php selected($settings['whatsapp_float_position'] ?? 'bottom-right', 'bottom-right'); ?>>Bottom Right</option>
                                                    <option value="bottom-left" <?php selected($settings['whatsapp_float_position'] ?? 'bottom-right', 'bottom-left'); ?>>Bottom Left</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <label class="evonee-toggle" style="margin-left:16px;">
                                        <input type="checkbox" name="enable_whatsapp_float" value="1" <?php checked($settings['enable_whatsapp_float'] ?? '1', '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                <div class="evonee-setting-row" style="background:#faf5ff; border:1px solid #e9d5ff; border-radius:10px; padding:16px; margin:12px 0;">
                                    <div class="evonee-setting-info">
                                        <strong style="color:#6d28d9; font-size:14px;">🛒 RFQ Dynamic Quote Basket & Side Drawer (ON / OFF)</strong>
                                        <p style="color:#5b21b6; font-size:12px; margin-top:2px;">Displays the floating "Quote Basket" button and slide-out side drawer for customers to collect multiple items and request bulk quotes.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_rfq_basket" value="1" <?php checked($settings['enable_rfq_basket'] ?? '1', '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>🛍️ WooCommerce "Quote Only" Mode</strong>
                                        <p>Hides traditional "Add to Cart" buttons and forces products into Quote-Only mode for custom B2B pricing.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_wc_quote_only" value="1" <?php checked($settings['enable_wc_quote_only'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>🎯 WooCommerce Quote Trigger Condition</strong>
                                        <p>Choose when to trigger Quote mode on WooCommerce product pages.</p>
                                    </div>
                                    <select name="wc_quote_condition" style="min-width:180px;">
                                        <option value="all" <?php selected($settings['wc_quote_condition'], 'all'); ?>>All Products & Catalog</option>
                                        <option value="out_of_stock" <?php selected($settings['wc_quote_condition'], 'out_of_stock'); ?>>Out of Stock Products Only</option>
                                        <option value="guests" <?php selected($settings['wc_quote_condition'], 'guests'); ?>>Guest / Unauthenticated Users Only</option>
                                    </select>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>🙈 Hide Product Prices (Call for Quote)</strong>
                                        <p>Hides traditional WooCommerce product price display and replaces with "Price Available Upon Quote".</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="wc_hide_price" value="1" <?php checked($settings['wc_hide_price'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>🛒 Enable Bulk Cart Quote Request (Cart & Checkout)</strong>
                                        <p>Appends a "Request Quote for Cart" button on WooCommerce Cart & Checkout pages to convert cart contents into a bulk B2B quote request.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_cart_quote" value="1" <?php checked($settings['enable_cart_quote'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                            </div>
                        </div>

                        <!-- Form Fields Manager Card -->
                        <div class="evonee-doc-card" style="margin-top: 20px;">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-forms"></span>
                                <h2>2. Popup Form Fields Manager (Show / Hide Fields)</h2>
                            </div>
                            <div class="evonee-card-body">
                                
                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>🏢 Company Name Field (Section 1)</strong>
                                        <p>Displays an optional "Company Name" input field in the contact information section.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="show_field_company" value="1" <?php checked($settings['show_field_company'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>✍️ Debossed Text & Text Color Fields (Section 3)</strong>
                                        <p>Displays optional text inputs for custom debossed/embossed text and custom text colors.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="show_field_text_specs" value="1" <?php checked($settings['show_field_text_specs'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>📅 Need by Specific Date Field (Section 5)</strong>
                                        <p>Displays an optional date picker for customers requiring products by an exact calendar date.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="show_field_specific_date" value="1" <?php checked($settings['show_field_specific_date'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div class="evonee-setting-row">
                                    <div class="evonee-setting-info">
                                        <strong>📝 Tell Us About Your Project Textarea (Section 6)</strong>
                                        <p>Displays an optional project requirements textarea for custom instructions or packaging details.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="show_field_project_notes" value="1" <?php checked($settings['show_field_project_notes'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                </div>
                            </div>
                        </div> <!-- End #tab-modules -->

                        <!-- TAB 2: CUSTOM FIELD BUILDER -->
                        <div id="tab-builder" class="eq-tab-content">
                            <div class="evonee-doc-card">
                                <div class="evonee-card-header">
                                    <span class="dashicons dashicons-plus-alt2"></span>
                                    <h2>2. 🎨 Visual Custom Field Builder (No-Code)</h2>
                                </div>
                            <div class="evonee-card-body">
                                <p style="color:#64748b; font-size:13px; margin-top:0;">Add custom fields to the Get Quote popup modal without writing code. Fields render automatically in the form and save to customer submissions.</p>

                                <div id="eq-custom-fields-list">
                                    <?php 
                                    $custom_fields = get_option('evonee_quote_custom_fields', []);
                                    if (!empty($custom_fields) && is_array($custom_fields)):
                                        foreach ($custom_fields as $index => $field):
                                    ?>
                                        <div class="eq-custom-field-item" style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px 14px; margin-bottom:12px; display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                                            <div style="flex:2; min-width:180px;">
                                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Field Label:</label>
                                                <input type="text" name="custom_fields[<?php echo esc_attr($index); ?>][label]" value="<?php echo esc_attr($field['label']); ?>" placeholder="e.g. Event Name" class="widefat" required>
                                            </div>
                                            <div style="flex:1; min-width:130px;">
                                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Field Type:</label>
                                                <select name="custom_fields[<?php echo esc_attr($index); ?>][type]" class="widefat">
                                                    <option value="text" <?php selected($field['type'], 'text'); ?>>Text Input</option>
                                                    <option value="select" <?php selected($field['type'], 'select'); ?>>Dropdown Select</option>
                                                    <option value="radio" <?php selected($field['type'], 'radio'); ?>>Radio Buttons</option>
                                                    <option value="checkbox" <?php selected($field['type'], 'checkbox'); ?>>Single Checkbox</option>
                                                    <option value="number" <?php selected($field['type'], 'number'); ?>>Number</option>
                                                    <option value="date" <?php selected($field['type'], 'date'); ?>>Date Picker</option>
                                                    <option value="textarea" <?php selected($field['type'], 'textarea'); ?>>Textarea</option>
                                                </select>
                                            </div>
                                            <div style="flex:2; min-width:180px;">
                                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Options (for Select dropdown):</label>
                                                <input type="text" name="custom_fields[<?php echo esc_attr($index); ?>][options]" value="<?php echo esc_attr(isset($field['options']) ? $field['options'] : ''); ?>" placeholder="Option 1, Option 2, Option 3" class="widefat">
                                            </div>
                                            <div style="flex:0 0 auto; padding-top:14px;">
                                                <label style="font-size:12px; font-weight:600;"><input type="checkbox" name="custom_fields[<?php echo esc_attr($index); ?>][required]" value="1" <?php checked(!empty($field['required'])); ?>> Required</label>
                                            </div>
                                            <div style="flex:0 0 auto; padding-top:14px;">
                                                <button type="button" class="button button-link-delete eq-remove-field-btn">&times; Delete</button>
                                            </div>
                                        </div>
                                    <?php 
                                        endforeach;
                                    endif; 
                                    ?>
                                </div>

                                <button type="button" id="eq-add-custom-field-btn" class="button button-secondary" style="margin-top:6px;">➕ Add Custom Field</button>
                            </div>
                        </div>
                        </div> <!-- End #tab-builder -->

                        <!-- TAB 3: EMAIL & BRANDING -->
                        <div id="tab-email" class="eq-tab-content">
                            <!-- General Configuration Card -->
                            <div class="evonee-doc-card">
                                <div class="evonee-card-header">
                                    <span class="dashicons dashicons-email-alt"></span>
                                    <h2>3. General Email & Pricing Configuration</h2>
                                </div>
                            <div class="evonee-card-body">
                                
                                <div style="margin-bottom: 16px;">
                                    <label style="font-weight:700; display:block; margin-bottom:6px;">Sales Notification Recipient Email:</label>
                                    <input type="email" name="sales_email" value="<?php echo esc_attr($settings['sales_email']); ?>" class="regular-text" required>
                                    <p class="description">All incoming customer quote request notifications will be sent to this email address.</p>
                                </div>

                                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px;">
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Currency Symbol:</label>
                                        <input type="text" name="currency_symbol" value="<?php echo esc_attr($settings['currency_symbol'] ?? '$'); ?>" class="regular-text" placeholder="$" required>
                                        <p class="description">Symbol displayed in UI & PDFs (e.g. $, €, £, ¥, ৳, AED, ₹, kr).</p>
                                    </div>
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Currency Code (ISO 4217):</label>
                                        <input type="text" name="currency_code" value="<?php echo esc_attr($settings['currency_code'] ?? 'USD'); ?>" class="regular-text" placeholder="USD" maxlength="4">
                                        <p class="description">Three-letter ISO currency code (e.g. USD, EUR, GBP, AUD, CAD).</p>
                                    </div>
                                </div>

                                <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:16px;">
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Currency Position:</label>
                                        <select name="currency_pos" class="widefat">
                                            <option value="left" <?php selected($settings['currency_pos'] ?? 'left', 'left'); ?>>Left ($99.00)</option>
                                            <option value="right" <?php selected($settings['currency_pos'] ?? 'left', 'right'); ?>>Right (99.00$)</option>
                                            <option value="left_space" <?php selected($settings['currency_pos'] ?? 'left', 'left_space'); ?>>Left with space ($ 99.00)</option>
                                            <option value="right_space" <?php selected($settings['currency_pos'] ?? 'left', 'right_space'); ?>>Right with space (99.00 $)</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Decimal Separator:</label>
                                        <input type="text" name="decimal_separator" value="<?php echo esc_attr($settings['decimal_separator'] ?? '.'); ?>" style="width:60px;">
                                    </div>
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Thousand Separator:</label>
                                        <input type="text" name="thousand_separator" value="<?php echo esc_attr($settings['thousand_separator'] ?? ','); ?>" style="width:60px;">
                                    </div>
                                </div>

                                <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:16px; margin-bottom:16px;">
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Number of Decimals:</label>
                                        <input type="number" name="decimals" value="<?php echo esc_attr($settings['decimals'] ?? 2); ?>" min="0" max="4" style="width:70px;">
                                        <p class="description">For non-decimal currencies (JPY, KRW).</p>
                                    </div>
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Grid — Items to Display:</label>
                                        <input type="number" name="products_grid_limit" value="<?php echo esc_attr($settings['products_grid_limit']); ?>" min="0" max="100" style="width:80px;" required>
                                        <p class="description">Products count in <code>[evonee_products]</code>.</p>
                                    </div>
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Default Order By:</label>
                                        <select name="product_grid_orderby" style="width:100%;">
                                            <option value="date" <?php selected($settings['product_grid_orderby'] ?? 'date', 'date'); ?>>Date Created (Default)</option>
                                            <option value="menu_order" <?php selected($settings['product_grid_orderby'] ?? '', 'menu_order'); ?>>Menu Order (Custom Admin Order)</option>
                                            <option value="title" <?php selected($settings['product_grid_orderby'] ?? '', 'title'); ?>>Product Title (A-Z)</option>
                                            <option value="price" <?php selected($settings['product_grid_orderby'] ?? '', 'price'); ?>>Product Price</option>
                                            <option value="popularity" <?php selected($settings['product_grid_orderby'] ?? '', 'popularity'); ?>>Popularity (Top Sales)</option>
                                            <option value="rand" <?php selected($settings['product_grid_orderby'] ?? '', 'rand'); ?>>Random Shuffle</option>
                                        </select>
                                        <p class="description">WooCommerce query order parameter.</p>
                                    </div>
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:6px;">Order Direction:</label>
                                        <select name="product_grid_order" style="width:100%;">
                                            <option value="DESC" <?php selected(strtoupper($settings['product_grid_order'] ?? 'DESC'), 'DESC'); ?>>Descending (High to Low / Newest First)</option>
                                            <option value="ASC" <?php selected(strtoupper($settings['product_grid_order'] ?? ''), 'ASC'); ?>>Ascending (Low to High / Oldest First)</option>
                                        </select>
                                        <p class="description">Sorting direction (ASC/DESC).</p>
                                    </div>
                                </div>

                                <div class="evonee-setting-row" style="border-bottom:none; padding-bottom:0;">
                                    <div class="evonee-setting-info">
                                        <strong>Show Product Grid Title</strong>
                                        <p>Displays the "Popular Products" heading above the grid. Off by default.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="show_products_title" value="1" <?php checked($settings['show_products_title'], '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div style="margin-top:20px; padding-top:20px; border-top:1px solid #e2e8f0;">
                                    <h3 style="margin:0 0 12px; font-size:15px; font-weight:700; color:#3b0764;">🎨 Product Grid Brand Colors Customizer</h3>
                                    <p class="description" style="margin-bottom:16px;">Customize default colors for product cards to match your store brand styling.</p>

                                    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px; margin-bottom:16px;">
                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Top Accent Color:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_accent_color" value="<?php echo esc_attr($settings['card_accent_color'] ?? '#6d28d9'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_accent_color'] ?? '#6d28d9'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Card Hover Border Color:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_border_hover_color" value="<?php echo esc_attr($settings['card_border_hover_color'] ?? '#a78bfa'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_border_hover_color'] ?? '#a78bfa'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Title Normal Color:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_title_color" value="<?php echo esc_attr($settings['card_title_color'] ?? '#0f172a'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_title_color'] ?? '#0f172a'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Title Hover Color:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_title_hover_color" value="<?php echo esc_attr($settings['card_title_hover_color'] ?? '#6d28d9'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_title_hover_color'] ?? '#6d28d9'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Button Background:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_btn_bg" value="<?php echo esc_attr($settings['card_btn_bg'] ?? '#f3f0fc'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_btn_bg'] ?? '#f3f0fc'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Button Text Color:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_btn_text" value="<?php echo esc_attr($settings['card_btn_text'] ?? '#6d28d9'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_btn_text'] ?? '#6d28d9'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Button Hover Background:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_btn_hover_bg" value="<?php echo esc_attr($settings['card_btn_hover_bg'] ?? '#6d28d9'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_btn_hover_bg'] ?? '#6d28d9'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Button Hover Text:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_btn_hover_text" value="<?php echo esc_attr($settings['card_btn_hover_text'] ?? '#ffffff'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_btn_hover_text'] ?? '#ffffff'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Badge Background:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_badge_bg" value="<?php echo esc_attr($settings['card_badge_bg'] ?? '#7c3aed'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_badge_bg'] ?? '#7c3aed'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Badge Text Color:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_badge_text" value="<?php echo esc_attr($settings['card_badge_text'] ?? '#ffffff'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_badge_text'] ?? '#ffffff'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Price Tag Background:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_price_bg" value="<?php echo esc_attr($settings['card_price_bg'] ?? '#f0fdf4'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_price_bg'] ?? '#f0fdf4'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>

                                        <div>
                                            <label style="font-weight:600; display:block; margin-bottom:4px; font-size:12.5px;">Price Tag Text Color:</label>
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <input type="color" name="card_price_text" value="<?php echo esc_attr($settings['card_price_text'] ?? '#16a34a'); ?>" style="width:36px; height:36px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
                                                <input type="text" value="<?php echo esc_attr($settings['card_price_text'] ?? '#16a34a'); ?>" class="regular-text" style="width:100px; font-family:monospace;" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="evonee-setting-row" style="border-top:1px solid #e2e8f0; margin-top:12px; padding-top:12px; border-bottom:none; padding-bottom:0;">
                                    <div class="evonee-setting-info">
                                        <strong>Data Cleanup on Uninstallation</strong>
                                        <p style="color:#ef4444;">Erase all plugin database tables, logs, and settings when deleted from WordPress Plugins list.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="delete_data_on_uninstall" value="1" <?php checked($settings['delete_data_on_uninstall'] ?? '0', '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                            </div>
                        </div>

                        <!-- Email Template Builder (Phase 1.4) -->
                        <div class="evonee-doc-card" style="margin-top:20px;">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-email-alt"></span>
                                <h2>5. Email Template Branding</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p>Customize how your notification and auto-reply emails look. Changes apply to both admin and customer emails.</p>

                                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:14px;">
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:4px;">Brand Name:</label>
                                        <input type="text" name="email_brand_name" value="<?php echo esc_attr($settings['email_brand_name']); ?>" class="widefat" placeholder="Evonee">
                                        <p class="description">Shown in email header (e.g. "EVONEE").</p>
                                    </div>
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:4px;">Header Color:</label>
                                        <div style="display:flex; gap:8px; align-items:center;">
                                            <input type="color" name="email_header_color" value="<?php echo esc_attr($settings['email_header_color']); ?>" style="height:36px; width:60px; cursor:pointer; border:1px solid #d1d5db; border-radius:4px;">
                                            <input type="text" id="email-header-color-text" value="<?php echo esc_attr($settings['email_header_color']); ?>" style="width:90px; font-family:monospace;" placeholder="#6d28d9">
                                        </div>
                                        <p class="description">Email header background color.</p>
                                    </div>
                                </div>

                                <div style="margin-bottom:14px;">
                                    <label style="font-weight:700; display:block; margin-bottom:4px;">Logo Image URL:</label>
                                    <input type="url" name="email_logo_url" value="<?php echo esc_attr($settings['email_logo_url']); ?>" class="widefat" placeholder="https://yoursite.com/logo.png">
                                    <p class="description">Paste a full image URL. Leave blank to use text brand name. Recommended: 200×60px PNG with transparent background.</p>
                                </div>

                                <div>
                                    <label style="font-weight:700; display:block; margin-bottom:4px;">Email Footer Text:</label>
                                    <input type="text" name="email_footer_text" value="<?php echo esc_attr($settings['email_footer_text']); ?>" class="widefat" placeholder="Evonee Promotional Products • sales@evonee.com">
                                    <p class="description">Shown at the bottom of every email.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Quick Reply Templates (Phase 1.5) -->
                        <div class="evonee-doc-card" style="margin-top:20px;">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-format-chat"></span>
                                <h2>6. Quick Reply Email Templates</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p>Add pre-written email templates for common responses. Templates appear as a dropdown in the "Reply to Customer" modal. Use variables: <code>{customer_name}</code>, <code>{product}</code>, <code>{quote_id}</code>.</p>

                                <div id="eq-reply-templates-list">
                                    <?php
                                    $saved_templates = get_option('evonee_reply_templates', []);
                                    foreach ($saved_templates as $ti => $tmpl): ?>
                                    <div class="eq-reply-template-item" style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:14px; margin-bottom:12px;">
                                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:8px;">
                                            <div>
                                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Template Name:</label>
                                                <input type="text" name="reply_templates[<?php echo esc_attr($ti); ?>][title]" value="<?php echo esc_attr($tmpl['title']); ?>" class="widefat" placeholder="e.g. Standard Quote" required>
                                            </div>
                                            <div>
                                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Email Subject:</label>
                                                <input type="text" name="reply_templates[<?php echo esc_attr($ti); ?>][subject]" value="<?php echo esc_attr($tmpl['subject']); ?>" class="widefat" placeholder="Your Quote for {product} - Evonee">
                                            </div>
                                        </div>
                                        <div>
                                            <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Email Body:</label>
                                            <textarea name="reply_templates[<?php echo esc_attr($ti); ?>][body]" rows="4" class="widefat" placeholder="Hi {customer_name},..."><?php echo esc_textarea($tmpl['body']); ?></textarea>
                                        </div>
                                        <div style="text-align:right; margin-top:6px;">
                                            <button type="button" class="button button-link-delete eq-remove-template-btn">✕ Remove</button>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>

                                <button type="button" id="eq-add-reply-template-btn" class="button button-secondary">+ Add New Template</button>
                            </div>
                        </div>
                        </div> <!-- End #tab-email -->

                        <!-- TAB 4: INTEGRATIONS & SECURITY -->
                        <div id="tab-integrations" class="eq-tab-content">
                            <!-- Security & Integrations Card (Phase 3) -->
                            <div class="evonee-doc-card">
                                <div class="evonee-card-header">
                                    <span class="dashicons dashicons-shield"></span>
                                    <h2>4. Security & Integrations (Google Sheets, reCAPTCHA v3, Webhooks, Slack & Discord)</h2>
                                </div>
                            <div class="evonee-card-body">
                                
                                <!-- Google Sheets Sync -->
                                <div style="margin-bottom:20px; border-bottom:1px solid #e2e8f0; padding-bottom:16px;">
                                    <div class="evonee-setting-row" style="margin-bottom:10px;">
                                        <div class="evonee-setting-info">
                                            <strong>📊 Direct Google Sheets Auto-Sync</strong>
                                            <p>Automatically push every incoming client quote lead directly to your Google Spreadsheet in real-time!</p>
                                        </div>
                                        <label class="evonee-toggle">
                                            <input type="checkbox" name="enable_google_sheets" value="1" <?php checked(isset($settings['enable_google_sheets']) ? $settings['enable_google_sheets'] : '0', '1'); ?>>
                                            <span class="evonee-slider"></span>
                                        </label>
                                    </div>
                                    <div>
                                        <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Google Sheets Webhook URL:</label>
                                        <input type="url" name="google_sheets_url" value="<?php echo esc_attr(isset($settings['google_sheets_url']) ? $settings['google_sheets_url'] : ''); ?>" class="widefat" placeholder="https://script.google.com/macros/s/AKfycb.../exec">
                                        <p class="description" style="margin-top:4px;">Paste your Google Apps Script Webhook URL. <a href="#" onclick="alert('Google Sheets 1-Minute Setup Guide:\n\n1. Open your Google Sheet -> Extensions -> Apps Script.\n2. Paste this code:\n\nfunction doPost(e) {\n  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();\n  var d = JSON.parse(e.postData.contents);\n  if (sheet.getLastRow() === 0) {\n    sheet.appendRow([\"ID\", \"Date\", \"Name\", \"Company\", \"Email\", \"Phone\", \"Country\", \"Product\", \"Qty\", \"Details\", \"Artwork\", \"Timeframe\", \"Specific Date\", \"ZIP\", \"Notes\", \"Status\"]);\n  }\n  sheet.appendRow([d.submission_id, d.created_at, d.full_name, d.company, d.email, d.phone, d.country, d.product, d.quantity, d.product_details, d.artwork_urls, d.timeframe, d.specific_date, d.zip_code, d.project_notes, d.status]);\n  return ContentService.createTextOutput(JSON.stringify({\"result\":\"success\"})).setMimeType(ContentService.MimeType.JSON);\n}\n\n3. Click Deploy -> New deployment -> Select Web app -> Execute as: Me -> Who has access: Anyone -> Deploy!'); return false;" style="color:#6d28d9; font-weight:bold;">📖 Click for 1-Minute Setup Instructions & Apps Script Code</a></p>
                                    </div>
                                </div>

                                <!-- reCAPTCHA v3 -->
                                <div style="margin-bottom:20px; border-bottom:1px solid #e2e8f0; padding-bottom:16px;">
                                    <div class="evonee-setting-row" style="margin-bottom:10px;">
                                        <div class="evonee-setting-info">
                                            <strong>🛡️ Google reCAPTCHA v3 Integration</strong>
                                            <p>Protect quote modal from spam bots using invisible Google reCAPTCHA v3.</p>
                                        </div>
                                        <label class="evonee-toggle">
                                            <input type="checkbox" name="enable_recaptcha" value="1" <?php checked($settings['enable_recaptcha'], '1'); ?>>
                                            <span class="evonee-slider"></span>
                                        </label>
                                    </div>
                                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                                        <div>
                                            <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Site Key:</label>
                                            <input type="text" name="recaptcha_site_key" value="<?php echo esc_attr($settings['recaptcha_site_key']); ?>" class="widefat" placeholder="Google reCAPTCHA v3 Site Key">
                                        </div>
                                        <div>
                                            <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Secret Key:</label>
                                            <input type="text" name="recaptcha_secret_key" value="<?php echo esc_attr($settings['recaptcha_secret_key']); ?>" class="widefat" placeholder="Google reCAPTCHA v3 Secret Key">
                                        </div>
                                    </div>
                                </div>

                                 <!-- Webhook / Zapier -->
                                <div style="margin-bottom:20px; border-bottom:1px solid #e2e8f0; padding-bottom:16px;">
                                    <div class="evonee-setting-row" style="margin-bottom:10px;">
                                        <div class="evonee-setting-info">
                                            <strong>🔗 Outgoing CRM Webhook (Zapier / Make / HubSpot)</strong>
                                            <p>Automatically send a JSON POST request payload with optional HMAC SHA256 signature when a quote is submitted.</p>
                                        </div>
                                        <label class="evonee-toggle">
                                            <input type="checkbox" name="enable_webhook" value="1" <?php checked($settings['enable_webhook'], '1'); ?>>
                                            <span class="evonee-slider"></span>
                                        </label>
                                    </div>
                                    <div style="display:grid; grid-template-columns: 2fr 1fr; gap: 12px;">
                                        <div>
                                            <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Webhook Target URL:</label>
                                            <input type="url" name="webhook_url" value="<?php echo esc_attr($settings['webhook_url']); ?>" class="widefat" placeholder="https://hooks.zapier.com/hooks/catch/...">
                                        </div>
                                        <div>
                                            <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">HMAC Secret Key (Optional):</label>
                                            <input type="text" name="webhook_secret" value="<?php echo esc_attr($settings['webhook_secret'] ?? ''); ?>" class="widefat" placeholder="Secret Key for X-Evonee-Signature">
                                        </div>
                                    </div>
                                </div>

                                <!-- Slack Notification -->
                                <div style="margin-bottom:20px; border-bottom:1px solid #e2e8f0; padding-bottom:16px;">
                                    <div class="evonee-setting-row" style="margin-bottom:10px;">
                                        <div class="evonee-setting-info">
                                            <strong>💬 Slack Channel Notifications</strong>
                                            <p>Send formatted lead notifications directly to a Slack channel when a new quote is received.</p>
                                        </div>
                                        <label class="evonee-toggle">
                                            <input type="checkbox" name="enable_slack" value="1" <?php checked($settings['enable_slack'], '1'); ?>>
                                            <span class="evonee-slider"></span>
                                        </label>
                                    </div>
                                    <div>
                                        <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Slack Incoming Webhook URL:</label>
                                        <input type="url" name="slack_webhook_url" value="<?php echo esc_attr($settings['slack_webhook_url']); ?>" class="widefat" placeholder="https://hooks.slack.com/services/T00/B00/XXX">
                                    </div>
                                </div>

                                <!-- Discord Notification -->
                                <div style="margin-bottom:20px;">
                                    <div class="evonee-setting-row" style="margin-bottom:10px;">
                                        <div class="evonee-setting-info">
                                            <strong>🎮 Discord Server Notifications</strong>
                                            <p>Send styled embed alert cards to your sales Discord channel in real-time.</p>
                                        </div>
                                        <label class="evonee-toggle">
                                            <input type="checkbox" name="enable_discord" value="1" <?php checked(isset($settings['enable_discord']) ? $settings['enable_discord'] : '0', '1'); ?>>
                                            <span class="evonee-slider"></span>
                                        </label>
                                    </div>
                                    <div>
                                        <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Discord Webhook URL:</label>
                                        <input type="url" name="discord_webhook_url" value="<?php echo esc_attr(isset($settings['discord_webhook_url']) ? $settings['discord_webhook_url'] : ''); ?>" class="widefat" placeholder="https://discord.com/api/webhooks/...">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- PDF Customizer Card (Step 3) -->
                        <div class="evonee-doc-card" style="margin-top:20px;">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-pdf"></span>
                                <h2>8. PDF Quote Sheet Customizer & Branding</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p>Customize the official PDF quote sheet generated for customers and printable quotes.</p>

                                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:14px;">
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:4px;">Company Name on PDF:</label>
                                        <input type="text" name="pdf_company_name" value="<?php echo esc_attr($settings['pdf_company_name'] ?? ''); ?>" class="widefat" placeholder="Evonee Promotional Products">
                                    </div>
                                    <div>
                                        <label style="font-weight:700; display:block; margin-bottom:4px;">Tax / VAT / Business ID:</label>
                                        <input type="text" name="pdf_tax_id" value="<?php echo esc_attr($settings['pdf_tax_id'] ?? ''); ?>" class="widefat" placeholder="VAT-123456789 / EIN">
                                    </div>
                                </div>

                                <div style="margin-bottom:14px;">
                                    <label style="font-weight:700; display:block; margin-bottom:4px;">PDF Header Accent Color:</label>
                                    <input type="color" name="pdf_accent_color" value="<?php echo esc_attr($settings['pdf_accent_color'] ?? '#6d28d9'); ?>" style="height:36px; width:60px; cursor:pointer; border:1px solid #d1d5db; border-radius:4px;">
                                </div>

                                <div style="margin-bottom:14px;">
                                    <label style="font-weight:700; display:block; margin-bottom:4px;">Terms & Conditions Text:</label>
                                    <textarea name="pdf_terms_text" rows="4" class="widefat" placeholder="1. Free proof included..."><?php echo esc_textarea($settings['pdf_terms_text'] ?? ''); ?></textarea>
                                </div>

                                <!-- PDF Email Attachment Toggle -->
                                <div>
                                    <div class="evonee-setting-row" style="border-bottom:none; padding-bottom:0;">
                                        <div class="evonee-setting-info">
                                            <strong>📄 PDF Quote Attachment in Emails</strong>
                                            <p>Automatically attach a generated PDF Quote Summary file to sales notification & customer auto-reply emails.</p>
                                        </div>
                                        <label class="evonee-toggle">
                                            <input type="checkbox" name="enable_pdf_attachment" value="1" <?php checked(isset($settings['enable_pdf_attachment']) ? $settings['enable_pdf_attachment'] : '1', '1'); ?>>
                                            <span class="evonee-slider"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Dynamic Volume Tiered Pricing Card (Step 4) -->
                        <div class="evonee-doc-card" style="margin-top:20px;">
                            <div class="evonee-card-header">
                                <span class="dashicons dashicons-chart-line"></span>
                                <h2>9. Dynamic Volume Tiered Pricing (Bulk Discount Breaks)</h2>
                            </div>
                            <div class="evonee-card-body">
                                <div class="evonee-setting-row" style="margin-bottom:14px;">
                                    <div class="evonee-setting-info">
                                        <strong>📊 Enable Volume Discount Table in Modal</strong>
                                        <p>Displays a live volume discount table in the quote modal as customers enter quantity.</p>
                                    </div>
                                    <label class="evonee-toggle">
                                        <input type="checkbox" name="enable_tiered_pricing" value="1" <?php checked($settings['enable_tiered_pricing'] ?? '1', '1'); ?>>
                                        <span class="evonee-slider"></span>
                                    </label>
                                </div>

                                <div>
                                    <label style="font-weight:700; display:block; margin-bottom:4px;">Quantity Tier Breaks & Unit Prices (Format: <code>Quantity|UnitPrice</code> per line):</label>
                                    <textarea name="tiered_price_breaks" rows="5" class="widefat" style="font-family:monospace;" placeholder="50|5.00&#10;100|4.50&#10;500|3.80&#10;1000|3.20"><?php echo esc_textarea($settings['tiered_price_breaks'] ?? ''); ?></textarea>
                                    <p class="description">Example: <code>50|5.00</code> means for 50+ units, estimated unit price is $5.00.</p>
                                 </div>
                            </div>
                        </div>

                        <!-- Backup & Migration Card (Phase 6) -->
                        <div class="evonee-doc-card" style="margin-top:20px;">
                            <div class="evonee-card-header" style="background:#faf5ff; border-bottom:1px solid #e9d5ff;">
                                <span class="dashicons dashicons-backup" style="color:#6d28d9;"></span>
                                <h2 style="color:#6d28d9;">10. Export & Import Plugin Configuration</h2>
                            </div>
                            <div class="evonee-card-body">
                                <p>Backup your plugin settings, custom fields, email templates, and pricing tiers to a JSON file or migrate them to another WordPress site.</p>
                                <div style="display:flex; gap:16px; align-items:center; flex-wrap:wrap;">
                                    <button type="button" id="eq-export-settings-btn" class="button button-secondary button-large" style="font-weight:700;">
                                        📥 Export Settings (JSON)
                                    </button>
                                    <div style="display:inline-flex; align-items:center; gap:8px; background:#f8fafc; border:1px solid #cbd5e1; padding:6px 12px; border-radius:8px;">
                                        <input type="file" id="eq-import-file-input" accept=".json" style="font-size:12px;">
                                        <button type="button" id="eq-import-settings-btn" class="button button-primary" style="background:#6d28d9; border-color:#6d28d9; font-weight:700;">
                                            📤 Import Settings
                                        </button>
                                    </div>
                                </div>
                                <div id="eq-import-msg" style="display:none; font-size:12px; font-weight:700; margin-top:10px;"></div>
                            </div>
                        </div>
                    </div> <!-- End #tab-integrations -->

                    <!-- Sticky Bottom Save Bar -->
                    <div class="eq-sticky-save-bar">
                        <div style="font-size:13px; color:#64748b;">
                            💡 <strong>Tip:</strong> Configuration changes take effect immediately after saving.
                        </div>
                        <button type="submit" class="button button-primary button-large" style="background:#6d28d9; border-color:#6d28d9; padding: 6px 26px; font-weight:700;">💾 Save All Settings & Options</button>
                    </div>

                </div>
            </form>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Dark Mode Toggle Logic
            const darkToggle = document.getElementById('eq-darkmode-toggle');
            if (darkToggle) {
                if (localStorage.getItem('evonee_dark_mode') === 'enabled') {
                    document.body.classList.add('eq-dark-mode');
                    darkToggle.textContent = '☀️ Light Mode';
                }
                darkToggle.addEventListener('click', function() {
                    document.body.classList.toggle('eq-dark-mode');
                    if (document.body.classList.contains('eq-dark-mode')) {
                        localStorage.setItem('evonee_dark_mode', 'enabled');
                        this.textContent = '☀️ Light Mode';
                    } else {
                        localStorage.setItem('evonee_dark_mode', 'disabled');
                        this.textContent = '🌙 Dark Mode';
                    }
                });
            }

            // Export Settings JSON
            const exportBtn = document.getElementById('eq-export-settings-btn');
            if (exportBtn) {
                exportBtn.addEventListener('click', function() {
                    window.location.href = ajaxurl + '?action=eq_export_settings&_wpnonce=<?php echo esc_js(wp_create_nonce("eq_export_settings_nonce")); ?>';
                });
            }

            // Import Settings JSON
            const importBtn   = document.getElementById('eq-import-settings-btn');
            const importFile  = document.getElementById('eq-import-file-input');
            const importMsg   = document.getElementById('eq-import-msg');
            if (importBtn && importFile) {
                importBtn.addEventListener('click', function() {
                    if (!importFile.files || !importFile.files[0]) {
                        alert('Please select a JSON settings backup file first.');
                        return;
                    }
                    const formData = new FormData();
                    formData.append('action', 'eq_import_settings');
                    formData.append('_wpnonce', '<?php echo esc_js(wp_create_nonce("eq_import_settings_nonce")); ?>');
                    formData.append('settings_file', importFile.files[0]);

                    importBtn.disabled = true;
                    importBtn.textContent = 'Importing...';

                    fetch(ajaxurl, { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        importBtn.disabled = false;
                        importBtn.textContent = '📤 Import Settings';
                        if (data.success) {
                            importMsg.style.display = 'block';
                            importMsg.style.color = '#16a34a';
                            importMsg.textContent = '✅ Settings imported successfully! Reloading page...';
                            setTimeout(() => window.location.reload(), 1200);
                        } else {
                            importMsg.style.display = 'block';
                            importMsg.style.color = '#dc2626';
                            importMsg.textContent = '❌ Import failed: ' + (data.data || 'Invalid JSON file');
                        }
                    })
                    .catch(err => {
                        importBtn.disabled = false;
                        importBtn.textContent = '📤 Import Settings';
                        alert('Error importing settings: ' + err.message);
                    });
                });
            }

            // Tab Switcher Logic
            const tabBtns = document.querySelectorAll('.eq-tab-btn');
            const tabContents = document.querySelectorAll('.eq-tab-content');
            const activeTabInput = document.getElementById('eq_active_tab');

            function switchTab(targetId) {
                tabBtns.forEach(btn => {
                    if (btn.getAttribute('data-tab') === targetId) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                    }
                });
                tabContents.forEach(content => {
                    if (content.id === targetId) {
                        content.classList.add('active');
                    } else {
                        content.classList.remove('active');
                    }
                });
                if (activeTabInput) activeTabInput.value = targetId;
                if (history.replaceState) {
                    history.replaceState(null, null, '#' + targetId);
                } else {
                    window.location.hash = targetId;
                }
            }

            tabBtns.forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    switchTab(this.getAttribute('data-tab'));
                });
            });

            // Restore active tab from hash on load
            const currentHash = window.location.hash ? window.location.hash.replace('#', '') : '';
            if (currentHash && document.getElementById(currentHash)) {
                switchTab(currentHash);
            }

            // Color picker text sync
            const colorPicker = document.querySelector('input[name="email_header_color"]');
            const colorText   = document.getElementById('email-header-color-text');
            if (colorPicker && colorText) {
                colorPicker.addEventListener('input', function() { colorText.value = this.value; });
                colorText.addEventListener('input', function() { if (/^#[0-9A-F]{6}$/i.test(this.value)) colorPicker.value = this.value; });
            }

            // Custom Fields add/remove
            const listContainer = document.getElementById('eq-custom-fields-list');
            const addBtn = document.getElementById('eq-add-custom-field-btn');

            if (addBtn && listContainer) {
                addBtn.addEventListener('click', function() {
                    const index = Date.now();
                    const fieldHtml = `
                        <div class="eq-custom-field-item" style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px 14px; margin-bottom:12px; display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                            <div style="flex:2; min-width:180px;">
                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Field Label:</label>
                                <input type="text" name="custom_fields[${index}][label]" placeholder="e.g. Event Name" class="widefat" required>
                            </div>
                            <div style="flex:1; min-width:130px;">
                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Field Type:</label>
                                <select name="custom_fields[${index}][type]" class="widefat">
                                    <option value="text">Text Input</option>
                                    <option value="select">Dropdown Select</option>
                                    <option value="radio">Radio Buttons</option>
                                    <option value="checkbox">Single Checkbox</option>
                                    <option value="number">Number</option>
                                    <option value="date">Date Picker</option>
                                    <option value="textarea">Textarea</option>
                                </select>
                            </div>
                            <div style="flex:2; min-width:180px;">
                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Options (for Select dropdown):</label>
                                <input type="text" name="custom_fields[${index}][options]" placeholder="Option 1, Option 2, Option 3" class="widefat">
                            </div>
                            <div style="flex:0 0 auto; padding-top:14px;">
                                <label style="font-size:12px; font-weight:600;"><input type="checkbox" name="custom_fields[${index}][required]" value="1"> Required</label>
                            </div>
                            <div style="flex:0 0 auto; padding-top:14px;">
                                <button type="button" class="button button-link-delete eq-remove-field-btn">&times; Delete</button>
                            </div>
                        </div>
                    `;
                    listContainer.insertAdjacentHTML('beforeend', fieldHtml);
                });

                listContainer.addEventListener('click', function(e) {
                    if (e.target.classList.contains('eq-remove-field-btn')) {
                        e.target.closest('.eq-custom-field-item').remove();
                    }
                });
            }

            // Quick Reply Templates add/remove
            const tmplListContainer = document.getElementById('eq-reply-templates-list');
            const addTmplBtn        = document.getElementById('eq-add-reply-template-btn');

            if (addTmplBtn && tmplListContainer) {
                addTmplBtn.addEventListener('click', function() {
                    const index = Date.now();
                    const tmplHtml = `
                        <div class="eq-reply-template-item" style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:14px; margin-bottom:12px;">
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:8px;">
                                <div>
                                    <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Template Name:</label>
                                    <input type="text" name="reply_templates[${index}][title]" class="widefat" placeholder="e.g. Standard Quote" required>
                                </div>
                                <div>
                                    <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Email Subject:</label>
                                    <input type="text" name="reply_templates[${index}][subject]" class="widefat" placeholder="Your Quote for {product} - Evonee">
                                </div>
                            </div>
                            <div>
                                <label style="font-size:11px; font-weight:700; color:#64748b; display:block; margin-bottom:2px;">Email Body:</label>
                                <textarea name="reply_templates[${index}][body]" rows="4" class="widefat" placeholder="Hi {customer_name},..."></textarea>
                            </div>
                            <div style="text-align:right; margin-top:6px;">
                                <button type="button" class="button button-link-delete eq-remove-template-btn">✕ Remove</button>
                            </div>
                        </div>
                    `;
                    tmplListContainer.insertAdjacentHTML('beforeend', tmplHtml);
                });

                tmplListContainer.addEventListener('click', function(e) {
                    if (e.target.classList.contains('eq-remove-template-btn')) {
                        e.target.closest('.eq-reply-template-item').remove();
                    }
                });
            }
        });
        </script>
        <?php
    }

    /**
     * Render Onboarding Setup Wizard Page (3-Step Guided Setup)
     */
    public function render_setup_wizard_page() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized access.');
        }

        $settings = self::get_settings();
        $message  = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eq_wizard_nonce']) && wp_verify_nonce($_POST['eq_wizard_nonce'], 'eq_save_wizard')) {
            $updated = $settings;
            if (isset($_POST['sales_email'])) {
                $updated['sales_email'] = sanitize_email(wp_unslash($_POST['sales_email']));
            }
            if (isset($_POST['pdf_company_name'])) {
                $updated['pdf_company_name'] = sanitize_text_field(wp_unslash($_POST['pdf_company_name']));
            }
            if (isset($_POST['currency_symbol'])) {
                $updated['currency_symbol'] = sanitize_text_field(wp_unslash($_POST['currency_symbol']));
            }
            if (isset($_POST['currency_code'])) {
                $updated['currency_code'] = sanitize_text_field(wp_unslash($_POST['currency_code']));
            }
            $updated['enable_pdf_quote']       = isset($_POST['enable_pdf_quote']) ? '1' : '0';
            $updated['enable_price_calc']      = isset($_POST['enable_price_calc']) ? '1' : '0';
            $updated['enable_auto_reply']      = isset($_POST['enable_auto_reply']) ? '1' : '0';
            $updated['enable_deposit_payment'] = isset($_POST['enable_deposit_payment']) ? '1' : '0';

            if (!empty($_POST['preset_industry'])) {
                $industry = sanitize_text_field(wp_unslash($_POST['preset_industry']));
                if ($industry === 'b2b') {
                    $updated['enable_woocommerce_button'] = '1';
                    $updated['enable_wc_quote_only']      = '1';
                    $updated['wc_hide_price']             = '1';
                    $updated['enable_tiered_pricing']     = '1';
                } elseif ($industry === 'merch') {
                    $updated['enable_tiered_pricing']     = '1';
                    $updated['show_products_title']       = '1';
                } elseif ($industry === 'rental') {
                    $updated['enable_call_booking']       = '1';
                }
            }

            update_option('evonee_quote_settings', $updated);
            $settings = $updated;
            $message  = 'Setup complete! Your Evonee Quotes plugin is now configured for ' . esc_html(ucfirst($industry ?? 'your store')) . '.';
        }
        ?>
        <div class="wrap evonee-admin-wrap" style="max-width:900px; margin:40px auto;">
            <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:16px; padding:32px; box-shadow:0 10px 25px rgba(0,0,0,0.05);">
                <div style="text-align:center; margin-bottom:30px;">
                    <span style="font-size:40px; display:inline-block; margin-bottom:10px;">⚡</span>
                    <h1 style="font-size:28px; font-weight:800; color:#0f172a; margin:0 0 8px;">Evonee Quick Setup Wizard</h1>
                    <p style="color:#64748b; font-size:15px; margin:0;">Configure your B2B Quotation engine in 3 simple steps.</p>
                </div>

                <?php if (!empty($message)): ?>
                    <div style="background:#f0fdf4; border:1px solid #bbf7d0; color:#15803d; padding:14px 20px; border-radius:10px; margin-bottom:24px; font-weight:600; text-align:center;">
                        ✅ <?php echo esc_html($message); ?>
                    </div>
                <?php endif; ?>

                <div style="display:flex; justify-content:space-between; margin-bottom:32px; position:relative;">
                    <div style="flex:1; text-align:center; position:relative; z-index:2;">
                        <div style="width:36px; height:36px; border-radius:50%; background:#6d28d9; color:#fff; display:flex; align-items:center; justify-content:center; margin:0 auto 8px; font-weight:800;">1</div>
                        <div style="font-size:13px; font-weight:700; color:#0f172a;">Business Profile</div>
                    </div>
                    <div style="flex:1; text-align:center; position:relative; z-index:2;">
                        <div style="width:36px; height:36px; border-radius:50%; background:#6d28d9; color:#fff; display:flex; align-items:center; justify-content:center; margin:0 auto 8px; font-weight:800;">2</div>
                        <div style="font-size:13px; font-weight:700; color:#0f172a;">Core Features</div>
                    </div>
                    <div style="flex:1; text-align:center; position:relative; z-index:2;">
                        <div style="width:36px; height:36px; border-radius:50%; background:#16a34a; color:#fff; display:flex; align-items:center; justify-content:center; margin:0 auto 8px; font-weight:800;">3</div>
                        <div style="font-size:13px; font-weight:700; color:#0f172a;">Ready to Launch!</div>
                    </div>
                </div>

                <form method="post">
                    <?php wp_nonce_field('eq_save_wizard', 'eq_wizard_nonce'); ?>
                    
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:24px;">
                        <div style="background:#faf5ff; border:1px solid #e9d5ff; border-radius:12px; padding:20px;">
                            <h3 style="margin:0 0 14px; font-size:15px; color:#6d28d9;">📋 Step 1: Business Details</h3>
                            
                            <div style="margin-bottom:14px;">
                                <label style="font-size:12px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">Sales Email Address:</label>
                                <input type="email" name="sales_email" value="<?php echo esc_attr($settings['sales_email']); ?>" class="widefat" required>
                            </div>
                            
                            <div style="margin-bottom:14px;">
                                <label style="font-size:12px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">Company Name (for PDF Header):</label>
                                <input type="text" name="pdf_company_name" value="<?php echo esc_attr($settings['pdf_company_name']); ?>" class="widefat" required>
                            </div>

                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                                <div>
                                    <label style="font-size:12px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">Currency Symbol:</label>
                                    <input type="text" name="currency_symbol" value="<?php echo esc_attr($settings['currency_symbol']); ?>" class="widefat" required>
                                </div>
                                <div>
                                    <label style="font-size:12px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">Currency Code:</label>
                                    <input type="text" name="currency_code" value="<?php echo esc_attr($settings['currency_code']); ?>" class="widefat" required>
                                </div>
                            </div>
                        </div>

                        <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:12px; padding:20px;">
                            <h3 style="margin:0 0 14px; font-size:15px; color:#1d4ed8;">⚡ Step 2: Key Modules & Features</h3>
                            
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; font-size:13px; font-weight:600; cursor:pointer;">
                                <input type="checkbox" name="enable_pdf_quote" value="1" <?php checked($settings['enable_pdf_quote'], '1'); ?>>
                                Enable PDF Quote Sheet Generation & Downloads
                            </label>

                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; font-size:13px; font-weight:600; cursor:pointer;">
                                <input type="checkbox" name="enable_price_calc" value="1" <?php checked($settings['enable_price_calc'], '1'); ?>>
                                Enable Automatic Price Estimation Engine
                            </label>

                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; font-size:13px; font-weight:600; cursor:pointer;">
                                <input type="checkbox" name="enable_auto_reply" value="1" <?php checked($settings['enable_auto_reply'], '1'); ?>>
                                Send Instant Automated Confirmation Emails to Customers
                            </label>

                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; font-size:13px; font-weight:600; cursor:pointer;">
                                <input type="checkbox" name="enable_deposit_payment" value="1" <?php checked($settings['enable_deposit_payment'], '1'); ?>>
                                Allow Partial Deposit Payments (e.g., 50% upfront)
                            </label>
                        </div>
                    </div>

                    <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; padding:20px; margin-bottom:24px;">
                        <h3 style="margin:0 0 8px; font-size:15px; color:#0f172a;">🚀 Step 3: Embed Form on Your Site</h3>
                        <p style="font-size:13px; color:#64748b; margin:0 0 12px;">Copy and paste this shortcode onto any Page, Post, or Elementor builder layout:</p>
                        <div style="background:#0f172a; color:#38bdf8; padding:12px 18px; border-radius:8px; font-family:monospace; font-size:14px; font-weight:700; display:flex; justify-content:space-between; align-items:center;">
                            <span>[evonee_quote_form]</span>
                            <button type="button" onclick="navigator.clipboard.writeText('[evonee_quote_form]'); alert('Shortcode copied!');" class="button button-small" style="background:#38bdf8; color:#0f172a; border:none; font-weight:700;">📋 Copy</button>
                        </div>
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=evonee-submissions')); ?>" class="button button-secondary button-large">Skip to Submissions &rarr;</a>
                        <button type="submit" class="button button-primary button-large" style="background:#6d28d9; border-color:#6d28d9; font-weight:700; padding:8px 28px;">💾 Save Configuration & Complete Setup</button>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }
}
