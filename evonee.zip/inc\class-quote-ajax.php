<?php
if (!defined('ABSPATH')) {
    exit;
}

class Evonee_Quote_Ajax {

    const DB_SCHEMA_VERSION = '1.0.0';

    // FIX BUG #7: Static cache to avoid repeated DB queries on every AJAX call
    private static $migrations_ran = false;

    public static function init() {
        $instance = new self();
        add_action('wp_ajax_eq_submit_quote',         [$instance, 'handle_submit']);
        add_action('wp_ajax_nopriv_eq_submit_quote',  [$instance, 'handle_submit']);
        add_action('wp_ajax_eq_save_admin_notes',     [$instance, 'handle_save_notes']);
        add_action('wp_ajax_eq_get_today_stats',      [$instance, 'handle_today_stats']);
        add_action('wp_ajax_eq_save_followup',        [$instance, 'handle_save_followup']);
        add_action('wp_ajax_eq_save_price_offer',     [$instance, 'handle_save_price_offer']);
        add_action('wp_ajax_eq_download_pdf',         [$instance, 'handle_download_pdf']);
        add_action('wp_ajax_eq_convert_to_wc_order',  [$instance, 'handle_convert_to_wc_order']);
        add_action('wp_ajax_eq_send_message',         [$instance, 'handle_send_message']);
        add_action('wp_ajax_nopriv_eq_send_message',  [$instance, 'handle_send_message']);
        add_action('wp_ajax_eq_get_messages',         [$instance, 'handle_get_messages']);
        add_action('wp_ajax_nopriv_eq_get_messages',  [$instance, 'handle_get_messages']);
        add_action('wp_ajax_eq_update_status_kanban', [$instance, 'handle_update_status_kanban']);
        add_action('wp_ajax_eq_export_settings',      [$instance, 'handle_export_settings']);
        add_action('wp_ajax_eq_import_settings',      [$instance, 'handle_import_settings']);
        add_action('wp_ajax_eq_gdpr_export',          [$instance, 'handle_gdpr_export']);
        add_action('wp_ajax_nopriv_eq_gdpr_export',   [$instance, 'handle_gdpr_export']);
        add_action('wp_ajax_eq_gdpr_erasure',         [$instance, 'handle_gdpr_erasure']);
        add_action('wp_ajax_nopriv_eq_gdpr_erasure',  [$instance, 'handle_gdpr_erasure']);
        add_action('wp_ajax_eq_export_activity_csv',  [$instance, 'handle_export_activity_csv']);
        add_action('wp_ajax_eq_ai_generate_reply',    [$instance, 'handle_ai_generate_reply']);
        add_action('wp_ajax_eq_run_drip_engine',      [$instance, 'handle_run_drip_engine']);
        add_action('rest_api_init',                   [$instance, 'register_rest_routes']);
    }

    /**
     * Handle saving internal admin notes for a submission
     */
    public function handle_save_notes() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_save_notes_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $submission_id = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        $notes         = isset($_POST['notes']) ? sanitize_textarea_field(wp_unslash($_POST['notes'])) : '';

        if (!$submission_id) {
            wp_send_json_error(['message' => 'Invalid submission ID.']);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        self::maybe_run_phase2_migrations();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $updated = $wpdb->update(
            $table_name,
            ['admin_notes' => $notes],
            ['id'          => $submission_id],
            ['%s'],
            ['%d']
        );

        if ($updated === false) {
            wp_send_json_error(['message' => 'Failed to save notes.']);
        }

        self::log_activity($submission_id, 'notes_updated', 'Updated internal notes');
        wp_send_json_success(['message' => 'Notes saved successfully.', 'saved_at' => current_time('mysql')]);
    }

    /**
     * Handle today's stats for Dashboard Widget (AJAX)
     * FIX BUG #12: Added nonce verification
     */
    public function handle_today_stats() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_dashboard_stats_nonce', 'nonce', false) && !check_ajax_referer('eq_today_stats_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        $today      = current_time('Y-m-d');

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $today_val = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE DATE(created_at) = %s", $today));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $new_val   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'new'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $pending_val = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'pending'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $quoted_val  = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'quoted'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $completed_val = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions WHERE status = %s", 'completed'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $total_val   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}eq_quote_submissions");

        $stats = [
            'today'     => $today_val,
            'new'       => $new_val,
            'pending'   => $pending_val,
            'quoted'    => $quoted_val,
            'completed' => $completed_val,
            'total'     => $total_val,
        ];

        wp_send_json_success($stats);
    }

    /**
     * Handle saving follow-up date for a submission (Phase 2)
     */
    public function handle_save_followup() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_save_followup_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $submission_id = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        $followup_date = isset($_POST['follow_up_date']) ? sanitize_text_field(wp_unslash($_POST['follow_up_date'])) : '';

        if (!$submission_id) {
            wp_send_json_error(['message' => 'Invalid submission ID.']);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        self::maybe_run_phase2_migrations();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $updated = $wpdb->update(
            $table_name,
            ['follow_up_date' => !empty($followup_date) ? $followup_date : NULL],
            ['id'             => $submission_id],
            ['%s'],
            ['%d']
        );

        if ($updated === false) {
            wp_send_json_error(['message' => 'Failed to save follow-up date.']);
        }

        self::log_activity($submission_id, 'followup_updated', 'Set follow-up date to: ' . ($followup_date ?: 'None'));
        wp_send_json_success(['message' => 'Follow-up date saved successfully.']);
    }

    /**
     * Handle saving quoted price offer for a submission (Phase 2)
     */
    public function handle_save_price_offer() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_save_price_offer_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $submission_id = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        $price         = isset($_POST['quoted_price']) ? floatval($_POST['quoted_price']) : 0.00;
        $dep_pct       = isset($_POST['deposit_percent']) ? floatval($_POST['deposit_percent']) : 0.00;
        $dep_amt       = round($price * ($dep_pct / 100), 2);

        if (!$submission_id) {
            wp_send_json_error(['message' => 'Invalid submission ID.']);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        self::maybe_run_phase2_migrations();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $quote = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $submission_id));

        $update_data = [
            'quoted_price'   => $price,
            'deposit_percent'=> $dep_pct,
            'deposit_amount' => $dep_amt,
            'status'         => 'quoted'
        ];
        $update_format = ['%f', '%f', '%f', '%s'];

        if ($quote && empty($quote->response_time_seconds)) {
            $created_ts = strtotime($quote->created_at);
            if ($created_ts > 0) {
                $update_data['response_time_seconds'] = max(1, time() - $created_ts);
                $update_format[] = '%d';
            }
        }

        if ($quote && empty($quote->acceptance_token)) {
            $update_data['acceptance_token'] = wp_generate_password(32, false);
            $update_data['token_expiry']     = gmdate('Y-m-d H:i:s', strtotime('+30 days'));
            $update_format[] = '%s';
            $update_format[] = '%s';
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $updated = $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $submission_id],
            $update_format,
            ['%d']
        );

        if ($updated === false) {
            wp_send_json_error(['message' => 'Failed to save price offer.']);
        }

        $notes = 'Set price offer to $' . number_format($price, 2);
        if ($dep_pct > 0) {
            $notes .= ' with ' . $dep_pct . '% deposit ($' . number_format($dep_amt, 2) . ')';
        }
        self::log_activity($submission_id, 'price_updated', $notes);
        wp_send_json_success(['message' => 'Price offer saved successfully.']);
    }

    /**
     * AJAX: Convert Quote Submission to WooCommerce Order (Phase 1.2)
     */
    public function handle_convert_to_wc_order() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized action.'], 403);
        }

        if (!check_ajax_referer('eq_convert_to_wc_order_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        if (!class_exists('WooCommerce') || !function_exists('wc_create_order')) {
            wp_send_json_error(['message' => 'WooCommerce plugin is not active. Please install and activate WooCommerce.'], 400);
        }

        $submission_id = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        if (!$submission_id) {
            wp_send_json_error(['message' => 'Invalid submission ID.'], 400);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $quote = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}eq_quote_submissions WHERE id = %d", $submission_id));

        if (!$quote) {
            wp_send_json_error(['message' => 'Quote submission not found.'], 404);
        }

        try {
            $order = wc_create_order();

            // Item Fee or Product
            $item = new WC_Order_Item_Fee();
            $item_name = !empty($quote->product) ? $quote->product : 'Custom Quote Package';
            if (!empty($quote->quantity)) {
                $item_name .= ' (Qty: ' . $quote->quantity . ')';
            }
            $item->set_name($item_name);

            $total_price = floatval($quote->quoted_price) > 0 ? floatval($quote->quoted_price) : 0.00;

            $settings       = Evonee_Quote_Admin::get_settings();
            $enable_deposit = !empty($settings['enable_deposit_payment']);
            $deposit_pct    = isset($settings['deposit_percentage']) ? floatval($settings['deposit_percentage']) : 50;

            if ($enable_deposit && $deposit_pct > 0 && $deposit_pct < 100) {
                $deposit_amount = round(($total_price * $deposit_pct) / 100, 2);
                $item->set_name($item_name . ' (' . $deposit_pct . '% Deposit)');
                $item->set_total($deposit_amount);
                $order->add_note(sprintf('Partial Deposit Order: %s%% Deposit of total quoted amount ($%s). Remaining balance due upon completion.', $deposit_pct, number_format($total_price, 2)));
            } else {
                $item->set_total($total_price);
            }

            $order->add_item($item);

            // Billing details
            $name_parts = explode(' ', trim($quote->full_name), 2);
            $first_name = $name_parts[0];
            $last_name  = isset($name_parts[1]) ? $name_parts[1] : '';

            $address = [
                'first_name' => $first_name,
                'last_name'  => $last_name,
                'company'    => $quote->company,
                'email'      => $quote->email,
                'phone'      => $quote->phone,
                'country'    => $quote->country,
                'postcode'   => $quote->zip_code,
            ];
            $order->set_address($address, 'billing');

            if (!empty($quote->project_notes)) {
                $order->set_customer_note($quote->project_notes);
            }

            $order->calculate_totals();
            $order->update_status('pending', 'Converted from Evonee Quote Request #' . $quote->id);
            $order->save();

            // Update submission status to approved
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update($table_name, ['status' => 'approved'], ['id' => $submission_id], ['%s'], ['%d']);

            self::log_activity($submission_id, 'wc_order_created', 'Converted to WooCommerce Order #' . $order->get_id());

            delete_transient('evonee_dashboard_stats');
            delete_transient('evonee_dashboard_widget_stats');

            $order_edit_url = admin_url('post.php?post=' . $order->get_id() . '&action=edit');
            $payment_url    = $order->get_checkout_payment_url();

            wp_send_json_success([
                'message'        => 'Successfully created WooCommerce Order #' . $order->get_id(),
                'order_id'       => $order->get_id(),
                'order_edit_url' => $order_edit_url,
                'payment_url'    => $payment_url,
            ]);
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'Failed to create WooCommerce order: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Daily WP-Cron: Automated Expiry Reminders, Drip Follow-ups & Token Cleanup
     */
    public static function run_daily_quote_cron() {
        global $wpdb;
        self::maybe_run_phase2_migrations();
        $now      = gmdate('Y-m-d H:i:s');
        $day2_ago = gmdate('Y-m-d H:i:s', strtotime('-2 days'));
        $day5_ago = gmdate('Y-m-d H:i:s', strtotime('-5 days'));

        $day2_count = 0;
        $day5_count = 0;
        $sub_table  = $wpdb->prefix . 'eq_quote_submissions';

        // 1. Stage 1 Drip: Day 2 Check-in Follow-up
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $drip1_quotes = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$sub_table} WHERE status = %s AND (drip_level IS NULL OR drip_level = 0) AND created_at <= %s",
            'quoted',
            $day2_ago
        ));

        if (!empty($drip1_quotes)) {
            foreach ($drip1_quotes as $q) {
                if (Evonee_Quote_Mailer::send_drip_followup($q, 1)) {
                    $day2_count++;
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $wpdb->update(
                        $sub_table,
                        ['drip_level' => 1, 'drip_last_sent' => $now],
                        ['id' => $q->id],
                        ['%d', '%s'],
                        ['%d']
                    );
                    self::log_activity($q->id, 'drip_followup_1', 'Automated Day 2 Drip Check-in email sent to customer.');
                }
            }
        }

        // 2. Stage 2 Drip: Day 5 Urgency & Discount Follow-up
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $drip2_quotes = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$sub_table} WHERE status = %s AND drip_level = 1 AND created_at <= %s",
            'quoted',
            $day5_ago
        ));

        if (!empty($drip2_quotes)) {
            foreach ($drip2_quotes as $q) {
                if (Evonee_Quote_Mailer::send_drip_followup($q, 2)) {
                    $day5_count++;
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $wpdb->update(
                        $sub_table,
                        ['drip_level' => 2, 'drip_last_sent' => $now],
                        ['id' => $q->id],
                        ['%d', '%s'],
                        ['%d']
                    );
                    self::log_activity($q->id, 'drip_followup_2', 'Automated Day 5 Urgency & Expiration email sent to customer.');
                }
            }
        }

        // 3. Expiry Reminders (3 days prior to expiration)
        $three_days_later = gmdate('Y-m-d H:i:s', strtotime('+3 days'));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $expiring_quotes = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$sub_table} WHERE status = %s AND token_expiry IS NOT NULL AND token_expiry > %s AND token_expiry <= %s",
            'quoted',
            $now,
            $three_days_later
        ));

        if (!empty($expiring_quotes)) {
            foreach ($expiring_quotes as $q) {
                Evonee_Quote_Mailer::send_reminder_email($q);
                self::log_activity($q->id, 'cron_reminder', 'Automated 3-day expiry reminder email sent to customer.');
            }
        }

        // 4. Token Expiry Cleanup
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query($wpdb->prepare(
            "UPDATE {$sub_table} SET acceptance_token = '', token_expiry = NULL WHERE token_expiry IS NOT NULL AND token_expiry <= %s",
            $now
        ));

        return [
            'day2_count' => $day2_count,
            'day5_count' => $day5_count
        ];
    }

    /**
     * AJAX Action: 1-Click Manual Execution of Automated Drip Engine
     */
    public function handle_run_drip_engine() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized action.'], 403);
        }
        if (!check_ajax_referer('eq_admin_nonce', 'nonce', false) && !check_ajax_referer('eq_run_drip_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $res = self::run_daily_quote_cron();
        wp_send_json_success([
            'message'    => sprintf('Drip Engine executed! Sent %d Day-2 check-in emails & %d Day-5 urgency emails.', $res['day2_count'], $res['day5_count']),
            'day2_count' => $res['day2_count'],
            'day5_count' => $res['day5_count']
        ]);
    }

    /**
     * AJAX Action: 🤖 AI Smart Reply Drafter
     */
    public function handle_ai_generate_reply() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_admin_nonce', 'nonce', false) && !check_ajax_referer('eq_ai_generate_reply_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $submission_id = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        if (!$submission_id) {
            wp_send_json_error(['message' => 'Invalid submission ID.']);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        self::maybe_run_phase2_migrations();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $quote = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $submission_id));
        if (!$quote) {
            wp_send_json_error(['message' => 'Quote submission not found.']);
        }

        $settings   = Evonee_Quote_Admin::get_settings();
        $brand_name = !empty($settings['email_brand_name']) ? $settings['email_brand_name'] : get_bloginfo('name');
        $currency   = isset($settings['currency_symbol']) ? $settings['currency_symbol'] : '$';

        $qty = intval($quote->quantity);
        if ($qty <= 0) $qty = 100;

        $price = floatval($quote->quoted_price);
        if ($price <= 0) {
            $price = floatval($quote->estimated_total);
        }
        if ($price <= 0) {
            // Intelligent volume pricing estimation fallback
            $base_unit_price = 4.50;
            if ($qty >= 500) $base_unit_price = 2.80;
            elseif ($qty >= 250) $base_unit_price = 3.20;
            elseif ($qty >= 100) $base_unit_price = 3.80;
            $price = round($qty * $base_unit_price, 2);
        }

        $unit_price = round($price / $qty, 2);

        $deposit_percent = !empty($quote->deposit_percent) ? floatval($quote->deposit_percent) : 20;
        $deposit_amount  = round($price * ($deposit_percent / 100), 2);

        $timeframe = !empty($quote->timeframe) ? $quote->timeframe : 'Standard (5-7 business days)';
        $specs     = self::format_product_details_text($quote->product_details ?? '');

        $subject = sprintf('Official Custom Quote & Digital Proof Request #%d — %s', $quote->id, $quote->product);

        $body  = "Dear " . esc_html($quote->full_name) . ",\n\n";
        if (!empty($quote->company)) {
            $body .= "Thank you for reaching out on behalf of " . esc_html($quote->company) . "! ";
        } else {
            $body .= "Thank you for contacting " . esc_html($brand_name) . "! ";
        }
        $body .= "We are pleased to provide your custom quotation for " . esc_html($quote->product) . ".\n\n";

        $body .= "📋 QUOTATION SUMMARY & SPECIFICATIONS:\n";
        $body .= "----------------------------------------\n";
        $body .= "• Item: " . esc_html($quote->product) . "\n";
        $body .= "• Quantity: " . number_format($qty) . " units\n";
        if (!empty($specs)) {
            $body .= "• Specifications: " . esc_html($specs) . "\n";
        }
        $body .= "• Estimated Production & Delivery: " . esc_html($timeframe) . "\n\n";

        $body .= "💰 PRICING & PAYMENT TERMS:\n";
        $body .= "----------------------------------------\n";
        $body .= "• Unit Price: " . $currency . number_format($unit_price, 2) . " / unit\n";
        $body .= "• Total Quoted Amount: " . $currency . number_format($price, 2) . "\n";
        if ($deposit_percent > 0) {
            $body .= "• Advance Deposit Required (" . $deposit_percent . "%): " . $currency . number_format($deposit_amount, 2) . "\n";
            $body .= "• Balance Due (" . (100 - $deposit_percent) . "%): " . $currency . number_format($price - $deposit_amount, 2) . " (Before final shipment)\n";
        }
        $body .= "\n";

        $body .= "✨ WHAT'S INCLUDED IN YOUR QUOTE:\n";
        $body .= "• Complimentary Digital Art Proofing & Pre-production Preview\n";
        $body .= "• Dedicated Account Representative Support\n";
        $body .= "• Strict B2B Quality Guarantee\n\n";

        $body .= "To confirm this quote and proceed with digital artwork proofing, simply click the official proposal link in your email or reply directly to this message.\n\n";
        $body .= "Best regards,\n";
        $body .= esc_html($brand_name) . " B2B Sales Team\n";

        wp_send_json_success([
            'reply_subject'           => $subject,
            'reply_body'              => $body,
            'suggested_price'         => number_format($price, 2, '.', ''),
            'suggested_deposit_percent'=> $deposit_percent,
            'suggested_deposit_amount' => number_format($deposit_amount, 2, '.', '')
        ]);
    }

    /**
     * Helper to log activity (Phase 2)
     */
    public static function log_activity($submission_id, $action, $notes = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'eq_quote_activity_log';
        self::maybe_run_phase2_migrations();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->insert(
            $table,
            [
                'submission_id' => intval($submission_id),
                'action'        => sanitize_text_field($action),
                'notes'         => sanitize_textarea_field($notes),
                'user_id'       => get_current_user_id()
            ],
            ['%d', '%s', '%s', '%d']
        );
    }

    /**
     * Helper to log email sent (Phase 2)
     */
    public static function log_email($submission_id, $recipient, $subject, $type = 'reply', $status = 'sent') {
        global $wpdb;
        $table = $wpdb->prefix . 'eq_email_log';
        self::maybe_run_phase2_migrations();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $emails = array_filter(array_map('sanitize_email', preg_split('/\s*,\s*/', (string) $recipient)));
        $emails = array_values(array_filter($emails, 'is_email'));
        $recipient_store = !empty($emails) ? implode(', ', $emails) : sanitize_text_field($recipient);

        $wpdb->insert(
            $table,
            [
                'submission_id' => intval($submission_id),
                'recipient'     => $recipient_store,
                'subject'       => sanitize_text_field($subject),
                'type'          => sanitize_text_field($type),
                'status'        => sanitize_text_field($status)
            ],
            ['%d', '%s', '%s', '%s', '%s']
        );
    }

    /**
     * Sales notification address from settings, with constant fallback.
     */
    public static function get_sales_email() {
        $settings = Evonee_Quote_Admin::get_settings();
        if (!empty($settings['sales_email']) && is_email($settings['sales_email'])) {
            return $settings['sales_email'];
        }
        return defined('EQ_SALES_EMAIL') ? EQ_SALES_EMAIL : 'sales@evonee.com';
    }

    /**
     * Parse stored artwork field (JSON array or legacy comma-separated URLs).
     *
     * @param mixed $raw
     * @return string[]
     */
    public static function parse_artwork_urls($raw) {
        if (empty($raw)) {
            return [];
        }
        if (is_array($raw)) {
            return array_values(array_filter($raw, function ($url) {
                return is_string($url) && $url !== '';
            }));
        }
        $decoded = json_decode((string) $raw, true);
        if (is_array($decoded)) {
            return array_values(array_filter($decoded, function ($url) {
                return is_string($url) && $url !== '';
            }));
        }
        return array_values(array_filter(array_map('trim', preg_split('/\s*,\s*/', (string) $raw))));
    }

    /**
     * Parse stored product_details JSON.
     *
     * @param mixed $raw
     * @return array
     */
    public static function parse_product_details($raw) {
        if (empty($raw)) {
            return [];
        }
        if (is_array($raw)) {
            return $raw;
        }
        $decoded = json_decode((string) $raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Flatten product details for CSV / plain-text views.
     *
     * @param mixed $raw
     * @return string
     */
    public static function format_product_details_text($raw) {
        $details = self::parse_product_details($raw);
        $parts   = [];
        foreach ($details as $key => $val) {
            if ($val === '' || $val === null || $val === []) {
                continue;
            }
            $label = ucwords(str_replace('_', ' ', (string) $key));
            $value = is_array($val) ? implode(', ', $val) : (string) $val;
            $parts[] = $label . ': ' . $value;
        }
        return implode(' | ', $parts);
    }

    /**
     * Runtime migration: Phase 2 DB Columns & Tables
     * FIX BUG #7: Added static property cache to avoid repeated DB queries
     * on every AJAX call (log_activity, log_email, etc. each called this)
     */
    public static function maybe_run_phase2_migrations() {
        // FIX BUG #7: Use static flag to skip repeated DB version check in same request
        if (self::$migrations_ran) {
            return;
        }
        if (get_option('evonee_db_schema_version') === self::DB_SCHEMA_VERSION) {
            self::$migrations_ran = true;
            return;
        }

        global $wpdb;
        $sub_table = $wpdb->prefix . 'eq_quote_submissions';
        $charset_collate = $wpdb->get_charset_collate();

        // 1. Columns for eq_quote_submissions
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $has_notes = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'admin_notes'));
        if (empty($has_notes)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN admin_notes TEXT DEFAULT '' AFTER project_notes;");
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $has_followup = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'follow_up_date'));
        if (empty($has_followup)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN follow_up_date DATE DEFAULT NULL AFTER status;");
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $has_price = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'quoted_price'));
        if (empty($has_price)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN quoted_price DECIMAL(10,2) DEFAULT '0.00' AFTER follow_up_date;");
        }
        // Phase 3: Token-based Quote Acceptance
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $has_token = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'acceptance_token'));
        if (empty($has_token)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN acceptance_token VARCHAR(64) DEFAULT NULL AFTER quoted_price;");
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $has_expiry = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'token_expiry'));
        if (empty($has_expiry)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN token_expiry DATETIME DEFAULT NULL AFTER acceptance_token;");
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $has_estimated_total = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'estimated_total'));
        if (empty($has_estimated_total)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN estimated_total DECIMAL(10,2) DEFAULT '0.00' AFTER status;");
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $has_sig = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'digital_signature'));
        if (empty($has_sig)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN digital_signature LONGTEXT DEFAULT NULL AFTER token_expiry;");
        }

        // Advanced AI & Automation Columns
        $has_drip_level = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'drip_level'));
        if (empty($has_drip_level)) {
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN drip_level INT DEFAULT 0 AFTER token_expiry;");
        }

        $has_drip_sent = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'drip_last_sent'));
        if (empty($has_drip_sent)) {
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN drip_last_sent DATETIME DEFAULT NULL AFTER drip_level;");
        }

        $has_dep_pct = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'deposit_percent'));
        if (empty($has_dep_pct)) {
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN deposit_percent DECIMAL(5,2) DEFAULT '0.00' AFTER quoted_price;");
        }

        $has_dep_amt = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'deposit_amount'));
        if (empty($has_dep_amt)) {
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN deposit_amount DECIMAL(10,2) DEFAULT '0.00' AFTER deposit_percent;");
        }

        $has_resp_time = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'response_time_seconds'));
        if (empty($has_resp_time)) {
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD COLUMN response_time_seconds INT DEFAULT NULL AFTER drip_last_sent;");
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $col_art = $wpdb->get_row($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'artwork_url'));
        if (!empty($col_art) && isset($col_art->Type) && stripos($col_art->Type, 'varchar') !== false) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions MODIFY artwork_url TEXT DEFAULT '';");
        }

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // 2. Activity Log Table
        $act_table = $wpdb->prefix . 'eq_quote_activity_log';
        $sql_act = "CREATE TABLE $act_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            submission_id bigint(20) NOT NULL,
            action varchar(100) NOT NULL,
            notes text DEFAULT '',
            user_id bigint(20) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY submission_id (submission_id)
        ) $charset_collate;";
        dbDelta($sql_act);

        // 3. Email Log Table
        $email_table = $wpdb->prefix . 'eq_email_log';
        $sql_email = "CREATE TABLE $email_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            submission_id bigint(20) NOT NULL,
            recipient varchar(200) NOT NULL,
            subject varchar(255) NOT NULL,
            type varchar(50) DEFAULT 'notification',
            status varchar(20) DEFAULT 'sent',
            sent_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY submission_id (submission_id)
        ) $charset_collate;";
        dbDelta($sql_email);

        // 4. Quote Messages Thread Table (Step 2)
        $msg_table = $wpdb->prefix . 'eq_quote_messages';
        $sql_msg = "CREATE TABLE $msg_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            submission_id bigint(20) NOT NULL,
            sender_type varchar(20) NOT NULL DEFAULT 'customer',
            sender_name varchar(100) NOT NULL,
            message text NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY submission_id (submission_id)
        ) $charset_collate;";
        dbDelta($sql_msg);

        update_option('evonee_db_schema_version', self::DB_SCHEMA_VERSION);
        // FIX BUG #7: Mark migrations as completed for this request
        self::$migrations_ran = true;
    }

    public static function maybe_add_admin_notes_column() {
        self::maybe_run_phase2_migrations();
    }

    /**
     * Create custom database table on plugin activation
     */
    public static function create_submissions_table() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            full_name varchar(100) NOT NULL,
            company varchar(100) DEFAULT '',
            email varchar(100) NOT NULL,
            phone varchar(50) NOT NULL,
            country varchar(100) NOT NULL,
            product varchar(150) NOT NULL,
            quantity varchar(50) NOT NULL,
            product_details longtext DEFAULT '',
            artwork_url text DEFAULT '',
            timeframe varchar(50) NOT NULL,
            specific_date varchar(50) DEFAULT '',
            zip_code varchar(30) NOT NULL,
            project_notes text DEFAULT '',
            status varchar(30) DEFAULT 'new' NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY status_idx (status),
            KEY created_idx (created_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Ensure status column exists if updating existing installation
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $has_status = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$wpdb->prefix}eq_quote_submissions LIKE %s", 'status'));
        if (empty($has_status)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$wpdb->prefix}eq_quote_submissions ADD status varchar(30) DEFAULT 'new' NOT NULL;");
        }
    }

    /**
     * Handle AJAX Form Submission
     */
    public function handle_submit() {
        // 1. Verify Nonce
        if (!check_ajax_referer('eq_submit_quote', 'eq_nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed. Please refresh the page and try again.'], 403);
        }

        // 2. Honeypot Check (Spam bot detection)
        if (!empty($_POST['eq_website'])) {
            // Return fake success response to trick spambots
            wp_send_json_success([
                'message' => 'Quote request received! We will get back to you within 24 hours.'
            ]);
            exit;
        }

        // 3. Minimum Time-on-Page Check (Bots submit instantly)
        $open_time = isset($_POST['eq_open_time']) ? intval($_POST['eq_open_time']) : 0;
        if ($open_time > 0 && (time() - $open_time) < 3) {
            wp_send_json_error(['message' => 'Submission processed too quickly. Please try again.']);
        }

        // 4. Rate Limiting Check (Max 5 submissions per 15 min per IP)
        $client_ip = $this->get_client_ip();
        $transient_key = 'eq_rate_' . md5($client_ip);
        $submission_count = get_transient($transient_key) ?: 0;

        if ($submission_count >= 5) {
            wp_send_json_error(['message' => 'Too many requests. Please wait a few minutes before submitting again.']);
        }

        // 4.5. reCAPTCHA v3 Verification (Phase 3.2)
        $settings = Evonee_Quote_Admin::get_settings();
        if (!empty($settings['enable_recaptcha']) && $settings['enable_recaptcha'] === '1' && !empty($settings['recaptcha_secret_key'])) {
            $recaptcha_token = isset($_POST['eq_recaptcha_token']) ? sanitize_text_field(wp_unslash($_POST['eq_recaptcha_token'])) : '';
            if (empty($recaptcha_token)) {
                wp_send_json_error(['message' => 'reCAPTCHA verification failed. Token missing.']);
            }
            $verify_response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', [
                'body' => [
                    'secret'   => $settings['recaptcha_secret_key'],
                    'response' => $recaptcha_token,
                    'remoteip' => $client_ip
                ]
            ]);
            if (is_wp_error($verify_response)) {
                wp_send_json_error(['message' => 'reCAPTCHA verification server error.']);
            }
            $res_data = json_decode(wp_remote_retrieve_body($verify_response), true);
            if (empty($res_data['success']) || (isset($res_data['score']) && $res_data['score'] < 0.5)) {
                wp_send_json_error(['message' => 'reCAPTCHA verification failed. Low trust score.']);
            }
        }

        // 5. Sanitize & Collect Input Data
        $full_name    = isset($_POST['full_name']) ? sanitize_text_field(wp_unslash($_POST['full_name'])) : '';
        $company      = isset($_POST['company']) ? sanitize_text_field(wp_unslash($_POST['company'])) : '';
        $email        = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $phone        = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
        $country_raw   = isset($_POST['country']) ? sanitize_text_field(wp_unslash($_POST['country'])) : '';
        $other_country = isset($_POST['other_country']) ? sanitize_text_field(wp_unslash($_POST['other_country'])) : '';
        $country       = ($country_raw === 'Other' || $country_raw === 'other') ? ('Other (' . $other_country . ')') : $country_raw;

        $product      = isset($_POST['product']) ? sanitize_text_field(wp_unslash($_POST['product'])) : '';
        $quantity_raw = isset($_POST['quantity']) ? sanitize_text_field(wp_unslash($_POST['quantity'])) : '';
        $other_qty    = isset($_POST['other_quantity']) ? sanitize_text_field(wp_unslash($_POST['other_quantity'])) : '';
        
        $quantity     = ($quantity_raw === 'other' || $quantity_raw === 'Other') ? ('Other (' . $other_qty . ')') : $quantity_raw;

        $timeframe    = isset($_POST['timeframe']) ? sanitize_text_field(wp_unslash($_POST['timeframe'])) : '';
        $specific_date= isset($_POST['specific_date']) ? sanitize_text_field(wp_unslash($_POST['specific_date'])) : '';
        $zip_code     = isset($_POST['zip_code']) ? sanitize_text_field(wp_unslash($_POST['zip_code'])) : '';
        $project_notes= isset($_POST['project_notes']) ? sanitize_textarea_field(wp_unslash($_POST['project_notes'])) : '';
        $consent      = isset($_POST['consent']) ? true : false;
        $no_artwork   = isset($_POST['no_artwork']) ? true : false;

        // Collect Product Details (Section 3)
        $product_details = [
            'wristband_type'  => isset($_POST['wristband_type']) ? sanitize_text_field(wp_unslash($_POST['wristband_type'])) : '',
            'size'            => isset($_POST['size']) ? sanitize_text_field(wp_unslash($_POST['size'])) : '',
            'color'           => isset($_POST['color']) ? sanitize_text_field(wp_unslash($_POST['color'])) : '',
            'has_pms_color'   => isset($_POST['has_pms_color']) ? sanitize_text_field(wp_unslash($_POST['has_pms_color'])) : '',
            'debossed_text'   => isset($_POST['debossed_text']) ? sanitize_text_field(wp_unslash($_POST['debossed_text'])) : '',
            'text_color'      => isset($_POST['text_color']) ? sanitize_text_field(wp_unslash($_POST['text_color'])) : '',
        ];

        // Dynamically capture No-Code custom fields
        $custom_builder_fields = get_option('evonee_quote_custom_fields', []);
        $errors = [];
        if (!empty($custom_builder_fields) && is_array($custom_builder_fields)) {
            foreach ($custom_builder_fields as $cf) {
                $f_key = 'custom_field_' . sanitize_title($cf['label']);
                $f_type = $cf['type'] ?? 'text';
                $val = '';
                if ($f_type === 'textarea') {
                    $val = isset($_POST[$f_key]) ? sanitize_textarea_field(wp_unslash($_POST[$f_key])) : '';
                } elseif ($f_type === 'checkbox') {
                    $val = !empty($_POST[$f_key]) ? 'Yes' : '';
                } else {
                    $val = isset($_POST[$f_key]) ? sanitize_text_field(wp_unslash($_POST[$f_key])) : '';
                }

                if (!empty($cf['required']) && $val === '') {
                    $errors[$f_key] = sprintf('%s is required.', $cf['label']);
                }

                if ($val !== '') {
                    $product_details[$cf['label']] = $val;
                }
            }
        }

        // 6. Server-Side Validation
        if (empty($full_name)) {
            $errors['full_name'] = 'Full Name is required.';
        }
        if (empty($email) || !is_email($email)) {
            $errors['email'] = 'A valid email address is required.';
        }
        if (empty($phone)) {
            $errors['phone'] = 'Phone / WhatsApp number is required.';
        }
        if (empty($country)) {
            $errors['country'] = 'Please select your country.';
        }
        if (empty($product)) {
            $errors['product'] = 'Product selection is required.';
        }
        if (empty($quantity)) {
            $errors['quantity'] = 'Quantity selection is required.';
        }
        if (empty($timeframe)) {
            $errors['timeframe'] = 'Delivery timeframe is required.';
        }
        if (empty($zip_code)) {
            $errors['zip_code'] = 'ZIP / Postal Code is required.';
        }
        if (!$consent) {
            $errors['consent'] = 'You must agree to allow Evonee to contact you.';
        }

        if (!empty($errors)) {
            wp_send_json_error(['errors' => $errors]);
        }

        // 7. Validate & Process Artwork Upload (Multi-file support up to 3 files)
        $artwork_urls   = [];
        $artwork_errors = [];
        $had_artwork    = false;
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Artwork file is validated and uploaded via validate_and_upload_artwork()
        if (!$no_artwork && isset($_FILES['eq_artwork']) && !empty($_FILES['eq_artwork']['name'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $files = $_FILES['eq_artwork'];
            if (is_array($files['name'])) {
                $count = min(count($files['name']), 3);
                for ($i = 0; $i < $count; $i++) {
                    if (empty($files['name'][$i])) {
                        continue;
                    }
                    $had_artwork = true;
                    if ($files['error'][$i] !== UPLOAD_ERR_OK) {
                        $artwork_errors[] = 'File upload error code: ' . $files['error'][$i];
                        continue;
                    }
                    $single_file = [
                        'name'     => $files['name'][$i],
                        'type'     => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'error'    => $files['error'][$i],
                        'size'     => $files['size'][$i],
                    ];
                    $upload_result = $this->validate_and_upload_artwork($single_file);
                    if (is_wp_error($upload_result)) {
                        $artwork_errors[] = $upload_result->get_error_message();
                    } else {
                        $artwork_urls[] = $upload_result;
                    }
                }
            } else {
                $had_artwork = true;
                $upload_result = $this->validate_and_upload_artwork($files);
                if (is_wp_error($upload_result)) {
                    $artwork_errors[] = $upload_result->get_error_message();
                } else {
                    $artwork_urls[] = $upload_result;
                }
            }
        }

        if ($had_artwork && empty($artwork_urls) && !empty($artwork_errors)) {
            wp_send_json_error([
                'message' => 'Artwork upload failed: ' . $artwork_errors[0],
                'errors'  => ['artwork' => $artwork_errors[0]],
            ]);
        }

        $artwork_url = !empty($artwork_urls) ? wp_json_encode($artwork_urls) : '';

        // Calculate Server-Side Instant Price Estimate
        $settings = Evonee_Quote_Admin::get_settings();
        $base_price = isset($settings['base_quote_price']) ? floatval($settings['base_quote_price']) : 50.00;
        $qty_int    = intval(preg_replace('/[^0-9]/', '', $quantity)) ?: 100;
        $unit_price = isset($settings['price_per_item']) ? floatval($settings['price_per_item']) : 1.25;
        $estimated_total = round($base_price + ($qty_int * $unit_price), 2);

        // 8. Prepare Submission Array
        $submission = [
            'full_name'       => $full_name,
            'company'         => $company,
            'email'           => $email,
            'phone'           => $phone,
            'country'         => $country,
            'product'         => $product,
            'quantity'        => $quantity,
            'product_details' => $product_details,
            'artwork_url'     => $artwork_url,
            'timeframe'       => $timeframe,
            'specific_date'   => $specific_date,
            'zip_code'        => $zip_code,
            'project_notes'   => $project_notes,
            'estimated_total' => $estimated_total,
            'created_at'      => current_time('mysql')
        ];

        // 9. Save to Database
        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $inserted = $wpdb->insert(
            $table_name,
            [
                'full_name'       => $submission['full_name'],
                'company'         => $submission['company'],
                'email'           => $submission['email'],
                'phone'           => $submission['phone'],
                'country'         => $submission['country'],
                'product'         => $submission['product'],
                'quantity'        => $submission['quantity'],
                'product_details' => wp_json_encode($submission['product_details']),
                'artwork_url'     => $submission['artwork_url'],
                'timeframe'       => $submission['timeframe'],
                'specific_date'   => $submission['specific_date'],
                'zip_code'        => $submission['zip_code'],
                'project_notes'   => $submission['project_notes'],
                'estimated_total' => $submission['estimated_total'],
                'created_at'      => $submission['created_at']
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%s']
        );

        if ($inserted === false) {
            wp_send_json_error(['message' => 'An internal error occurred while saving your request. Please try again.'], 500);
        }

        $submission['id'] = (int) $wpdb->insert_id;

        delete_transient('evonee_dashboard_stats');
        delete_transient('evonee_dashboard_widget_stats');

        // Increment rate limit counter only after successful DB insert
        set_transient($transient_key, $submission_count + 1, 15 * MINUTE_IN_SECONDS);

        // 10. Send Notification Emails
        Evonee_Quote_Mailer::send_notification($submission);

        // 11. Dispatch Webhook, Slack, Discord, Auto-Quoter & Twilio SMS (Phase 5)
        self::dispatch_webhook($submission);
        self::dispatch_slack($submission);
        self::dispatch_discord($submission);
        self::maybe_auto_quote($submission);
        self::dispatch_twilio_sms($submission);
        self::dispatch_google_sheets($submission);

        // 12. Return Success Response
        wp_send_json_success([
            'message' => 'Quote request received! We will get back to you with a custom quote and digital proof within 24 hours.'
        ]);
    }

    /**
     * Dispatch submission payload to Google Sheets Apps Script Webhook
     *
     * @param array $submission
     * @return bool|WP_Error
     */
    public static function dispatch_google_sheets(array $submission) {
        $settings = Evonee_Quote_Admin::get_settings();
        if (empty($settings['enable_google_sheets']) || $settings['enable_google_sheets'] !== '1' || empty($settings['google_sheets_url'])) {
            return false;
        }

        $artwork_urls = self::parse_artwork_urls($submission['artwork_url'] ?? '');
        $artwork_str  = !empty($artwork_urls) ? implode(' | ', $artwork_urls) : 'None';
        $details_str  = self::format_product_details_text($submission['product_details'] ?? '');

        $payload = [
            'submission_id'   => !empty($submission['id']) ? intval($submission['id']) : 0,
            'created_at'      => $submission['created_at'] ?? current_time('mysql'),
            'full_name'       => $submission['full_name'] ?? '',
            'company'         => $submission['company'] ?? '',
            'email'           => $submission['email'] ?? '',
            'phone'           => $submission['phone'] ?? '',
            'country'         => $submission['country'] ?? '',
            'product'         => $submission['product'] ?? '',
            'quantity'        => $submission['quantity'] ?? '',
            'product_details' => $details_str,
            'artwork_urls'    => $artwork_str,
            'timeframe'       => $submission['timeframe'] ?? '',
            'specific_date'   => $submission['specific_date'] ?? '',
            'zip_code'        => $submission['zip_code'] ?? '',
            'project_notes'   => $submission['project_notes'] ?? '',
            'status'          => $submission['status'] ?? 'new',
        ];

        $response = wp_remote_post(esc_url_raw($settings['google_sheets_url']), [
            'headers'     => ['Content-Type' => 'application/json; charset=utf-8'],
            'body'        => wp_json_encode($payload),
            'timeout'     => 15,
            'redirection' => 5,
        ]);

        $status = is_wp_error($response) ? 'Error: ' . $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code($response);
        if (!empty($submission['id'])) {
            self::log_activity($submission['id'], 'google_sheets_sent', 'Dispatched Google Sheets Sync: ' . $status);
        }

        return is_wp_error($response) ? $response : true;
    }

    /**
     * Manual 1-click Google Sheet sync trigger from Admin Submissions table
     */
    public function handle_sync_google_sheet() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_sync_google_sheet_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $id = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        if (!$id) {
            wp_send_json_error(['message' => 'Invalid submission ID.']);
        }

        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}eq_quote_submissions WHERE id = %d", $id), ARRAY_A);
        if (!$row) {
            wp_send_json_error(['message' => 'Submission not found.']);
        }

        $res = self::dispatch_google_sheets($row);
        if (is_wp_error($res)) {
            wp_send_json_error(['message' => 'Sync failed: ' . $res->get_error_message()]);
        } elseif ($res === false) {
            wp_send_json_error(['message' => 'Google Sheets sync is not enabled in Settings.']);
        }

        wp_send_json_success(['message' => 'Successfully synced submission #' . $id . ' to Google Sheets!']);
    }

    /**
     * Dispatch Webhook POST payload (Phase 3.3)
     */
    public static function dispatch_webhook(array $submission) {
        $settings = Evonee_Quote_Admin::get_settings();
        if (empty($settings['enable_webhook']) || $settings['enable_webhook'] !== '1' || empty($settings['webhook_url'])) {
            return;
        }

        $payload_json = wp_json_encode($submission);
        $headers = ['Content-Type' => 'application/json; charset=utf-8'];

        if (!empty($settings['webhook_secret'])) {
            $signature = hash_hmac('sha256', $payload_json, $settings['webhook_secret']);
            $headers['X-Evonee-Signature'] = $signature;
        }

        $response = wp_remote_post(esc_url_raw($settings['webhook_url']), [
            'headers' => $headers,
            'body'    => $payload_json,
            'timeout' => 15
        ]);

        $status = is_wp_error($response) ? 'Error: ' . $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code($response);
        if (!empty($submission['id'])) {
            self::log_activity($submission['id'], 'webhook_sent', 'Dispatched Outgoing CRM Webhook: ' . $status);
        }
    }

    /**
     * Dispatch Slack Notification (Phase 3.4)
     */
    public static function dispatch_slack(array $submission) {
        $settings = Evonee_Quote_Admin::get_settings();
        if (empty($settings['enable_slack']) || $settings['enable_slack'] !== '1' || empty($settings['slack_webhook_url'])) {
            return;
        }

        $slack_payload = [
            'text' => sprintf("📥 *New Quote Request Received on Evonee*\n*Customer:* %s (%s)\n*Product:* %s (Qty: %s)\n*Email:* %s\n*Country:* %s",
                esc_html($submission['full_name']),
                esc_html($submission['company'] ?: 'No Company'),
                esc_html($submission['product']),
                esc_html($submission['quantity']),
                esc_html($submission['email']),
                esc_html($submission['country'])
            )
        ];

        $response = wp_remote_post(esc_url_raw($settings['slack_webhook_url']), [
            'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
            'body'    => wp_json_encode($slack_payload),
            'timeout' => 15
        ]);

        $status = is_wp_error($response) ? 'Error: ' . $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code($response);
        if (!empty($submission['id'])) {
            self::log_activity($submission['id'], 'slack_sent', 'Dispatched Slack Notification: ' . $status);
        }
    }

    /**
     * Dispatch Discord Notification
     */
    public static function dispatch_discord(array $submission) {
        $settings = Evonee_Quote_Admin::get_settings();
        if (empty($settings['enable_discord']) || $settings['enable_discord'] !== '1' || empty($settings['discord_webhook_url'])) {
            return;
        }

        $discord_payload = [
            'embeds' => [
                [
                    'title' => '📥 New Quote Request Received',
                    'color' => 7153881, // #6d28d9 purple
                    'fields' => [
                        ['name' => 'Customer', 'value' => esc_html($submission['full_name']), 'inline' => true],
                        ['name' => 'Email', 'value' => esc_html($submission['email']), 'inline' => true],
                        ['name' => 'Phone', 'value' => esc_html($submission['phone']), 'inline' => true],
                        ['name' => 'Product', 'value' => esc_html($submission['product']), 'inline' => true],
                        ['name' => 'Quantity', 'value' => esc_html($submission['quantity']), 'inline' => true],
                        ['name' => 'Estimated Total', 'value' => '$' . number_format((float)($submission['estimated_total'] ?? 0), 2), 'inline' => true],
                    ],
                    'footer' => ['text' => 'Evonee Quote System v2.0']
                ]
            ]
        ];

        $response = wp_remote_post(esc_url_raw($settings['discord_webhook_url']), [
            'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
            'body'    => wp_json_encode($discord_payload),
            'timeout' => 15
        ]);

        $status = is_wp_error($response) ? 'Error: ' . $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code($response);
        if (!empty($submission['id'])) {
            self::log_activity($submission['id'], 'discord_sent', 'Dispatched Discord Notification: ' . $status);
        }
    }

    /**
     * Handle Admin PDF Quote Download (AJAX)
     */
    public function handle_download_pdf() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized.', 'Evonee Quote System', ['response' => 403]);
        }

        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if (!$id) {
            wp_die('Invalid quote submission ID.', 'Evonee Quote System', ['response' => 400]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $id));

        if (!$row) {
            wp_die('Quote submission record not found.', 'Evonee Quote System', ['response' => 404]);
        }

        Evonee_Quote_PDF::generate($row, 'D', 'Quote-Estimate-' . $id . '.pdf');
        exit;
    }

    /**
     * Validate and Upload Artwork File
     *
     * @param array $file_array
     * @return string|WP_Error File URL or WP_Error on failure
     */
    private function validate_and_upload_artwork(array $file_array) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        // Check upload errors
        if ($file_array['error'] !== UPLOAD_ERR_OK) {
            return new WP_Error('upload_error', 'File upload error code: ' . $file_array['error']);
        }

        // Max file size: 20MB or WordPress server limit (whichever is smaller)
        $limit_bytes   = min(20 * 1024 * 1024, wp_max_upload_size());
        $formatted_max = size_format($limit_bytes);
        if ($file_array['size'] > $limit_bytes) {
            return new WP_Error('file_too_large', sprintf('File size exceeds the maximum allowed limit of %s.', $formatted_max));
        }

        // Allowed extensions and MIME types
        $mimes = [
            'pdf'  => 'application/pdf',
            'png'  => 'image/png',
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'svg'  => 'image/svg+xml',
            'ai'   => ['application/postscript', 'application/pdf', 'application/illustrator', 'application/vnd.adobe.illustrator'],
            'eps'  => ['application/postscript', 'image/x-eps', 'application/eps']
        ];

        $ext = strtolower(pathinfo($file_array['name'], PATHINFO_EXTENSION));
        $allowed_exts = ['ai', 'pdf', 'eps', 'svg', 'png', 'jpg', 'jpeg'];

        if (!in_array($ext, $allowed_exts, true)) {
            return new WP_Error('invalid_extension', 'Invalid file format. Allowed formats: AI, PDF, EPS, SVG, PNG, JPG.');
        }

        $wp_filetype = wp_check_filetype_and_ext($file_array['tmp_name'], $file_array['name'], $mimes);
        if (!empty($wp_filetype['proper_filename'])) {
            $file_array['name'] = $wp_filetype['proper_filename'];
        }

        $strict_exts = ['png', 'jpg', 'jpeg', 'pdf', 'svg'];
        if (in_array($ext, $strict_exts, true) && empty($wp_filetype['type'])) {
            return new WP_Error('invalid_type', 'File type could not be verified. Please upload a valid artwork file.');
        }

        // Custom upload directory callback
        $upload_dir_filter = function($uploads) {
            $folder = '/evonee-quotes/' . gmdate('Y/m');
            $uploads['subdir'] = $folder;
            $uploads['path']   = $uploads['basedir'] . $folder;
            $uploads['url']    = $uploads['baseurl'] . $folder;
            return $uploads;
        };

        add_filter('upload_dir', $upload_dir_filter);

        $upload_overrides = [
            'test_form' => false,
            'mimes'     => $mimes
        ];

        $move_file = wp_handle_upload($file_array, $upload_overrides);

        remove_filter('upload_dir', $upload_dir_filter);

        if (isset($move_file['error'])) {
            return new WP_Error('upload_failed', $move_file['error']);
        }

        $uploaded_file_path = $move_file['file'];

        // SVG Sanitization — FIX BUG #9: Use DOMDocument for reliable parsing
        if ($ext === 'svg' && file_exists($uploaded_file_path)) {
            $svg_content = file_get_contents($uploaded_file_path);
            if ($svg_content !== false) {
                if (class_exists('DOMDocument')) {
                    libxml_use_internal_errors(true);
                    $dom = new DOMDocument();
                    $dom->loadXML($svg_content, LIBXML_NONET | LIBXML_NOENT);
                    libxml_clear_errors();

                    // Remove dangerous element types
                    $dangerous_tags = ['script', 'use', 'foreignObject', 'iframe', 'object', 'embed', 'form', 'input', 'link'];
                    foreach ($dangerous_tags as $tag) {
                        $nodes = $dom->getElementsByTagName($tag);
                        while ($nodes->length > 0) {
                            $node = $nodes->item(0);
                            $node->parentNode->removeChild($node);
                        }
                    }

                    // Remove dangerous attributes from all elements
                    $all_elements = $dom->getElementsByTagName('*');
                    foreach ($all_elements as $el) {
                        $attrs_to_remove = [];
                        if ($el->hasAttributes()) {
                            foreach ($el->attributes as $attr) {
                                $name = strtolower($attr->name);
                                $val  = $attr->value;
                                if (strpos($name, 'on') === 0) {
                                    $attrs_to_remove[] = $attr->name;
                                }
                                if (in_array($name, ['href', 'xlink:href'], true) && preg_match('/^\s*(javascript|data):/i', $val)) {
                                    $attrs_to_remove[] = $attr->name;
                                }
                                if ($name === 'style' && preg_match('/(?:javascript:|expression\s*\()/i', $val)) {
                                    $attrs_to_remove[] = $attr->name;
                                }
                            }
                        }
                        foreach ($attrs_to_remove as $aname) {
                            $el->removeAttribute($aname);
                        }
                    }

                    $clean_svg = $dom->saveXML();
                } else {
                    // Fallback: regex-based sanitization
                    $clean_svg = preg_replace('/<script\b[^>]*>.*?<\/script>/is', '', $svg_content);
                    $clean_svg = preg_replace('/\s+on[a-z]+\s*=\s*"[^"]*"/i', '', $clean_svg);
                    $clean_svg = preg_replace("/\s+on[a-z]+\s*=\s*'[^']*'/i", '', $clean_svg);
                    $clean_svg = preg_replace('/<use\b[^>]*\/?>(?:.*?<\/use>)?/is', '', $clean_svg);
                    $clean_svg = preg_replace('/<foreignObject[^>]*>.*?<\/foreignObject>/is', '', $clean_svg);
                    $clean_svg = preg_replace('/(?:xlink:href|href)\s*=\s*["\']?\s*(?:javascript|data):[^"\'>\s]*/i', 'href="#"', $clean_svg);
                    $clean_svg = preg_replace('/style\s*=\s*"[^"]*(?:javascript:|expression\s*\()[^"]*"/i', '', $clean_svg);
                }

                // Final safety check — delete file if still contains dangerous patterns
                if (preg_match('/<script|on[a-z]+\s*=|javascript:|foreignObject|<use\b/i', $clean_svg)) {
                    @unlink($uploaded_file_path);
                    return new WP_Error('unsafe_svg', 'SVG file contains unsafe content and was rejected.');
                }
                file_put_contents($uploaded_file_path, $clean_svg);
            }
        }

        return esc_url_raw($move_file['url']);
    }

    /**
     * Handle Sending Quote Discussion Messages (Step 2)
     * FIX BUG #2: Added nonce verification
     * FIX BUG #3: Added sender authorization check
     */
    public function handle_send_message() {
        // FIX BUG #2: Verify nonce to prevent CSRF & unauthenticated message injection
        if (!check_ajax_referer('eq_message_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $sub_id  = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
        $sender  = isset($_POST['sender_type']) ? sanitize_text_field(wp_unslash($_POST['sender_type'])) : 'customer';

        // FIX BUG #3: Enforce sender type — only admins can claim to be 'admin'
        if ($sender === 'admin' && !current_user_can('manage_options')) {
            $sender = 'customer'; // Downgrade unauthorized admin claim
        }

        if (!$sub_id || empty($message)) {
            wp_send_json_error(['message' => 'Invalid parameters.'], 400);
        }

        global $wpdb;
        $msg_table = $wpdb->prefix . 'eq_quote_messages';
        self::maybe_run_phase2_migrations();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $quote = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}eq_quote_submissions WHERE id = %d", $sub_id));
        if (!$quote) {
            wp_send_json_error(['message' => 'Quote submission not found.'], 404);
        }

        $sender_name = ($sender === 'admin') ? (wp_get_current_user()->display_name ?: 'Sales Team') : $quote->full_name;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->insert(
            $msg_table,
            [
                'submission_id' => $sub_id,
                'sender_type'   => $sender,
                'sender_name'   => $sender_name,
                'message'       => $message,
                'created_at'    => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s', '%s']
        );

        // FIX BUG #15: Only append '...' when message is actually truncated
        $msg_preview = strlen($message) > 40 ? substr($message, 0, 40) . '...' : $message;
        self::log_activity($sub_id, 'discussion_message', 'Message sent by ' . strtoupper($sender) . ': ' . $msg_preview);

        // Email Notification for Discussion Thread
        $sales_email = self::get_sales_email();
        if ($sender === 'customer') {
            $to      = $sales_email;
            $subject = '💬 New Customer Message on Quote #' . $sub_id . ' — ' . $quote->full_name;
            $body    = "Customer {$quote->full_name} ({$quote->email}) sent a message regarding Quote #{$sub_id}:\n\n\"{$message}\"\n\nView submission: " . admin_url('admin.php?page=evonee-submissions');
        } else {
            $to      = $quote->email;
            $subject = '💬 New Response regarding your Quote #' . $sub_id . ' — Evonee';
            $body    = "Hi {$quote->full_name},\n\nOur team has responded to your quote request:\n\n\"{$message}\"\n\nThank you for choosing Evonee.";
        }

        wp_mail($to, $subject, $body, ['From: Evonee Sales <' . $sales_email . '>']);

        wp_send_json_success(['message' => 'Message sent successfully.']);
    }

    /**
     * Handle Fetching Discussion Messages for a Quote (Step 2)
     * FIX BUG #3: Added nonce + authorization to prevent unauthenticated data access
     */
    public function handle_get_messages() {
        // FIX BUG #3: Require nonce verification
        if (!check_ajax_referer('eq_message_nonce', 'nonce', false)) {
            wp_send_json_error(['messages' => []], 403);
        }

        $sub_id = isset($_GET['submission_id']) ? intval($_GET['submission_id']) : 0;
        if (!$sub_id) {
            wp_send_json_error(['messages' => []]);
        }

        global $wpdb;
        $msg_table = $wpdb->prefix . 'eq_quote_messages';
        self::maybe_run_phase2_migrations();

        // FIX BUG #3: Authorization — admins see all; customers only see messages
        // for quotes matching their verified nonce session (portal context)
        if (!current_user_can('manage_options')) {
            // For non-admin users (customer portal), verify the quote exists
            // Nonce verification above already ensures this is a legitimate page request
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $quote_exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}eq_quote_submissions WHERE id = %d",
                $sub_id
            ));
            if (!$quote_exists) {
                wp_send_json_error(['messages' => []], 404);
            }
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $messages = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}eq_quote_messages WHERE submission_id = %d ORDER BY id ASC", $sub_id));

        wp_send_json_success(['messages' => $messages ?: []]);
    }

    /**
     * Register Custom WP REST API Endpoints (Step 6)
     */
    public function register_rest_routes() {
        register_rest_route('evonee/v1', '/quotes', [
            'methods'             => 'GET',
            'callback'            => [$this, 'rest_get_quotes'],
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ]);

        register_rest_route('evonee/v1', '/submit', [
            'methods'             => 'POST',
            'callback'            => [$this, 'rest_submit_quote'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('evonee/v1', '/stats', [
            'methods'             => 'GET',
            'callback'            => [$this, 'rest_get_stats'],
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ]);
    }

    public function rest_get_quotes($request) {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $results = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}eq_quote_submissions ORDER BY id DESC LIMIT 50");
        return rest_ensure_response(['success' => true, 'quotes' => $results ?: []]);
    }

    public function rest_get_stats($request) {
        return rest_ensure_response(['success' => true, 'stats' => get_transient('evonee_dashboard_stats') ?: []]);
    }

    public function rest_submit_quote($request) {
        // FIX BUG #11: Implement actual REST API quote submission instead of dummy response
        $params = $request->get_params();
        if (empty($params)) {
            return new WP_Error('missing_params', 'No parameters provided.', ['status' => 400]);
        }

        // Sanitize required fields
        $full_name = !empty($params['full_name']) ? sanitize_text_field($params['full_name']) : '';
        $email     = !empty($params['email']) ? sanitize_email($params['email']) : '';
        $phone     = !empty($params['phone']) ? sanitize_text_field($params['phone']) : '';
        $product   = !empty($params['product']) ? sanitize_text_field($params['product']) : '';
        $quantity  = !empty($params['quantity']) ? sanitize_text_field($params['quantity']) : '';
        $timeframe = !empty($params['timeframe']) ? sanitize_text_field($params['timeframe']) : '';
        $zip_code  = !empty($params['zip_code']) ? sanitize_text_field($params['zip_code']) : '';
        $country   = !empty($params['country']) ? sanitize_text_field($params['country']) : '';

        // Validate required fields
        $errors = [];
        if (empty($full_name))                        $errors[] = 'full_name is required.';
        if (empty($email) || !is_email($email))       $errors[] = 'A valid email is required.';
        if (empty($phone))                            $errors[] = 'phone is required.';
        if (empty($product))                          $errors[] = 'product is required.';
        if (empty($quantity))                         $errors[] = 'quantity is required.';
        if (empty($timeframe))                        $errors[] = 'timeframe is required.';
        if (empty($zip_code))                         $errors[] = 'zip_code is required.';
        if (empty($country))                          $errors[] = 'country is required.';

        if (!empty($errors)) {
            return new WP_Error('validation_error', implode(' ', $errors), ['status' => 422]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $inserted = $wpdb->insert(
            $table_name,
            [
                'full_name'       => $full_name,
                'company'         => !empty($params['company']) ? sanitize_text_field($params['company']) : '',
                'email'           => $email,
                'phone'           => $phone,
                'country'         => $country,
                'product'         => $product,
                'quantity'        => $quantity,
                'product_details' => !empty($params['product_details']) ? wp_json_encode($params['product_details']) : '',
                'artwork_url'     => '',
                'timeframe'       => $timeframe,
                'specific_date'   => !empty($params['specific_date']) ? sanitize_text_field($params['specific_date']) : '',
                'zip_code'        => $zip_code,
                'project_notes'   => !empty($params['project_notes']) ? sanitize_textarea_field($params['project_notes']) : '',
                'created_at'      => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );

        if ($inserted === false) {
            return new WP_Error('db_error', 'Failed to save quote submission.', ['status' => 500]);
        }

        $submission_id = (int) $wpdb->insert_id;
        delete_transient('evonee_dashboard_stats');
        delete_transient('evonee_dashboard_widget_stats');

        // Send notification emails
        $submission = array_merge((array) $wpdb->get_row($wpdb->prepare(
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            "SELECT * FROM {$wpdb->prefix}eq_quote_submissions WHERE id = %d", $submission_id
        )), ['id' => $submission_id]);
        Evonee_Quote_Mailer::send_notification($submission);

        return rest_ensure_response([
            'success'       => true,
            'message'       => 'Quote submitted successfully.',
            'submission_id' => $submission_id,
        ]);
    }

    /**
     * Handle Kanban Drag & Drop Status Update
     */
    public function handle_update_status_kanban() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_kanban_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $id     = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field(wp_unslash($_POST['status'])) : '';
        $allowed_statuses = ['new', 'pending', 'quoted', 'approved', 'completed', 'rejected'];

        if (!$id || !in_array($status, $allowed_statuses, true)) {
            wp_send_json_error(['message' => 'Invalid parameters.']);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $updated = $wpdb->update($table_name, ['status' => $status], ['id' => $id], ['%s'], ['%d']);

        if ($updated !== false) {
            self::log_activity($id, 'status_updated_kanban', 'Status changed to ' . strtoupper($status) . ' via Kanban Board');
            delete_transient('evonee_dashboard_stats');
            delete_transient('evonee_dashboard_widget_stats');
            wp_send_json_success(['message' => 'Status updated to ' . strtoupper($status)]);
        }
        wp_send_json_error(['message' => 'Failed to update status.']);
    }

    /**
     * Handle JSON Export of Plugin Settings
     */
    public function handle_export_settings() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_export_settings_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $export_data = [
            'version'         => EVONEE_QUOTE_VERSION,
            'exported_at'     => current_time('mysql'),
            'settings'        => Evonee_Quote_Admin::get_settings(),
            'custom_fields'   => get_option('evonee_quote_custom_fields', []),
            'reply_templates' => get_option('evonee_reply_templates', []),
        ];

        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="evonee-settings-export-' . date('Y-m-d') . '.json"');
        echo wp_json_encode($export_data, JSON_PRETTY_PRINT);
        exit;
    }

    /**
     * Handle JSON Import of Plugin Settings
     */
    public function handle_import_settings() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.'], 403);
        }
        if (!check_ajax_referer('eq_import_settings_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $json_raw = isset($_POST['json_data']) ? wp_unslash($_POST['json_data']) : '';
        if (empty($json_raw) && !empty($_FILES['import_file']['tmp_name'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $json_raw = file_get_contents($_FILES['import_file']['tmp_name']);
        }

        $data = json_decode($json_raw, true);
        if (!$data || !is_array($data) || empty($data['settings'])) {
            wp_send_json_error(['message' => 'Invalid JSON configuration file format.']);
        }

        update_option('evonee_quote_settings', $data['settings']);
        if (isset($data['custom_fields']) && is_array($data['custom_fields'])) {
            update_option('evonee_quote_custom_fields', $data['custom_fields']);
        }
        if (isset($data['reply_templates']) && is_array($data['reply_templates'])) {
            update_option('evonee_reply_templates', $data['reply_templates']);
        }

        wp_send_json_success(['message' => 'Plugin settings and configurations successfully imported!']);
    }

    /**
     * Handle GDPR Customer Quote Data Export (JSON)
     */
    public function handle_gdpr_export() {
        $email = isset($_REQUEST['email']) ? sanitize_email(wp_unslash($_REQUEST['email'])) : '';
        $token = isset($_REQUEST['token']) ? sanitize_text_field(wp_unslash($_REQUEST['token'])) : '';

        if (empty($email)) {
            wp_send_json_error(['message' => 'Email address is required.'], 400);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';

        if (!current_user_can('manage_options')) {
            if (empty($token)) {
                wp_send_json_error(['message' => 'Security token required.'], 403);
            }
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $quotes = $wpdb->get_results($wpdb->prepare("SELECT id, full_name, email, phone, company, product, quantity, timeframe, project_notes, status, created_at FROM {$table_name} WHERE email = %s AND acceptance_token = %s", $email, $token));
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $quotes = $wpdb->get_results($wpdb->prepare("SELECT id, full_name, email, phone, company, product, quantity, timeframe, project_notes, status, created_at FROM {$table_name} WHERE email = %s", $email));
        }

        if (empty($quotes)) {
            wp_send_json_error(['message' => 'No matching quote records found for this email address.']);
        }

        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="gdpr-quote-data-' . sanitize_file_name($email) . '.json"');
        echo wp_json_encode(['gdpr_export' => $quotes, 'exported_at' => current_time('mysql')], JSON_PRETTY_PRINT);
        exit;
    }

    /**
     * Handle GDPR Right to be Forgotten (Data Erasure)
     */
    public function handle_gdpr_erasure() {
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';

        if (empty($email)) {
            wp_send_json_error(['message' => 'Email address is required.']);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';

        if (!current_user_can('manage_options')) {
            if (empty($token)) {
                wp_send_json_error(['message' => 'Security verification failed.'], 403);
            }
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $updated = $wpdb->query($wpdb->prepare(
                "UPDATE {$table_name} SET full_name = 'Anonymized User', email = 'anonymized@deleted.local', phone = '', company = '', project_notes = '[GDPR Erased]' WHERE email = %s AND acceptance_token = %s",
                $email, $token
            ));
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $updated = $wpdb->query($wpdb->prepare(
                "UPDATE {$table_name} SET full_name = 'Anonymized User', email = 'anonymized@deleted.local', phone = '', company = '', project_notes = '[GDPR Erased]' WHERE email = %s",
                $email
            ));
        }

        delete_transient('evonee_dashboard_stats');
        delete_transient('evonee_dashboard_widget_stats');

        wp_send_json_success(['message' => 'Personal data has been successfully anonymized in compliance with GDPR.']);
    }

    /**
     * Handle Exporting Activity Log Timeline to CSV
     */
    public function handle_export_activity_csv() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized', 'Error', ['response' => 403]);
        }
        if (!check_ajax_referer('eq_export_csv_nonce', 'nonce', false)) {
            wp_die('Security check failed', 'Error', ['response' => 403]);
        }

        global $wpdb;
        $act_table = $wpdb->prefix . 'eq_quote_activity_log';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $logs = $wpdb->get_results("SELECT id, submission_id, action, notes, user_id, created_at FROM {$act_table} ORDER BY id DESC LIMIT 500");

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="evonee-audit-activity-log-' . date('Y-m-d') . '.csv"');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Log ID', 'Submission ID', 'Action', 'Notes', 'User ID', 'Timestamp']);

        if (!empty($logs)) {
            foreach ($logs as $l) {
                fputcsv($output, [$l->id, $l->submission_id, $l->action, $l->notes, $l->user_id, $l->created_at]);
            }
        }
        fclose($output);
        exit;
    }

    /**
     * Get Visitor Real Client IP Address
     */
    private function get_client_ip() {
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_CONNECTING_IP']));
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
        if (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR']));
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
        return '127.0.0.1';
    }

    /**
     * Smart Auto-Quoter Pricing Rules Engine (Phase 5)
     */
    public static function maybe_auto_quote(array $submission) {
        $settings = Evonee_Quote_Admin::get_settings();
        if (empty($settings['enable_auto_quoter']) || $settings['enable_auto_quoter'] !== '1') {
            return;
        }

        $qty     = intval($submission['quantity'] ?? 0);
        $min_qty = intval($settings['auto_quoter_min_qty'] ?? 100);
        if ($qty <= 0 || $qty < $min_qty) {
            return;
        }

        $sub_id = intval($submission['id'] ?? 0);
        if (!$sub_id) return;

        $unit_price  = floatval($settings['auto_quoter_unit_price'] ?? 2.50);
        $total_offer = $qty * $unit_price;

        $token  = wp_generate_password(32, false);
        $expiry = gmdate('Y-m-d H:i:s', time() + (30 * DAY_IN_SECONDS));

        global $wpdb;
        $table_name = $wpdb->prefix . 'eq_quote_submissions';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $table_name,
            [
                'quoted_price'     => $total_offer,
                'status'           => 'quoted',
                'acceptance_token' => $token,
                'token_expiry'     => $expiry
            ],
            ['id' => $sub_id],
            ['%f', '%s', '%s', '%s'],
            ['%d']
        );

        self::log_activity($sub_id, 'auto_quoted', 'Smart Auto-Quoter issued instant offer of $' . number_format($total_offer, 2));

        // Dispatch Auto-Quoted Offer Email to Customer
        $sales_email = self::get_sales_email();
        $brand_name  = !empty($settings['email_brand_name']) ? $settings['email_brand_name'] : 'Evonee';
        $accept_url  = add_query_arg(['eq_action' => 'accept_quote', 'token' => $token], home_url());
        $decline_url = add_query_arg(['eq_action' => 'decline_quote', 'token' => $token], home_url());

        $subject = '🎉 Instant Price Offer for your Quote #' . $sub_id . ' — ' . $brand_name;
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $brand_name . ' Sales <' . $sales_email . '>'
        ];

        $mail_body = '
        <!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family:sans-serif; background:#f8fafc; padding:20px; color:#1e293b;">
            <div style="max-width:580px; margin:0 auto; background:#ffffff; border-radius:10px; overflow:hidden; border:1px solid #e2e8f0;">
                <div style="background:#6d28d9; color:#fff; padding:20px; text-align:center;">
                    <h2 style="margin:0;">🎉 Instant Price Offer Ready!</h2>
                </div>
                <div style="padding:24px;">
                    <p>Hi <strong>' . esc_html($submission['full_name']) . '</strong>,</p>
                    <p>Thank you for submitting a quote for <strong>' . esc_html($submission['product']) . '</strong>. Based on your requested quantity (' . esc_html($submission['quantity']) . '), here is your instant negotiated offer:</p>
                    <div style="background:#faf5ff; border:1px solid #e9d5ff; border-radius:8px; padding:16px; margin:20px 0; text-align:center;">
                        <span style="font-size:12px; color:#6d28d9; text-transform:uppercase; font-weight:700;">Instant Quoted Price</span>
                        <div style="font-size:28px; font-weight:800; color:#4c1d95; margin-top:4px;">$' . number_format($total_offer, 2) . '</div>
                    </div>
                    <div style="text-align:center; margin-top:24px;">
                        <a href="' . esc_url($accept_url) . '" style="background:#16a34a; color:#fff; padding:12px 24px; border-radius:6px; font-weight:bold; text-decoration:none; margin-right:10px;">✅ Accept & Sign Quote</a>
                        <a href="' . esc_url($decline_url) . '" style="background:#dc2626; color:#fff; padding:12px 20px; border-radius:6px; font-weight:bold; text-decoration:none;">❌ Decline</a>
                    </div>
                </div>
            </div>
        </body>
        </html>';

        wp_mail($submission['email'], $subject, $mail_body, $headers);
    }

    /**
     * Twilio SMS & WhatsApp Notification Trigger (Phase 5)
     */
    public static function dispatch_twilio_sms(array $submission) {
        $settings = Evonee_Quote_Admin::get_settings();
        if (empty($settings['enable_twilio_sms']) || $settings['enable_twilio_sms'] !== '1') {
            return;
        }

        $sid   = $settings['twilio_sid'] ?? '';
        $token = $settings['twilio_token'] ?? '';
        $from  = $settings['twilio_from_number'] ?? '';
        if (empty($sid) || empty($token) || empty($from)) {
            return;
        }

        $phone = $submission['phone'] ?? '';
        if (empty($phone)) return;

        $msg = sprintf("Hi %s, we received your quote request for %s (Qty: %s). Our team will prepare your custom quote & digital proof within 24h! - Evonee", $submission['full_name'], $submission['product'], $submission['quantity']);

        $url = 'https://api.twilio.com/2010-04-01/Accounts/' . urlencode($sid) . '/Messages.json';
        wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($sid . ':' . $token)
            ],
            'body' => [
                'From' => $from,
                'To'   => $phone,
                'Body' => $msg
            ]
        ]);
    }
}
